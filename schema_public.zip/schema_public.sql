--
-- PostgreSQL database dump
--

\restrict 2ZcSy2FdaWKfBPjpHUmu9KLqIpIJbaiT5pnXDsxx5VXzgW8FD6oH1LYkAhqIVY9

-- Dumped from database version 18.6 (Ubuntu 18.6-3build2)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-3build2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: brasil_saas; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA brasil_saas;


--
-- Name: SCHEMA brasil_saas; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA brasil_saas IS 'Schema principal do Brasil SaaS ERP';


--
-- Name: brasil_saas_dl; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA brasil_saas_dl;


--
-- Name: SCHEMA brasil_saas_dl; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA brasil_saas_dl IS 'Datalake do BI - Brasil SaaS ERP';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA brasil_saas;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA brasil_saas;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA brasil_saas;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: dmemo; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dmemo AS character varying(500);


--
-- Name: dmkqt; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dmkqt AS numeric(15,2);


--
-- Name: docod; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.docod AS integer;


--
-- Name: dodata; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dodata AS date;


--
-- Name: dohoras; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dohoras AS time without time zone;


--
-- Name: dom1; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom1 AS character(1);


--
-- Name: dom10; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom10 AS character varying(10);


--
-- Name: dom100; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom100 AS character varying(100);


--
-- Name: dom15; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom15 AS character varying(15);


--
-- Name: dom150; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom150 AS character varying(150);


--
-- Name: dom2; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom2 AS character(2);


--
-- Name: dom20; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom20 AS character varying(20);


--
-- Name: dom200; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom200 AS character varying(200);


--
-- Name: dom30; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom30 AS character varying(30);


--
-- Name: dom40; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom40 AS character varying(40);


--
-- Name: dom45; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom45 AS character varying(45);


--
-- Name: dom5; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom5 AS character varying(5);


--
-- Name: dom50; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom50 AS character varying(50);


--
-- Name: dom60; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom60 AS character varying(60);


--
-- Name: dom80; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dom80 AS character varying(80);


--
-- Name: dompeso; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dompeso AS numeric(9,3);


--
-- Name: domtraco; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.domtraco AS numeric(15,5);


--
-- Name: domvalor4casas; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.domvalor4casas AS numeric(15,4);


--
-- Name: dovalor; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dovalor AS numeric(15,2);


--
-- Name: dovalort; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.dovalort AS numeric(15,4);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: brasil_saas; Owner: -
--

CREATE FUNCTION brasil_saas.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION set_updated_at(); Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON FUNCTION brasil_saas.set_updated_at() IS 'Atualiza updated_at em triggers de UPDATE';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bc_bi_dashboard; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_dashboard (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    dashboard_type character varying(50) DEFAULT 'CUSTOM'::character varying,
    layout_config jsonb,
    is_public boolean DEFAULT false,
    is_default boolean DEFAULT false,
    refresh_interval_minutes integer DEFAULT 30,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    nome character varying(100),
    tipo character varying(50),
    layout text,
    filtros text,
    ativo boolean DEFAULT true,
    publico boolean DEFAULT false,
    data_criacao date DEFAULT CURRENT_DATE,
    data_atualizacao date,
    criado_por bigint,
    descricao text
);


--
-- Name: TABLE bc_bi_dashboard; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_bi_dashboard IS 'Business Intelligence dashboards';


--
-- Name: bc_bi_dashboard_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_dashboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_dashboard_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_dashboard_id_seq OWNED BY brasil_saas.bc_bi_dashboard.id;


--
-- Name: bc_bi_dashboard_widget; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_dashboard_widget (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    dashboard_id bigint NOT NULL,
    title character varying(100) NOT NULL,
    widget_type character varying(50) NOT NULL,
    data_source character varying(200),
    chart_type character varying(50),
    config jsonb,
    position_x integer DEFAULT 0,
    position_y integer DEFAULT 0,
    width integer DEFAULT 4,
    height integer DEFAULT 3,
    refresh_enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_bi_dashboard_widget; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_bi_dashboard_widget IS 'Widgets that compose dashboards';


--
-- Name: bc_bi_dashboard_widget_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_dashboard_widget_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_dashboard_widget_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_dashboard_widget_id_seq OWNED BY brasil_saas.bc_bi_dashboard_widget.id;


--
-- Name: bc_bi_indicador; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_indicador (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    categoria character varying(50),
    formula text,
    valor_atual numeric(15,2),
    valor_anterior numeric(15,2),
    valor_meta numeric(15,2),
    unidade_medida character varying(20) DEFAULT 'R$'::character varying,
    cor_valor_baixo character varying(20) DEFAULT '#dc3545'::character varying,
    cor_valor_medio character varying(20) DEFAULT '#ffc107'::character varying,
    cor_valor_alto character varying(20) DEFAULT '#28a745'::character varying,
    ativo boolean DEFAULT true,
    data_calculo date,
    frequencia_atualizacao character varying(20),
    visivel_dashboard boolean DEFAULT true,
    ordem_exibicao integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_bi_indicador_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_indicador_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_indicador_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_indicador_id_seq OWNED BY brasil_saas.bc_bi_indicador.id;


--
-- Name: bc_bi_kpi; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_kpi (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    kpi_type character varying(50),
    query_formula text,
    target_value double precision,
    current_value double precision,
    unit character varying(20) DEFAULT 'R$'::character varying,
    format character varying(20) DEFAULT 'NUMBER'::character varying,
    color_good character varying(20) DEFAULT '#10b981'::character varying,
    color_warning character varying(20) DEFAULT '#f59e0b'::character varying,
    color_bad character varying(20) DEFAULT '#ef4444'::character varying,
    threshold_good double precision,
    threshold_warning double precision,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_bi_kpi; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_bi_kpi IS 'Key Performance Indicators';


--
-- Name: bc_bi_kpi_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_kpi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_kpi_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_kpi_id_seq OWNED BY brasil_saas.bc_bi_kpi.id;


--
-- Name: bc_bi_relatorio; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_relatorio (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    tipo character varying(50),
    categoria character varying(50),
    sql_query text,
    parametros text,
    ativo boolean DEFAULT true,
    agendado boolean DEFAULT false,
    frequencia character varying(20),
    ultima_execucao timestamp without time zone,
    proxima_execucao timestamp without time zone,
    email_destinatarios text,
    formato_exportacao character varying(20) DEFAULT 'PDF'::character varying,
    criado_por bigint,
    data_criacao timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_bi_relatorio_agendado; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_relatorio_agendado (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    relatorio_id bigint,
    nome character varying(100) NOT NULL,
    descricao text,
    frequencia character varying(20),
    intervalo_dias integer,
    proxima_execucao timestamp without time zone,
    ultima_execucao timestamp without time zone,
    ativo boolean DEFAULT true,
    email_destinatarios text,
    formato character varying(20) DEFAULT 'PDF'::character varying,
    parametros text,
    criado_por bigint,
    data_criacao timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_bi_relatorio_agendado_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_relatorio_agendado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_relatorio_agendado_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_relatorio_agendado_id_seq OWNED BY brasil_saas.bc_bi_relatorio_agendado.id;


--
-- Name: bc_bi_relatorio_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_relatorio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_relatorio_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_relatorio_id_seq OWNED BY brasil_saas.bc_bi_relatorio.id;


--
-- Name: bc_bi_report; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_report (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    report_type character varying(50),
    query_sql text,
    template_path character varying(500),
    output_format character varying(50),
    is_scheduled boolean DEFAULT false,
    schedule_cron character varying(100),
    schedule_email character varying(200),
    category character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_bi_report; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_bi_report IS 'Business Intelligence reports';


--
-- Name: bc_bi_report_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_report_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_report_id_seq OWNED BY brasil_saas.bc_bi_report.id;


--
-- Name: bc_bi_report_parameter; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_bi_report_parameter (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    report_id bigint NOT NULL,
    name character varying(50) NOT NULL,
    label character varying(100),
    parameter_type character varying(20),
    default_value character varying(200),
    is_required boolean DEFAULT false,
    sort_order integer DEFAULT 0,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_bi_report_parameter; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_bi_report_parameter IS 'Parameters for reports';


--
-- Name: bc_bi_report_parameter_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_bi_report_parameter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_bi_report_parameter_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_bi_report_parameter_id_seq OWNED BY brasil_saas.bc_bi_report_parameter.id;


--
-- Name: bc_cad_base_cep; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_base_cep (
    id bigint NOT NULL,
    cep character varying(8) NOT NULL,
    logradouro character varying(200),
    bairro character varying(100),
    municipio_id bigint,
    uf character(2),
    tipo character varying(30),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_base_cep; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_base_cep IS 'Base de CEPs (global)';


--
-- Name: bc_cad_base_cep_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_base_cep_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_base_cep_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_base_cep_id_seq OWNED BY brasil_saas.bc_cad_base_cep.id;


--
-- Name: bc_cad_categoria; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_categoria (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(255),
    categoria_pai_id bigint,
    tipo character varying(20) DEFAULT 'PRODUTO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_categoria; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_categoria IS 'Categorias de produtos/serviços (hierárquica)';


--
-- Name: bc_cad_categoria_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_categoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_categoria_id_seq OWNED BY brasil_saas.bc_cad_categoria.id;


--
-- Name: bc_cad_cliente; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_cliente (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    codigo character varying(30),
    limite_credito numeric(15,2) DEFAULT 0 NOT NULL,
    classificacao character varying(10),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    logo_url text,
    logo_tipo_conteudo character varying(50),
    logo_tamanho bigint
);


--
-- Name: TABLE bc_cad_cliente; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_cliente IS 'Clientes';


--
-- Name: COLUMN bc_cad_cliente.logo_url; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_cliente.logo_url IS 'URL do logo do cliente para relatórios e documentos';


--
-- Name: COLUMN bc_cad_cliente.logo_tipo_conteudo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_cliente.logo_tipo_conteudo IS 'Tipo MIME do logo do cliente';


--
-- Name: COLUMN bc_cad_cliente.logo_tamanho; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_cliente.logo_tamanho IS 'Tamanho em bytes do logo do cliente';


--
-- Name: bc_cad_cliente_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_cliente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_cliente_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_cliente_id_seq OWNED BY brasil_saas.bc_cad_cliente.id;


--
-- Name: bc_cad_contato; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_contato (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    tipo character varying(30) DEFAULT 'COMERCIAL'::character varying NOT NULL,
    nome character varying(150),
    email character varying(150),
    telefone character varying(20),
    observacao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_contato; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_contato IS 'Contatos das pessoas';


--
-- Name: bc_cad_contato_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_contato_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_contato_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_contato_id_seq OWNED BY brasil_saas.bc_cad_contato.id;


--
-- Name: bc_cad_documento_fiscal; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_documento_fiscal (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint,
    modelo character varying(10) NOT NULL,
    serie character varying(10),
    numero character varying(20) NOT NULL,
    chave_acesso character varying(50),
    emissao_at timestamp without time zone,
    arquivo_url character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_documento_fiscal; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_documento_fiscal IS 'Documentos fiscais recebidos/emitidos vinculados à pessoa';


--
-- Name: bc_cad_documento_fiscal_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_documento_fiscal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_documento_fiscal_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_documento_fiscal_id_seq OWNED BY brasil_saas.bc_cad_documento_fiscal.id;


--
-- Name: bc_cad_endereco; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_endereco (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    tipo character varying(20) DEFAULT 'PRINCIPAL'::character varying NOT NULL,
    logradouro character varying(200),
    numero character varying(20),
    complemento character varying(100),
    bairro character varying(100),
    cep character varying(8),
    municipio_id bigint,
    uf character(2),
    latitude numeric(10,7),
    longitude numeric(10,7),
    principal boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_endereco; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_endereco IS 'Endereços das pessoas';


--
-- Name: bc_cad_endereco_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_endereco_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_endereco_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_endereco_id_seq OWNED BY brasil_saas.bc_cad_endereco.id;


--
-- Name: bc_cad_fornecedor; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_fornecedor (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    codigo character varying(30),
    prazo_medio_dias integer DEFAULT 0 NOT NULL,
    avaliacao numeric(4,2),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    logo_url text,
    logo_tipo_conteudo character varying(50),
    logo_tamanho bigint
);


--
-- Name: TABLE bc_cad_fornecedor; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_fornecedor IS 'Fornecedores';


--
-- Name: COLUMN bc_cad_fornecedor.logo_url; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_fornecedor.logo_url IS 'URL do logo do fornecedor';


--
-- Name: COLUMN bc_cad_fornecedor.logo_tipo_conteudo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_fornecedor.logo_tipo_conteudo IS 'Tipo MIME do logo do fornecedor';


--
-- Name: COLUMN bc_cad_fornecedor.logo_tamanho; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_fornecedor.logo_tamanho IS 'Tamanho em bytes do logo do fornecedor';


--
-- Name: bc_cad_fornecedor_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_fornecedor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_fornecedor_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_fornecedor_id_seq OWNED BY brasil_saas.bc_cad_fornecedor.id;


--
-- Name: bc_cad_marca; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_marca (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_marca; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_marca IS 'Marcas de produtos';


--
-- Name: bc_cad_marca_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_marca_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_marca_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_marca_id_seq OWNED BY brasil_saas.bc_cad_marca.id;


--
-- Name: bc_cad_municipio; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_municipio (
    id bigint NOT NULL,
    codigo_ibge character varying(7) NOT NULL,
    nome character varying(100) NOT NULL,
    uf character(2) NOT NULL,
    codigo_siafi character varying(10),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_municipio; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_municipio IS 'Municípios IBGE (tabela oficial, global)';


--
-- Name: bc_cad_municipio_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_municipio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_municipio_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_municipio_id_seq OWNED BY brasil_saas.bc_cad_municipio.id;


--
-- Name: bc_cad_papel; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_papel (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(50) NOT NULL,
    descricao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_papel; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_papel IS 'Papéis de relacionamento (CLIENTE, FORNECEDOR, TRANSPORTADORA...)';


--
-- Name: bc_cad_papel_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_papel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_papel_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_papel_id_seq OWNED BY brasil_saas.bc_cad_papel.id;


--
-- Name: bc_cad_pessoa; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_pessoa (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    tipo character varying(10) NOT NULL,
    nome character varying(200) NOT NULL,
    documento character varying(14),
    email character varying(150),
    telefone character varying(20),
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_pessoa; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_pessoa IS 'Pessoas físicas e jurídicas (cadastro único)';


--
-- Name: COLUMN bc_cad_pessoa.tipo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_pessoa.tipo IS 'FISICA ou JURIDICA';


--
-- Name: bc_cad_pessoa_fisica; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_pessoa_fisica (
    id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    cpf character varying(11),
    rg character varying(20),
    orgao_expedidor character varying(20),
    data_nascimento date,
    sexo character(1),
    estado_civil character varying(20),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_pessoa_fisica; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_pessoa_fisica IS 'Complemento de pessoa física';


--
-- Name: bc_cad_pessoa_fisica_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_pessoa_fisica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_pessoa_fisica_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_pessoa_fisica_id_seq OWNED BY brasil_saas.bc_cad_pessoa_fisica.id;


--
-- Name: bc_cad_pessoa_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_pessoa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_pessoa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_pessoa_id_seq OWNED BY brasil_saas.bc_cad_pessoa.id;


--
-- Name: bc_cad_pessoa_juridica; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_pessoa_juridica (
    id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    cnpj character varying(14),
    inscricao_estadual character varying(30),
    inscricao_municipal character varying(30),
    data_abertura date,
    porte character varying(20),
    natureza_juridica character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_pessoa_juridica; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_pessoa_juridica IS 'Complemento de pessoa jurídica';


--
-- Name: bc_cad_pessoa_juridica_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_pessoa_juridica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_pessoa_juridica_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_pessoa_juridica_id_seq OWNED BY brasil_saas.bc_cad_pessoa_juridica.id;


--
-- Name: bc_cad_produto; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_produto (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    codigo character varying(30) NOT NULL,
    nome character varying(200) NOT NULL,
    descricao text,
    categoria_id bigint,
    marca_id bigint,
    unidade_medida_id bigint,
    ncm character varying(8),
    cfop_padrao character varying(4),
    codigo_barras character varying(30),
    preco_custo numeric(15,4) DEFAULT 0 NOT NULL,
    preco_venda numeric(15,2) DEFAULT 0 NOT NULL,
    estoque_minimo numeric(15,3) DEFAULT 0 NOT NULL,
    estoque_maximo numeric(15,3) DEFAULT 0 NOT NULL,
    peso numeric(10,3),
    tipo character varying(20) DEFAULT 'PRODUTO'::character varying NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    url_produto character varying(500),
    cest character varying(7)
);


--
-- Name: TABLE bc_cad_produto; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_produto IS 'Produtos';


--
-- Name: COLUMN bc_cad_produto.cest; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_produto.cest IS 'CEST do produto, especificador da substituicao tributaria (7 digitos).';


--
-- Name: bc_cad_produto_ecommerce; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_produto_ecommerce (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    publicado boolean DEFAULT false NOT NULL,
    marketplace character varying(50),
    url_externa character varying(500),
    preco_marketplace numeric(15,2),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    uuid uuid NOT NULL
);


--
-- Name: TABLE bc_cad_produto_ecommerce; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_produto_ecommerce IS 'Publicação de produtos em e-commerce/marketplace';


--
-- Name: bc_cad_produto_ecommerce_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_produto_ecommerce_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_produto_ecommerce_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_produto_ecommerce_id_seq OWNED BY brasil_saas.bc_cad_produto_ecommerce.id;


--
-- Name: bc_cad_produto_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_produto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_produto_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_produto_id_seq OWNED BY brasil_saas.bc_cad_produto.id;


--
-- Name: bc_cad_produto_imagem; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_produto_imagem (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    url character varying(500) NOT NULL,
    ordem integer DEFAULT 0 NOT NULL,
    principal boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_produto_imagem; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_produto_imagem IS 'Imagens de produtos';


--
-- Name: bc_cad_produto_imagem_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_produto_imagem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_produto_imagem_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_produto_imagem_id_seq OWNED BY brasil_saas.bc_cad_produto_imagem.id;


--
-- Name: bc_cad_produto_kit; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_produto_kit (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    kit_id bigint NOT NULL,
    item_id bigint NOT NULL,
    quantidade numeric(15,3) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by bigint
);


--
-- Name: TABLE bc_cad_produto_kit; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_produto_kit IS 'Composição de kits';


--
-- Name: bc_cad_produto_kit_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_produto_kit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_produto_kit_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_produto_kit_id_seq OWNED BY brasil_saas.bc_cad_produto_kit.id;


--
-- Name: bc_cad_produto_variacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_produto_variacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    sku character varying(50),
    codigo_barras character varying(30),
    preco numeric(15,2),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_produto_variacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_produto_variacao IS 'Variações de produto (cor, tamanho...)';


--
-- Name: bc_cad_produto_variacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_produto_variacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_produto_variacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_produto_variacao_id_seq OWNED BY brasil_saas.bc_cad_produto_variacao.id;


--
-- Name: bc_cad_servico; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_servico (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    codigo character varying(30) NOT NULL,
    nome character varying(200) NOT NULL,
    descricao text,
    lc116_codigo character varying(10),
    nbs character varying(12),
    aliquota_iss numeric(7,4) DEFAULT 0 NOT NULL,
    preco numeric(15,2) DEFAULT 0 NOT NULL,
    unidade_medida_id bigint,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    codigo_tributacao_municipal character varying(10)
);


--
-- Name: TABLE bc_cad_servico; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_servico IS 'Serviços ( NFS-e )';


--
-- Name: COLUMN bc_cad_servico.codigo_tributacao_municipal; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_cad_servico.codigo_tributacao_municipal IS 'Codigo de servico da Tabela de Servicos da Prefeitura de Sao Paulo (4 digitos). Ex.: 2919 = suporte tecnico em informatica (LC 116 01.07). Usado na emissao de NFS-e.';


--
-- Name: bc_cad_servico_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_servico_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_servico_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_servico_id_seq OWNED BY brasil_saas.bc_cad_servico.id;


--
-- Name: bc_cad_transportadora; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_transportadora (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    codigo character varying(30),
    registro_antt character varying(30),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_transportadora; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_transportadora IS 'Transportadoras';


--
-- Name: bc_cad_transportadora_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_transportadora_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_transportadora_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_transportadora_id_seq OWNED BY brasil_saas.bc_cad_transportadora.id;


--
-- Name: bc_cad_unidade_medida; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_cad_unidade_medida (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    sigla character varying(10) NOT NULL,
    nome character varying(50) NOT NULL,
    tipo character varying(20) DEFAULT 'UNIDADE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_cad_unidade_medida; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_cad_unidade_medida IS 'Unidades de medida';


--
-- Name: bc_cad_unidade_medida_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_cad_unidade_medida_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_cad_unidade_medida_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_cad_unidade_medida_id_seq OWNED BY brasil_saas.bc_cad_unidade_medida.id;


--
-- Name: bc_com_conferencia_fatura; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_conferencia_fatura (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    pedido_id bigint NOT NULL,
    recebimento_id bigint,
    titulo_id bigint,
    valor_pedido numeric(15,2) DEFAULT 0 NOT NULL,
    valor_recebido numeric(15,2) DEFAULT 0 NOT NULL,
    valor_fatura numeric(15,2) DEFAULT 0 NOT NULL,
    tolerancia numeric(7,4) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    divergencia text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    nfe_id bigint
);


--
-- Name: TABLE bc_com_conferencia_fatura; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_com_conferencia_fatura IS 'Conferencia tripla pedido, recebimento e titulo';


--
-- Name: COLUMN bc_com_conferencia_fatura.nfe_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_com_conferencia_fatura.nfe_id IS 'NF-e de entrada vinculada à conferência 3-way';


--
-- Name: bc_com_conferencia_fatura_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_conferencia_fatura_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_conferencia_fatura_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_conferencia_fatura_id_seq OWNED BY brasil_saas.bc_com_conferencia_fatura.id;


--
-- Name: bc_com_contrato; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_contrato (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    fornecedor_id bigint NOT NULL,
    numero character varying(30) NOT NULL,
    descricao character varying(255),
    data_inicio date NOT NULL,
    data_fim date,
    valor_limite numeric(15,2),
    valor_utilizado numeric(15,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    renovacao_automatica boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_com_contrato; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_com_contrato IS 'Contratos de fornecimento';


--
-- Name: bc_com_contrato_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_contrato_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_contrato_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_contrato_id_seq OWNED BY brasil_saas.bc_com_contrato.id;


--
-- Name: bc_com_cotacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_cotacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    solicitacao_id bigint,
    numero character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    data_abertura date DEFAULT CURRENT_DATE NOT NULL,
    data_limite date,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_com_cotacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_com_cotacao IS 'Cotacoes de compra';


--
-- Name: bc_com_cotacao_fornecedor; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_cotacao_fornecedor (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    cotacao_id bigint NOT NULL,
    fornecedor_id bigint NOT NULL,
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    prazo_entrega integer,
    condicao_pagamento_id bigint,
    frete numeric(15,2) DEFAULT 0,
    desconto numeric(15,2) DEFAULT 0,
    valor_total numeric(15,2) DEFAULT 0,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_com_cotacao_fornecedor_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_cotacao_fornecedor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_cotacao_fornecedor_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_cotacao_fornecedor_id_seq OWNED BY brasil_saas.bc_com_cotacao_fornecedor.id;


--
-- Name: bc_com_cotacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_cotacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_cotacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_cotacao_id_seq OWNED BY brasil_saas.bc_com_cotacao.id;


--
-- Name: bc_com_cotacao_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_cotacao_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    cotacao_fornecedor_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    valor_unitario numeric(15,4) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_com_cotacao_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_cotacao_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_cotacao_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_cotacao_item_id_seq OWNED BY brasil_saas.bc_com_cotacao_item.id;


--
-- Name: bc_com_pedido; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_pedido (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    fornecedor_id bigint NOT NULL,
    numero character varying(20),
    status character varying(255) DEFAULT 'ABERTO'::character varying NOT NULL,
    condicao_pagamento_id bigint,
    data_emissao date NOT NULL,
    data_previsao_entrega date,
    valor_produtos numeric(15,2) DEFAULT 0 NOT NULL,
    valor_desconto numeric(15,2) DEFAULT 0 NOT NULL,
    valor_frete numeric(15,2) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    titulo_id bigint,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_com_pedido; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_com_pedido IS 'Pedidos de compra';


--
-- Name: COLUMN bc_com_pedido.status; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_com_pedido.status IS 'ABERTO, RECEBIDO ou CANCELADO';


--
-- Name: COLUMN bc_com_pedido.titulo_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_com_pedido.titulo_id IS 'Título a pagar gerado no financeiro';


--
-- Name: bc_com_pedido_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_pedido_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_pedido_id_seq OWNED BY brasil_saas.bc_com_pedido.id;


--
-- Name: bc_com_pedido_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_pedido_item (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    pedido_id bigint NOT NULL,
    numero_item integer NOT NULL,
    produto_id bigint,
    descricao character varying(300),
    quantidade numeric(15,3) NOT NULL,
    unidade character varying(10),
    valor_unitario numeric(15,4) NOT NULL,
    valor_desconto numeric(15,2) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    criado_estoque boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    quantidade_recebida numeric(15,3) DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN bc_com_pedido_item.quantidade_recebida; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_com_pedido_item.quantidade_recebida IS 'Quantidade fisicamente recebida e conferida do item do pedido';


--
-- Name: bc_com_pedido_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_pedido_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_pedido_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_pedido_item_id_seq OWNED BY brasil_saas.bc_com_pedido_item.id;


--
-- Name: bc_com_recebimento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_recebimento (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    pedido_id bigint,
    numero character varying(30) NOT NULL,
    data_recebimento date DEFAULT CURRENT_DATE NOT NULL,
    status character varying(20) DEFAULT 'CONFERENCIA'::character varying NOT NULL,
    documento_fornecedor character varying(50),
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_com_recebimento; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_com_recebimento IS 'Recebimentos/conferencia de compras';


--
-- Name: COLUMN bc_com_recebimento.documento_fornecedor; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_com_recebimento.documento_fornecedor IS 'Numero do documento fiscal ou documento de entrada informado pelo fornecedor';


--
-- Name: bc_com_recebimento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_recebimento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_recebimento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_recebimento_id_seq OWNED BY brasil_saas.bc_com_recebimento.id;


--
-- Name: bc_com_recebimento_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_recebimento_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    recebimento_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade_pedida numeric(15,4) DEFAULT 0 NOT NULL,
    quantidade_recebida numeric(15,4) DEFAULT 0 NOT NULL,
    valor_unitario numeric(15,4) DEFAULT 0 NOT NULL,
    lote_id bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_com_recebimento_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_recebimento_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_recebimento_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_recebimento_item_id_seq OWNED BY brasil_saas.bc_com_recebimento_item.id;


--
-- Name: bc_com_solicitacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_solicitacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    solicitante_id bigint,
    numero character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    data_solicitacao date DEFAULT CURRENT_DATE NOT NULL,
    data_necessidade date,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_com_solicitacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_com_solicitacao IS 'Solicitacoes internas de compra';


--
-- Name: bc_com_solicitacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_solicitacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_solicitacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_solicitacao_id_seq OWNED BY brasil_saas.bc_com_solicitacao.id;


--
-- Name: bc_com_solicitacao_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_com_solicitacao_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    solicitacao_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    observacao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_com_solicitacao_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_com_solicitacao_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_com_solicitacao_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_com_solicitacao_item_id_seq OWNED BY brasil_saas.bc_com_solicitacao_item.id;


--
-- Name: bc_core_auditoria; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_auditoria (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    usuario_id bigint,
    tabela character varying(80) NOT NULL,
    registro_id bigint,
    operacao character varying(10) NOT NULL,
    antes jsonb,
    depois jsonb,
    ip character varying(45),
    user_agent character varying(300),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_core_auditoria; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_auditoria IS 'Trilha de auditoria de operações sensíveis';


--
-- Name: bc_core_auditoria_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_auditoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_auditoria_id_seq OWNED BY brasil_saas.bc_core_auditoria.id;


--
-- Name: bc_core_banco; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_banco (
    compe character varying(10) NOT NULL,
    ispb character varying(20),
    cnpj character varying(20),
    nome character varying(200) NOT NULL,
    nome_curto character varying(100),
    tipo character varying(60),
    aceita_pix boolean DEFAULT false NOT NULL,
    ativo boolean DEFAULT true NOT NULL
);


--
-- Name: bc_core_configuracao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_configuracao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    chave character varying(100) NOT NULL,
    valor text,
    descricao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_core_configuracao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_configuracao IS 'Configurações por empresa (chave/valor)';


--
-- Name: bc_core_configuracao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_configuracao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_configuracao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_configuracao_id_seq OWNED BY brasil_saas.bc_core_configuracao.id;


--
-- Name: bc_core_empresa; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_empresa (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    razao_social character varying(200) NOT NULL,
    nome_fantasia character varying(200),
    cnpj character varying(14) NOT NULL,
    inscricao_estadual character varying(30),
    inscricao_municipal character varying(30),
    regime_tributario character varying(20) DEFAULT 'SIMPLES_NACIONAL'::character varying NOT NULL,
    codigo_ibge character varying(7),
    endereco character varying(200),
    numero character varying(20),
    complemento character varying(100),
    bairro character varying(100),
    cep character varying(8),
    uf character(2),
    telefone character varying(20),
    email character varying(150),
    logo_url text,
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    logo_tipo_conteudo character varying(50),
    logo_tamanho bigint,
    matriz boolean,
    grupo_cnpj_cpf character varying(20),
    matriz_id bigint,
    tipo_pessoa character varying(20),
    CONSTRAINT ck_matriz_nao_aponta_para_matriz CHECK ((NOT ((matriz IS TRUE) AND (matriz_id IS NOT NULL))))
);


--
-- Name: TABLE bc_core_empresa; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_empresa IS 'Empresas (raiz do multi-tenant)';


--
-- Name: COLUMN bc_core_empresa.logo_url; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.logo_url IS 'URL do logo da empresa para relatórios, NF-e e OS';


--
-- Name: COLUMN bc_core_empresa.logo_tipo_conteudo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.logo_tipo_conteudo IS 'Tipo MIME do logo da empresa';


--
-- Name: COLUMN bc_core_empresa.logo_tamanho; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.logo_tamanho IS 'Tamanho em bytes do logo da empresa';


--
-- Name: COLUMN bc_core_empresa.matriz; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.matriz IS 'true quando esta empresa e'' a matriz do grupo. Uma por grupo, garantido pelo indice parcial unico em grupo_cnpj_cpf.';


--
-- Name: COLUMN bc_core_empresa.grupo_cnpj_cpf; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.grupo_cnpj_cpf IS 'A chave do grupo empresarial: CPF para produtor rural, CNPJ para empresa comum. E'' a coluna que separa uma empresa que a outra.';


--
-- Name: COLUMN bc_core_empresa.matriz_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.matriz_id IS 'A matriz do grupo desta filial. NULL na propria matriz. A constraint abaixo garante que a empresa apontada e'' de verdade a matriz do mesmo grupo.';


--
-- Name: COLUMN bc_core_empresa.tipo_pessoa; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_empresa.tipo_pessoa IS 'PF para produtor rural, PJ para empresa. Determina se a chave do grupo e'' CPF ou CNPJ.';


--
-- Name: bc_core_empresa_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_empresa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_empresa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_empresa_id_seq OWNED BY brasil_saas.bc_core_empresa.id;


--
-- Name: bc_core_empresa_vinculo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_empresa_vinculo (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    empresa_vinculada_id bigint NOT NULL,
    tipo character varying(30) NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_core_empresa_vinculo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_empresa_vinculo IS 'Vínculos entre empresas (matriz/filial, contador, parceira)';


--
-- Name: bc_core_empresa_vinculo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_empresa_vinculo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_empresa_vinculo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_empresa_vinculo_id_seq OWNED BY brasil_saas.bc_core_empresa_vinculo.id;


--
-- Name: bc_core_log_acesso; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_log_acesso (
    id bigint NOT NULL,
    empresa_id bigint,
    usuario_id bigint,
    username character varying(50),
    ip character varying(45),
    user_agent character varying(300),
    sucesso boolean NOT NULL,
    motivo character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_core_log_acesso; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_log_acesso IS 'Log de tentativas de login/acesso';


--
-- Name: bc_core_log_acesso_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_log_acesso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_log_acesso_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_log_acesso_id_seq OWNED BY brasil_saas.bc_core_log_acesso.id;


--
-- Name: bc_core_modulo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_modulo (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    chave character varying(30) NOT NULL,
    nome character varying(100) NOT NULL,
    descricao character varying(255),
    icone character varying(50),
    rota character varying(100),
    ordem integer DEFAULT 100 NOT NULL,
    exige_superuser boolean DEFAULT false NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_core_modulo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_modulo IS 'Modulos do ERP. A coluna exige_superuser marca os quelidam documento/certificado e exigem SUPERUSER.';


--
-- Name: bc_core_modulo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_modulo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_modulo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_modulo_id_seq OWNED BY brasil_saas.bc_core_modulo.id;


--
-- Name: bc_core_notificacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_notificacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    usuario_id bigint NOT NULL,
    titulo character varying(150) NOT NULL,
    mensagem text NOT NULL,
    tipo character varying(30) DEFAULT 'INFO'::character varying NOT NULL,
    lida boolean DEFAULT false NOT NULL,
    lida_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_core_notificacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_notificacao IS 'Notificações para usuários';


--
-- Name: bc_core_notificacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_notificacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_notificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_notificacao_id_seq OWNED BY brasil_saas.bc_core_notificacao.id;


--
-- Name: bc_core_perfil; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_perfil (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(50) NOT NULL,
    descricao character varying(255),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    hierarquia_nivel integer,
    perfil_pai_id bigint,
    CONSTRAINT ck_bc_core_perfil_pai_nao_self CHECK (((perfil_pai_id IS NULL) OR (perfil_pai_id <> id)))
);


--
-- Name: TABLE bc_core_perfil; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_perfil IS 'Perfil de acesso. SUPERUSER opera o gerenciador SQL; enquanto a separacao nao for avaliada, SUPERUSER e ADMIN tem as mesmas permissoes.';


--
-- Name: COLUMN bc_core_perfil.hierarquia_nivel; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_perfil.hierarquia_nivel IS 'Nível hierárquico do perfil (usado para ordenação e permissões em cascata)';


--
-- Name: COLUMN bc_core_perfil.perfil_pai_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_perfil.perfil_pai_id IS 'Perfil pai do qual este perfil herda permissões efetivas';


--
-- Name: bc_core_perfil_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_perfil_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_perfil_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_perfil_id_seq OWNED BY brasil_saas.bc_core_perfil.id;


--
-- Name: bc_core_perfil_permissao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_perfil_permissao (
    id bigint NOT NULL,
    perfil_id bigint NOT NULL,
    permissao_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by bigint
);


--
-- Name: TABLE bc_core_perfil_permissao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_perfil_permissao IS 'Associação perfil ↔ permissão';


--
-- Name: bc_core_perfil_permissao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_perfil_permissao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_perfil_permissao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_perfil_permissao_id_seq OWNED BY brasil_saas.bc_core_perfil_permissao.id;


--
-- Name: bc_core_permissao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_permissao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo character varying(80) NOT NULL,
    recurso character varying(50) NOT NULL,
    acao character varying(20) NOT NULL,
    descricao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_core_permissao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_permissao IS 'Permissões por recurso/ação (ex.: CADASTRO_CLIENTE_CRIAR)';


--
-- Name: bc_core_permissao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_permissao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_permissao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_permissao_id_seq OWNED BY brasil_saas.bc_core_permissao.id;


--
-- Name: bc_core_sessao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_sessao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    usuario_id bigint NOT NULL,
    token_hash character varying(255) NOT NULL,
    refresh_token_hash character varying(255),
    ip character varying(45),
    user_agent character varying(300),
    expira_at timestamp without time zone NOT NULL,
    revogada_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_core_sessao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_sessao IS 'Sessões JWT ativas/revogadas';


--
-- Name: bc_core_sessao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_sessao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_sessao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_sessao_id_seq OWNED BY brasil_saas.bc_core_sessao.id;


--
-- Name: bc_core_usuario; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_usuario (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint,
    nome character varying(150) NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(150) NOT NULL,
    senha_hash character varying(255) NOT NULL,
    cpf character varying(11),
    telefone character varying(20),
    ativo boolean DEFAULT true NOT NULL,
    mfa_habilitado boolean DEFAULT false NOT NULL,
    mfa_secret character varying(100),
    ultimo_login_at timestamp without time zone,
    tentativas_login integer DEFAULT 0 NOT NULL,
    bloqueado_ate timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    foto_url text,
    foto_tipo_conteudo character varying(50),
    foto_tamanho bigint
);


--
-- Name: TABLE bc_core_usuario; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_usuario IS 'Usuários do sistema';


--
-- Name: COLUMN bc_core_usuario.empresa_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_usuario.empresa_id IS 'Empresa do usuario. NULL significa que ele ainda nao cadastrou a sua: o sistema so libera o resto depois do cadastro da empresa.';


--
-- Name: COLUMN bc_core_usuario.senha_hash; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_usuario.senha_hash IS 'BCrypt hash — nunca armazenar senha em texto';


--
-- Name: COLUMN bc_core_usuario.foto_url; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_usuario.foto_url IS 'URL da foto do usuário para perfil';


--
-- Name: COLUMN bc_core_usuario.foto_tipo_conteudo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_usuario.foto_tipo_conteudo IS 'Tipo MIME da foto do usuário';


--
-- Name: COLUMN bc_core_usuario.foto_tamanho; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_core_usuario.foto_tamanho IS 'Tamanho em bytes da foto do usuário';


--
-- Name: bc_core_usuario_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_usuario_id_seq OWNED BY brasil_saas.bc_core_usuario.id;


--
-- Name: bc_core_usuario_modulo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_usuario_modulo (
    id bigint NOT NULL,
    usuario_id bigint NOT NULL,
    modulo_id bigint NOT NULL,
    somente_leitura boolean DEFAULT false NOT NULL,
    criado_em timestamp without time zone DEFAULT now() NOT NULL,
    criado_por bigint
);


--
-- Name: TABLE bc_core_usuario_modulo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_usuario_modulo IS 'Modulos liberados por usuario. many-to-many: permite Financeiro + Estoque sem criar perfil novo.';


--
-- Name: bc_core_usuario_modulo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_usuario_modulo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_usuario_modulo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_usuario_modulo_id_seq OWNED BY brasil_saas.bc_core_usuario_modulo.id;


--
-- Name: bc_core_usuario_perfil; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_core_usuario_perfil (
    id bigint NOT NULL,
    usuario_id bigint NOT NULL,
    perfil_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by bigint
);


--
-- Name: TABLE bc_core_usuario_perfil; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_core_usuario_perfil IS 'Associação usuário ↔ perfil';


--
-- Name: bc_core_usuario_perfil_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_core_usuario_perfil_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_core_usuario_perfil_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_core_usuario_perfil_id_seq OWNED BY brasil_saas.bc_core_usuario_perfil.id;


--
-- Name: bc_crm_atividade; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_crm_atividade (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    oportunidade_id bigint,
    cliente_id bigint,
    vendedor_id bigint,
    tipo character varying(30) NOT NULL,
    assunto character varying(150) NOT NULL,
    data_agendada timestamp without time zone,
    data_conclusao timestamp without time zone,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    resultado text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_crm_atividade; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_crm_atividade IS 'Atividades comerciais e follow-up';


--
-- Name: bc_crm_atividade_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_crm_atividade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_crm_atividade_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_crm_atividade_id_seq OWNED BY brasil_saas.bc_crm_atividade.id;


--
-- Name: bc_crm_oportunidade; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_crm_oportunidade (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    cliente_id bigint,
    vendedor_id bigint,
    titulo character varying(150) NOT NULL,
    etapa character varying(30) DEFAULT 'PROSPECCAO'::character varying NOT NULL,
    origem character varying(50),
    valor_estimado numeric(15,2),
    probabilidade numeric(5,2),
    data_prevista_fechamento date,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_crm_oportunidade; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_crm_oportunidade IS 'Pipeline comercial/CRM';


--
-- Name: bc_crm_oportunidade_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_crm_oportunidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_crm_oportunidade_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_crm_oportunidade_id_seq OWNED BY brasil_saas.bc_crm_oportunidade.id;


--
-- Name: bc_est_deposito; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_deposito (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    codigo character varying(30) NOT NULL,
    nome character varying(100) NOT NULL,
    tipo character varying(30) DEFAULT 'PADRAO'::character varying NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_est_deposito; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_deposito IS 'Depositos/almoxarifados por empresa';


--
-- Name: bc_est_deposito_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_deposito_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_deposito_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_deposito_id_seq OWNED BY brasil_saas.bc_est_deposito.id;


--
-- Name: bc_est_endereco; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_endereco (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    deposito_id bigint NOT NULL,
    codigo character varying(50) NOT NULL,
    descricao character varying(150),
    tipo character varying(30) DEFAULT 'PULMAO'::character varying NOT NULL,
    capacidade numeric(15,4),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_est_endereco; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_endereco IS 'Enderecamento fisico de estoque';


--
-- Name: bc_est_endereco_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_endereco_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_endereco_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_endereco_id_seq OWNED BY brasil_saas.bc_est_endereco.id;


--
-- Name: bc_est_expedicao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_expedicao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    pedido_venda_id bigint NOT NULL,
    deposito_id bigint NOT NULL,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    transportadora_id bigint,
    codigo_rastreio character varying(120),
    data_abertura timestamp without time zone DEFAULT now() NOT NULL,
    data_separacao timestamp without time zone,
    data_embalagem timestamp without time zone,
    data_expedicao timestamp without time zone,
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_est_expedicao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_expedicao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_expedicao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_expedicao_id_seq OWNED BY brasil_saas.bc_est_expedicao.id;


--
-- Name: bc_est_expedicao_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_expedicao_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    expedicao_id bigint NOT NULL,
    reserva_id bigint,
    produto_id bigint NOT NULL,
    quantidade numeric(15,3) NOT NULL,
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    lote_id bigint,
    endereco_id bigint,
    CONSTRAINT bc_est_expedicao_item_quantidade_check CHECK ((quantidade > (0)::numeric))
);


--
-- Name: bc_est_expedicao_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_expedicao_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_expedicao_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_expedicao_item_id_seq OWNED BY brasil_saas.bc_est_expedicao_item.id;


--
-- Name: bc_est_inventario; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_inventario (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    deposito_id bigint NOT NULL,
    status character varying(20) DEFAULT 'ABERTO'::character varying NOT NULL,
    data_contagem timestamp without time zone DEFAULT now() NOT NULL,
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_est_inventario_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_inventario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_inventario_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_inventario_id_seq OWNED BY brasil_saas.bc_est_inventario.id;


--
-- Name: bc_est_inventario_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_inventario_item (
    id bigint NOT NULL,
    inventario_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    lote_id bigint,
    endereco_id bigint,
    quantidade_sistema numeric(15,3) DEFAULT 0 NOT NULL,
    quantidade_contada numeric(15,3) DEFAULT 0 NOT NULL,
    diferenca numeric(15,3) DEFAULT 0 NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: bc_est_inventario_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_inventario_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_inventario_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_inventario_item_id_seq OWNED BY brasil_saas.bc_est_inventario_item.id;


--
-- Name: bc_est_lote; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_lote (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    codigo character varying(80) NOT NULL,
    data_fabricacao date,
    data_validade date,
    quantidade numeric(15,4) DEFAULT 0 NOT NULL,
    deposito_id bigint,
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    CONSTRAINT ck_est_lote_quantidade_nao_negativa CHECK ((quantidade >= (0)::numeric))
);


--
-- Name: TABLE bc_est_lote; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_lote IS 'Lotes com validade e rastreabilidade';


--
-- Name: bc_est_lote_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_lote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_lote_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_lote_id_seq OWNED BY brasil_saas.bc_est_lote.id;


--
-- Name: bc_est_movimentacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_movimentacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    tipo character varying(255) NOT NULL,
    origem character varying(255),
    origem_id bigint,
    quantidade numeric(15,3) NOT NULL,
    saldo_apos numeric(15,3),
    data_movimento timestamp without time zone DEFAULT now() NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    deposito_id bigint,
    endereco_id bigint,
    lote_id bigint
);


--
-- Name: TABLE bc_est_movimentacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_movimentacao IS 'Movimentações de estoque';


--
-- Name: COLUMN bc_est_movimentacao.tipo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_est_movimentacao.tipo IS 'ENTRADA, SAIDA ou AJUSTE';


--
-- Name: COLUMN bc_est_movimentacao.origem; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_est_movimentacao.origem IS 'VENDA, COMPRA ou MANUAL';


--
-- Name: bc_est_movimentacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_movimentacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_movimentacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_movimentacao_id_seq OWNED BY brasil_saas.bc_est_movimentacao.id;


--
-- Name: bc_est_reserva; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_reserva (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    deposito_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    pedido_venda_id bigint,
    quantidade numeric(15,4) NOT NULL,
    status character varying(20) DEFAULT 'RESERVADA'::character varying NOT NULL,
    data_reserva timestamp without time zone DEFAULT now() NOT NULL,
    data_expiracao timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    lote_id bigint,
    endereco_id bigint
);


--
-- Name: TABLE bc_est_reserva; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_reserva IS 'Reservas de estoque para operacoes comerciais';


--
-- Name: COLUMN bc_est_reserva.lote_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_est_reserva.lote_id IS 'Lote fisico reservado; permite rastreabilidade e separacao por FEFO';


--
-- Name: bc_est_reserva_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_reserva_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_reserva_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_reserva_id_seq OWNED BY brasil_saas.bc_est_reserva.id;


--
-- Name: bc_est_saldo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_saldo (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade numeric(15,3) DEFAULT 0 NOT NULL,
    atualizado_em timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp without time zone,
    deposito_id bigint NOT NULL
);


--
-- Name: TABLE bc_est_saldo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_saldo IS 'Saldo de estoque por produto e empresa';


--
-- Name: bc_est_saldo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_saldo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_saldo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_saldo_id_seq OWNED BY brasil_saas.bc_est_saldo.id;


--
-- Name: bc_est_serie; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_serie (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    numero_serie character varying(100) NOT NULL,
    lote_id bigint,
    deposito_id bigint,
    status character varying(20) DEFAULT 'DISPONIVEL'::character varying NOT NULL,
    data_entrada date,
    data_saida date,
    origem character varying(30),
    origem_id bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_est_serie; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_est_serie IS 'Numeros de serie e rastreabilidade unitaria';


--
-- Name: bc_est_serie_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_serie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_serie_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_serie_id_seq OWNED BY brasil_saas.bc_est_serie.id;


--
-- Name: bc_est_transferencia; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_transferencia (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    deposito_origem_id bigint NOT NULL,
    deposito_destino_id bigint NOT NULL,
    status character varying(20) DEFAULT 'CONCLUIDA'::character varying NOT NULL,
    data_transferencia timestamp without time zone DEFAULT now() NOT NULL,
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    tipo character varying(30) DEFAULT 'DEPOSITO'::character varying NOT NULL,
    CONSTRAINT ck_est_transferencia_depositos CHECK ((deposito_origem_id <> deposito_destino_id))
);


--
-- Name: bc_est_transferencia_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_transferencia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_transferencia_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_transferencia_id_seq OWNED BY brasil_saas.bc_est_transferencia.id;


--
-- Name: bc_est_transferencia_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_est_transferencia_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    transferencia_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade numeric(15,3) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    lote_id bigint,
    endereco_origem_id bigint,
    endereco_destino_id bigint,
    CONSTRAINT bc_est_transferencia_item_quantidade_check CHECK ((quantidade > (0)::numeric))
);


--
-- Name: bc_est_transferencia_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_est_transferencia_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_est_transferencia_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_est_transferencia_item_id_seq OWNED BY brasil_saas.bc_est_transferencia_item.id;


--
-- Name: bc_fin_analise_rentabilidade; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_analise_rentabilidade (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    centro_custo_id bigint,
    periodo character varying(20) NOT NULL,
    receita numeric(15,2) DEFAULT 0.00,
    despesa numeric(15,2) DEFAULT 0.00,
    margem_lucro numeric(15,4) DEFAULT 0.00,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_analise_rentabilidade_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_analise_rentabilidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_analise_rentabilidade_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_analise_rentabilidade_id_seq OWNED BY brasil_saas.bc_fin_analise_rentabilidade.id;


--
-- Name: bc_fin_aplicacao_financeira; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_aplicacao_financeira (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conta_bancaria_id bigint,
    descricao character varying(100) NOT NULL,
    valor_aplicado numeric(15,2) NOT NULL,
    taxa_juros numeric(10,4),
    data_aplicacao date NOT NULL,
    data_resgate date,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_aplicacao_financeira_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_aplicacao_financeira_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_aplicacao_financeira_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_aplicacao_financeira_id_seq OWNED BY brasil_saas.bc_fin_aplicacao_financeira.id;


--
-- Name: bc_fin_aprovacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_aprovacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    titulo_id bigint NOT NULL,
    fluxo_aprovacao_id bigint,
    usuario_aprovador_id bigint,
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    data_aprovacao timestamp without time zone,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    tipo_documento character varying(30) DEFAULT 'TITULO'::character varying NOT NULL,
    documento_id bigint,
    nivel integer DEFAULT 1 NOT NULL,
    usuario_solicitante_id bigint,
    data_solicitacao timestamp without time zone,
    data_rejeicao timestamp without time zone,
    numero_documento character varying(60)
);


--
-- Name: COLUMN bc_fin_aprovacao.status; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_aprovacao.status IS 'PENDENTE | APROVADO | REJEITADO | CANCELADO';


--
-- Name: COLUMN bc_fin_aprovacao.tipo_documento; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_aprovacao.tipo_documento IS 'Domínio do documento aprovado: TITULO, COMPRA, VENDA etc.';


--
-- Name: COLUMN bc_fin_aprovacao.documento_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_aprovacao.documento_id IS 'Id genérico do documento no domínio (para workflow transversal).';


--
-- Name: COLUMN bc_fin_aprovacao.nivel; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_aprovacao.nivel IS 'Nível sequencial dentro do fluxo (aprovação multinível).';


--
-- Name: COLUMN bc_fin_aprovacao.numero_documento; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_aprovacao.numero_documento IS 'Número do documento aprovado (snapshot no momento da solicitação).';


--
-- Name: bc_fin_aprovacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_aprovacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_aprovacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_aprovacao_id_seq OWNED BY brasil_saas.bc_fin_aprovacao.id;


--
-- Name: bc_fin_baixa; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_baixa (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    titulo_id bigint NOT NULL,
    parcela_id bigint,
    conta_bancaria_id bigint,
    tipo_pagamento_id bigint,
    data_baixa date NOT NULL,
    valor_baixa numeric(15,2) NOT NULL,
    valor_desconto numeric(15,2) DEFAULT 0.00,
    valor_juro numeric(15,2) DEFAULT 0.00,
    valor_multa numeric(15,2) DEFAULT 0.00,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_baixa; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_baixa IS 'Baixas financeiras (pagamentos e recebimentos)';


--
-- Name: bc_fin_baixa_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_baixa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_baixa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_baixa_id_seq OWNED BY brasil_saas.bc_fin_baixa.id;


--
-- Name: bc_fin_boleto; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_boleto (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    titulo_id bigint,
    nosso_numero character varying(50),
    numero_documento character varying(50),
    banco character varying(10) NOT NULL,
    agencia character varying(10),
    conta character varying(20),
    digito_agencia character varying(2),
    digito_conta character varying(2),
    valor numeric(15,2) NOT NULL,
    vencimento date NOT NULL,
    nosso_numero_base character varying(50),
    especie_documento character varying(4),
    especie_moeda character varying(4),
    aceite character varying(2),
    codigo_moeda character varying(4),
    uso_boleto character varying(2),
    especie_vencimento character varying(2),
    documento_id character varying(64),
    documento_hash character varying(64),
    status character varying(20) DEFAULT 'EMITIDO'::character varying NOT NULL,
    criado_por bigint,
    criado_em timestamp without time zone DEFAULT now() NOT NULL,
    atualizado_em timestamp without time zone,
    nosso_numero_chave character varying(50),
    CONSTRAINT ck_fin_boleto_status CHECK (((status)::text = ANY (ARRAY[('EMITIDO'::character varying)::text, ('PAGO'::character varying)::text, ('CANCELADO'::character varying)::text, ('VENCIDO'::character varying)::text]))),
    CONSTRAINT ck_fin_boleto_valor CHECK ((valor > (0)::numeric))
);


--
-- Name: TABLE bc_fin_boleto; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_boleto IS 'Boleto emitido via boleto_cnab_api. documento_id aponta para a colecao "documentos" do Mongo.';


--
-- Name: COLUMN bc_fin_boleto.documento_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_boleto.documento_id IS 'Id do documento no Mongo (colecao "documentos"); nao e caminho de arquivo.';


--
-- Name: bc_fin_boleto_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_boleto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_boleto_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_boleto_id_seq OWNED BY brasil_saas.bc_fin_boleto.id;


--
-- Name: bc_fin_caixa; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_caixa (
    id bigint NOT NULL,
    uuid uuid NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    saldo numeric(15,2) DEFAULT 0.00 NOT NULL,
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_caixa; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_caixa IS 'Caixas do modulo financeiro. Tela /financeiro/caixa.';


--
-- Name: COLUMN bc_fin_caixa.saldo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_caixa.saldo IS 'Saldo atual. Mantido aqui para consulta rapida; a origem do movimento e o extrato.';


--
-- Name: bc_fin_caixa_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_caixa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_caixa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_caixa_id_seq OWNED BY brasil_saas.bc_fin_caixa.id;


--
-- Name: bc_fin_centro_custo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_centro_custo (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    codigo character varying(50) NOT NULL,
    descricao character varying(255) NOT NULL,
    centro_custo_pai_id bigint,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_centro_custo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_centro_custo IS 'Centros de custo para rateio e análise';


--
-- Name: bc_fin_centro_custo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_centro_custo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_centro_custo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_centro_custo_id_seq OWNED BY brasil_saas.bc_fin_centro_custo.id;


--
-- Name: bc_fin_comissao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_comissao (
    id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    deleted_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    uuid uuid NOT NULL,
    empresa_id bigint NOT NULL,
    data_pagamento timestamp(6) without time zone,
    funcionario_id bigint NOT NULL,
    pedido_id bigint NOT NULL,
    percentual_comissao numeric(5,2) NOT NULL,
    status character varying(20) NOT NULL,
    valor_comissao numeric(15,2) NOT NULL,
    valor_venda numeric(15,2) NOT NULL
);


--
-- Name: bc_fin_comissao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

ALTER TABLE brasil_saas.bc_fin_comissao ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME brasil_saas.bc_fin_comissao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bc_fin_conciliacao_bancaria; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_conciliacao_bancaria (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conta_bancaria_id bigint NOT NULL,
    data_inicio date NOT NULL,
    data_fim date NOT NULL,
    status character varying(20) DEFAULT 'EM_ABERTO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_conciliacao_bancaria_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_conciliacao_bancaria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_conciliacao_bancaria_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_conciliacao_bancaria_id_seq OWNED BY brasil_saas.bc_fin_conciliacao_bancaria.id;


--
-- Name: bc_fin_conciliacao_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_conciliacao_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conciliacao_id bigint NOT NULL,
    extrato_id bigint NOT NULL,
    baixa_id bigint,
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_conciliacao_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_conciliacao_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_conciliacao_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_conciliacao_item_id_seq OWNED BY brasil_saas.bc_fin_conciliacao_item.id;


--
-- Name: bc_fin_condicao_pagamento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_condicao_pagamento (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    descricao character varying(100) NOT NULL,
    dias text,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_condicao_pagamento; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_condicao_pagamento IS 'Condições de pagamento (prazos)';


--
-- Name: bc_fin_condicao_pagamento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_condicao_pagamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_condicao_pagamento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_condicao_pagamento_id_seq OWNED BY brasil_saas.bc_fin_condicao_pagamento.id;


--
-- Name: bc_fin_conta_bancaria; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_conta_bancaria (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    banco character varying(100) NOT NULL,
    agencia character varying(20) NOT NULL,
    conta character varying(50) NOT NULL,
    digito character varying(5),
    tipo character varying(50) NOT NULL,
    saldo_inicial numeric(15,2) DEFAULT 0.00 NOT NULL,
    ativa boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_conta_bancaria; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_conta_bancaria IS 'Contas bancárias da empresa';


--
-- Name: bc_fin_conta_bancaria_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_conta_bancaria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_conta_bancaria_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_conta_bancaria_id_seq OWNED BY brasil_saas.bc_fin_conta_bancaria.id;


--
-- Name: bc_fin_emprestimo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_emprestimo (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    instituicao character varying(100) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    taxa_juros numeric(10,4),
    data_contratacao date NOT NULL,
    data_quitacao date,
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_emprestimo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_emprestimo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_emprestimo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_emprestimo_id_seq OWNED BY brasil_saas.bc_fin_emprestimo.id;


--
-- Name: bc_fin_extrato; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_extrato (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conta_bancaria_id bigint NOT NULL,
    data_movimento date NOT NULL,
    descricao character varying(255) NOT NULL,
    valor numeric(15,2) NOT NULL,
    tipo character(1) NOT NULL,
    saldo_anterior numeric(15,2),
    saldo_atual numeric(15,2),
    conciliado boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_extrato; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_extrato IS 'Extrato bancário importado ou manual';


--
-- Name: bc_fin_extrato_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_extrato_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_extrato_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_extrato_id_seq OWNED BY brasil_saas.bc_fin_extrato.id;


--
-- Name: bc_fin_fluxo_aprovacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_fluxo_aprovacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    descricao character varying(100) NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_fluxo_aprovacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_fluxo_aprovacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_fluxo_aprovacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_fluxo_aprovacao_id_seq OWNED BY brasil_saas.bc_fin_fluxo_aprovacao.id;


--
-- Name: bc_fin_integracao_bancaria; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_integracao_bancaria (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conta_bancaria_id bigint NOT NULL,
    provedor character varying(50) NOT NULL,
    configuracao_json text,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_integracao_bancaria_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_integracao_bancaria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_integracao_bancaria_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_integracao_bancaria_id_seq OWNED BY brasil_saas.bc_fin_integracao_bancaria.id;


--
-- Name: bc_fin_lancamento_contabil; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_lancamento_contabil (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    data_lancamento date NOT NULL,
    periodo_contabil_id bigint,
    descricao_historico character varying(255) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    origem character varying(50),
    id_origem bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_lancamento_contabil; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_lancamento_contabil IS 'Lançamentos contábeis (cabeçalho)';


--
-- Name: bc_fin_lancamento_contabil_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_lancamento_contabil_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_lancamento_contabil_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_lancamento_contabil_id_seq OWNED BY brasil_saas.bc_fin_lancamento_contabil.id;


--
-- Name: bc_fin_lancamento_partida; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_lancamento_partida (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    lancamento_id bigint NOT NULL,
    plano_contas_id bigint NOT NULL,
    centro_custo_id bigint,
    tipo character(1) NOT NULL,
    valor numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_lancamento_partida; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_lancamento_partida IS 'Partidas dobradas (débito e crédito)';


--
-- Name: bc_fin_lancamento_partida_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_lancamento_partida_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_lancamento_partida_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_lancamento_partida_id_seq OWNED BY brasil_saas.bc_fin_lancamento_partida.id;


--
-- Name: bc_fin_orcamento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_orcamento (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    ano integer NOT NULL,
    centro_custo_id bigint,
    plano_contas_id bigint,
    valor_orcado numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_orcamento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_orcamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_orcamento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_orcamento_id_seq OWNED BY brasil_saas.bc_fin_orcamento.id;


--
-- Name: bc_fin_orcamento_realizado; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_orcamento_realizado (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    orcamento_id bigint NOT NULL,
    mes integer NOT NULL,
    valor_realizado numeric(15,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_orcamento_realizado_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_orcamento_realizado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_orcamento_realizado_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_orcamento_realizado_id_seq OWNED BY brasil_saas.bc_fin_orcamento_realizado.id;


--
-- Name: bc_fin_periodo_contabil; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_periodo_contabil (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    data_inicio date NOT NULL,
    data_fim date NOT NULL,
    status character varying(20) DEFAULT 'ABERTO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_periodo_contabil; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_periodo_contabil IS 'Períodos contábeis para fechamento';


--
-- Name: bc_fin_periodo_contabil_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_periodo_contabil_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_periodo_contabil_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_periodo_contabil_id_seq OWNED BY brasil_saas.bc_fin_periodo_contabil.id;


--
-- Name: bc_fin_plano_contas; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_plano_contas (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    codigo character varying(50) NOT NULL,
    descricao character varying(255) NOT NULL,
    tipo character(1) NOT NULL,
    natureza character(1) NOT NULL,
    conta_pai_id bigint,
    nivel integer DEFAULT 1 NOT NULL,
    ativa boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_plano_contas; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_plano_contas IS 'Plano de contas contábil';


--
-- Name: bc_fin_plano_contas_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_plano_contas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_plano_contas_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_plano_contas_id_seq OWNED BY brasil_saas.bc_fin_plano_contas.id;


--
-- Name: bc_fin_projecao_fluxo_caixa; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_projecao_fluxo_caixa (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    data_projecao date NOT NULL,
    valor_previsto_entrada numeric(15,2) DEFAULT 0.00,
    valor_previsto_saida numeric(15,2) DEFAULT 0.00,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_projecao_fluxo_caixa_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_projecao_fluxo_caixa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_projecao_fluxo_caixa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_projecao_fluxo_caixa_id_seq OWNED BY brasil_saas.bc_fin_projecao_fluxo_caixa.id;


--
-- Name: bc_fin_provisao_pdd; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_provisao_pdd (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    data_provisao date NOT NULL,
    valor_provisao numeric(15,2) NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_provisao_pdd_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_provisao_pdd_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_provisao_pdd_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_provisao_pdd_id_seq OWNED BY brasil_saas.bc_fin_provisao_pdd.id;


--
-- Name: bc_fin_remessa; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_remessa (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conta_bancaria_id bigint,
    banco character varying(10) NOT NULL,
    tipo character varying(10) DEFAULT 'cnab240'::character varying NOT NULL,
    numero_sequencial character varying(20),
    data_geracao date DEFAULT CURRENT_DATE NOT NULL,
    data_credito date,
    qtde_titulos integer DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'GERADA'::character varying NOT NULL,
    documento_id character varying(64),
    documento_hash character varying(64),
    nome_arquivo character varying(255),
    criado_por bigint,
    criado_em timestamp without time zone DEFAULT now() NOT NULL,
    atualizado_em timestamp without time zone,
    CONSTRAINT ck_fin_remessa_status CHECK (((status)::text = ANY (ARRAY[('GERADA'::character varying)::text, ('ENVIADA'::character varying)::text, ('PROCESSADA'::character varying)::text, ('REJEITADA'::character varying)::text]))),
    CONSTRAINT ck_fin_remessa_tipo CHECK (((tipo)::text = ANY (ARRAY[('cnab240'::character varying)::text, ('cnab400'::character varying)::text])))
);


--
-- Name: TABLE bc_fin_remessa; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_remessa IS 'Remessa CNAB gerada pelo boleto_cnab_api e enviada ao banco.';


--
-- Name: bc_fin_remessa_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_remessa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_remessa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_remessa_id_seq OWNED BY brasil_saas.bc_fin_remessa.id;


--
-- Name: bc_fin_remessa_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_remessa_item (
    id bigint NOT NULL,
    remessa_id bigint NOT NULL,
    titulo_id bigint,
    boleto_id bigint,
    nosso_numero character varying(50),
    valor numeric(15,2) NOT NULL,
    vencimento date,
    codigo_ocorrencia character varying(4),
    criado_em timestamp without time zone DEFAULT now() NOT NULL,
    documento_sacado character varying(20),
    nome_sacado character varying(200),
    endereco_sacado character varying(200),
    bairro_sacado character varying(120),
    cep_sacado character varying(10),
    cidade_sacado character varying(120),
    uf_sacado character varying(2)
);


--
-- Name: bc_fin_remessa_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_remessa_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_remessa_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_remessa_item_id_seq OWNED BY brasil_saas.bc_fin_remessa_item.id;


--
-- Name: bc_fin_renegociacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_renegociacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    titulo_original_id bigint NOT NULL,
    novo_titulo_id bigint,
    data_renegociacao date NOT NULL,
    valor_acrescimo numeric(15,2) DEFAULT 0.00,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_fin_renegociacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_renegociacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_renegociacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_renegociacao_id_seq OWNED BY brasil_saas.bc_fin_renegociacao.id;


--
-- Name: bc_fin_retorno_bancario; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_retorno_bancario (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    conta_bancaria_id bigint,
    banco character varying(10) NOT NULL,
    tipo character varying(10) DEFAULT 'cnab240'::character varying NOT NULL,
    nome_arquivo character varying(255),
    data_arquivo date,
    qtde_registros integer DEFAULT 0 NOT NULL,
    qtde_baixados integer DEFAULT 0 NOT NULL,
    qtde_divergentes integer DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'PROCESSADO'::character varying NOT NULL,
    documento_id character varying(64),
    resumo_json text,
    erro text,
    criado_por bigint,
    criado_em timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_fin_retorno_status CHECK (((status)::text = ANY (ARRAY[('PROCESSADO'::character varying)::text, ('PARCIAL'::character varying)::text, ('ERRO'::character varying)::text]))),
    CONSTRAINT ck_fin_retorno_tipo CHECK (((tipo)::text = ANY (ARRAY[('cnab240'::character varying)::text, ('cnab400'::character varying)::text])))
);


--
-- Name: bc_fin_retorno_bancario_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_retorno_bancario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_retorno_bancario_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_retorno_bancario_id_seq OWNED BY brasil_saas.bc_fin_retorno_bancario.id;


--
-- Name: bc_fin_retorno_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_retorno_item (
    id bigint NOT NULL,
    retorno_id bigint NOT NULL,
    titulo_id bigint,
    codigo_registro character varying(4),
    codigo_ocorrencia character varying(4),
    nosso_numero character varying(50),
    valor_titulo numeric(15,2),
    valor_recebido numeric(15,2),
    juros numeric(15,2),
    multa numeric(15,2),
    desconto numeric(15,2),
    data_credito date,
    data_ocorrencia date,
    aplicado boolean DEFAULT false NOT NULL,
    observacao text,
    criado_em timestamp without time zone DEFAULT now() NOT NULL,
    boleto_id bigint
);


--
-- Name: bc_fin_retorno_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_retorno_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_retorno_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_retorno_item_id_seq OWNED BY brasil_saas.bc_fin_retorno_item.id;


--
-- Name: bc_fin_tipo_pagamento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_tipo_pagamento (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    descricao character varying(100) NOT NULL,
    codigo character varying(20),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_tipo_pagamento; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_tipo_pagamento IS 'Tipos/Meios de pagamento';


--
-- Name: bc_fin_tipo_pagamento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_tipo_pagamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_tipo_pagamento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_tipo_pagamento_id_seq OWNED BY brasil_saas.bc_fin_tipo_pagamento.id;


--
-- Name: bc_fin_titulo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_titulo (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    tipo character(1) NOT NULL,
    numero_documento character varying(100),
    descricao character varying(255) NOT NULL,
    pessoa_id bigint,
    valor_original numeric(15,2) NOT NULL,
    valor_saldo numeric(15,2) NOT NULL,
    data_emissao date NOT NULL,
    data_vencimento date NOT NULL,
    status character varying(255) DEFAULT 'ABERTO'::character varying NOT NULL,
    centro_custo_id bigint,
    plano_contas_id bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_titulo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_titulo IS 'Títulos a pagar e a receber';


--
-- Name: COLUMN bc_fin_titulo.status; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fin_titulo.status IS 'ABERTO | PENDENTE_APROVACAO | BAIXADO | CANCELADO (demais estados por regra de negócio)';


--
-- Name: bc_fin_titulo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_titulo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_titulo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_titulo_id_seq OWNED BY brasil_saas.bc_fin_titulo.id;


--
-- Name: bc_fin_titulo_parcela; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fin_titulo_parcela (
    id bigint NOT NULL,
    uuid uuid DEFAULT brasil_saas.uuid_generate_v4(),
    empresa_id bigint NOT NULL,
    titulo_id bigint NOT NULL,
    numero_parcela integer NOT NULL,
    valor_parcela numeric(15,2) NOT NULL,
    valor_saldo numeric(15,2) NOT NULL,
    data_vencimento date NOT NULL,
    status character varying(20) DEFAULT 'ABERTO'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fin_titulo_parcela; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fin_titulo_parcela IS 'Parcelas dos títulos';


--
-- Name: bc_fin_titulo_parcela_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fin_titulo_parcela_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fin_titulo_parcela_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fin_titulo_parcela_id_seq OWNED BY brasil_saas.bc_fin_titulo_parcela.id;


--
-- Name: bc_fis_apuracao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_apuracao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    imposto_id bigint NOT NULL,
    competencia character varying(7) NOT NULL,
    base_calculo numeric(15,2) DEFAULT 0 NOT NULL,
    valor_devido numeric(15,2) DEFAULT 0 NOT NULL,
    valor_credito numeric(15,2) DEFAULT 0 NOT NULL,
    valor_pagar numeric(15,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    apurada_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    data_encerramento date,
    imposto character varying(10) NOT NULL,
    valor_base_calculo numeric(15,2),
    valor_imposto numeric(15,2),
    valor_debito numeric(15,2),
    valor_recolher numeric(15,2)
);


--
-- Name: TABLE bc_fis_apuracao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_apuracao IS 'Apurações mensais de impostos';


--
-- Name: bc_fis_apuracao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_apuracao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_apuracao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_apuracao_id_seq OWNED BY brasil_saas.bc_fis_apuracao.id;


--
-- Name: bc_fis_certificado_digital; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_certificado_digital (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    tipo character varying(10) DEFAULT 'A1'::character varying NOT NULL,
    arquivo_url character varying(500),
    cnpj_titular character varying(14),
    emissao_at timestamp without time zone,
    validade_at timestamp without time zone NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    arquivo character varying(200),
    cnpj character varying(14),
    razao_social character varying(200),
    senha character varying(255)
);


--
-- Name: TABLE bc_fis_certificado_digital; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_certificado_digital IS 'Certificados digitais (A1/A3)';


--
-- Name: COLUMN bc_fis_certificado_digital.arquivo_url; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_certificado_digital.arquivo_url IS 'Referência MinIO — nunca versionar o arquivo em si';


--
-- Name: bc_fis_certificado_digital_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_certificado_digital_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_certificado_digital_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_certificado_digital_id_seq OWNED BY brasil_saas.bc_fis_certificado_digital.id;


--
-- Name: bc_fis_cest; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_cest (
    id bigint NOT NULL,
    codigo character varying(7) NOT NULL,
    ncm character varying(8),
    descricao text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_cest; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_cest IS 'CEST — Código Especificador da Substituição Tributária (oficial)';


--
-- Name: bc_fis_cest_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_cest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_cest_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_cest_id_seq OWNED BY brasil_saas.bc_fis_cest.id;


--
-- Name: bc_fis_cfop; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_cfop (
    id bigint NOT NULL,
    codigo character varying(4) NOT NULL,
    descricao text NOT NULL,
    tipo character varying(20),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_cfop; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_cfop IS 'CFOP — Código Fiscal de Operações e Prestações (oficial)';


--
-- Name: bc_fis_cfop_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_cfop_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_cfop_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_cfop_id_seq OWNED BY brasil_saas.bc_fis_cfop.id;


--
-- Name: bc_fis_cnae_servico; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_cnae_servico (
    id bigint NOT NULL,
    codigo character varying(10) NOT NULL,
    descricao text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    lc116_codigo character varying(12)
);


--
-- Name: TABLE bc_fis_cnae_servico; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_cnae_servico IS 'CNAE de serviços (oficial IBGE)';


--
-- Name: bc_fis_cnae_servico_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_cnae_servico_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_cnae_servico_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_cnae_servico_id_seq OWNED BY brasil_saas.bc_fis_cnae_servico.id;


--
-- Name: bc_fis_cte; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_cte (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint,
    numero bigint,
    serie character varying(10),
    chave_acesso character varying(50),
    data_emissao timestamp without time zone,
    status character varying(20) DEFAULT 'DIGITADA'::character varying NOT NULL,
    valor_carga numeric(15,2) DEFAULT 0 NOT NULL,
    valor_frete numeric(15,2) DEFAULT 0 NOT NULL,
    xml text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    tipo_operacao character(1) DEFAULT 'S'::bpchar NOT NULL
);


--
-- Name: TABLE bc_fis_cte; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_cte IS 'Conhecimentos de transporte eletrônicos (modelo 57)';


--
-- Name: COLUMN bc_fis_cte.tipo_operacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_cte.tipo_operacao IS 'E=entrada, S=saída';


--
-- Name: bc_fis_cte_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_cte_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_cte_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_cte_id_seq OWNED BY brasil_saas.bc_fis_cte.id;


--
-- Name: bc_fis_cte_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_cte_item (
    id bigint NOT NULL,
    cte_id bigint NOT NULL,
    descricao text,
    quantidade numeric(15,4),
    valor numeric(15,2),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_fis_cte_item; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_cte_item IS 'Cargas/itens do CT-e';


--
-- Name: bc_fis_cte_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_cte_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_cte_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_cte_item_id_seq OWNED BY brasil_saas.bc_fis_cte_item.id;


--
-- Name: bc_fis_ecd; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_ecd (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    exercicio character varying(4) NOT NULL,
    arquivo_url character varying(500),
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_ecd; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_ecd IS 'ECD — Escrituração Contábil Digital';


--
-- Name: bc_fis_ecd_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_ecd_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_ecd_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_ecd_id_seq OWNED BY brasil_saas.bc_fis_ecd.id;


--
-- Name: bc_fis_ecf; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_ecf (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    exercicio character varying(4) NOT NULL,
    arquivo_url character varying(500),
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_ecf; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_ecf IS 'ECF — Escrituração Contábil Fiscal';


--
-- Name: bc_fis_ecf_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_ecf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_ecf_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_ecf_id_seq OWNED BY brasil_saas.bc_fis_ecf.id;


--
-- Name: bc_fis_esocial; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_esocial (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    competencia character varying(7) NOT NULL,
    evento character varying(20),
    arquivo_url character varying(500),
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_esocial; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_esocial IS 'Eventos de eSocial';


--
-- Name: bc_fis_esocial_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_esocial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_esocial_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_esocial_id_seq OWNED BY brasil_saas.bc_fis_esocial.id;


--
-- Name: bc_fis_imposto; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_imposto (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    sigla character varying(10) NOT NULL,
    nome character varying(100) NOT NULL,
    tipo character varying(30) NOT NULL,
    aliquota_padrao numeric(7,4),
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_imposto; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_imposto IS 'Impostos configurados por empresa';


--
-- Name: bc_fis_imposto_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_imposto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_imposto_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_imposto_id_seq OWNED BY brasil_saas.bc_fis_imposto.id;


--
-- Name: bc_fis_issqn; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_issqn (
    id bigint NOT NULL,
    codigo character varying(20) NOT NULL,
    descricao text NOT NULL,
    aliquota numeric(7,4),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    cod_ibge character varying(7),
    uf character(2),
    municipio character varying(150),
    codigo_municipal character varying(20),
    vigencia date
);


--
-- Name: TABLE bc_fis_issqn; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_issqn IS 'Códigos de tributação municipal de ISSQN';


--
-- Name: bc_fis_issqn_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_issqn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_issqn_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_issqn_id_seq OWNED BY brasil_saas.bc_fis_issqn.id;


--
-- Name: bc_fis_manifestacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_manifestacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    chave_acesso character varying(50) NOT NULL,
    tipo character varying(30) NOT NULL,
    justificativa character varying(255),
    protocolo character varying(50),
    data_evento timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_manifestacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_manifestacao IS 'Manifestação do destinatário';


--
-- Name: bc_fis_manifestacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_manifestacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_manifestacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_manifestacao_id_seq OWNED BY brasil_saas.bc_fis_manifestacao.id;


--
-- Name: bc_fis_mdfe; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_mdfe (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    numero bigint,
    serie character varying(10),
    chave_acesso character varying(50),
    data_emissao timestamp without time zone,
    status character varying(20) DEFAULT 'DIGITADA'::character varying NOT NULL,
    uf_inicio character(2),
    uf_fim character(2),
    xml text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_mdfe; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_mdfe IS 'Manifestos eletrônicos de documentos fiscais (modelo 58)';


--
-- Name: bc_fis_mdfe_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_mdfe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_mdfe_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_mdfe_id_seq OWNED BY brasil_saas.bc_fis_mdfe.id;


--
-- Name: bc_fis_nbs; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nbs (
    id bigint NOT NULL,
    codigo character varying(12) NOT NULL,
    descricao text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_nbs; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nbs IS 'NBS — Nomenclatura Brasileira de Serviços (oficial)';


--
-- Name: bc_fis_nbs_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nbs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nbs_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nbs_id_seq OWNED BY brasil_saas.bc_fis_nbs.id;


--
-- Name: bc_fis_ncm; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_ncm (
    id bigint NOT NULL,
    codigo character varying(8) NOT NULL,
    descricao text NOT NULL,
    aliquota_ipi numeric(7,4),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_ncm; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_ncm IS 'NCM — Nomenclatura Comum do Mercosul (oficial)';


--
-- Name: bc_fis_ncm_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_ncm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_ncm_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_ncm_id_seq OWNED BY brasil_saas.bc_fis_ncm.id;


--
-- Name: bc_fis_nfce; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfce (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint,
    numero bigint,
    serie character varying(10),
    chave_acesso character varying(50),
    data_emissao timestamp without time zone,
    status character varying(20) DEFAULT 'DIGITADA'::character varying NOT NULL,
    protocolo character varying(50),
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    xml text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_nfce; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfce IS 'Notas fiscais de consumidor eletrônicas (modelo 65)';


--
-- Name: bc_fis_nfce_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfce_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfce_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfce_id_seq OWNED BY brasil_saas.bc_fis_nfce.id;


--
-- Name: bc_fis_nfce_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfce_item (
    id bigint NOT NULL,
    nfce_id bigint NOT NULL,
    produto_id bigint,
    quantidade numeric(15,4) NOT NULL,
    valor_unitario numeric(15,4) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_fis_nfce_item; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfce_item IS 'Itens da NFC-e';


--
-- Name: bc_fis_nfce_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfce_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfce_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfce_item_id_seq OWNED BY brasil_saas.bc_fis_nfce_item.id;


--
-- Name: bc_fis_nfe; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfe (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    cliente_id bigint,
    pessoa_id bigint,
    numero bigint,
    serie character varying(10),
    chave_acesso character varying(50),
    natureza_operacao character varying(100),
    cfop character varying(4),
    data_emissao timestamp without time zone,
    data_saida timestamp without time zone,
    status character varying(20) DEFAULT 'DIGITADA'::character varying NOT NULL,
    protocolo character varying(50),
    xml text,
    danfe_url character varying(500),
    valor_produtos numeric(15,2) DEFAULT 0 NOT NULL,
    valor_frete numeric(15,2) DEFAULT 0 NOT NULL,
    valor_desconto numeric(15,2) DEFAULT 0 NOT NULL,
    valor_icms numeric(15,2) DEFAULT 0 NOT NULL,
    valor_ipi numeric(15,2) DEFAULT 0 NOT NULL,
    valor_pis numeric(15,2) DEFAULT 0 NOT NULL,
    valor_cofins numeric(15,2) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    tipo_operacao character(1) DEFAULT 'S'::bpchar NOT NULL,
    pedido_venda_id bigint,
    pedido_compra_id bigint,
    documento_origem_tipo character varying(30),
    documento_origem_id bigint
);


--
-- Name: TABLE bc_fis_nfe; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfe IS 'Notas fiscais eletrônicas (modelo 55)';


--
-- Name: COLUMN bc_fis_nfe.tipo_operacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfe.tipo_operacao IS 'E=entrada, S=saída';


--
-- Name: COLUMN bc_fis_nfe.documento_origem_tipo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfe.documento_origem_tipo IS 'VENDA, COMPRA, SERVICO ou OUTRO';


--
-- Name: bc_fis_nfe_evento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfe_evento (
    id bigint NOT NULL,
    nfe_id bigint NOT NULL,
    tipo character varying(30) NOT NULL,
    sequencia integer DEFAULT 1 NOT NULL,
    protocolo character varying(50),
    data_evento timestamp without time zone,
    xml text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by bigint
);


--
-- Name: TABLE bc_fis_nfe_evento; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfe_evento IS 'Eventos de NF-e (cancelamento, carta de correção...)';


--
-- Name: bc_fis_nfe_evento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfe_evento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfe_evento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfe_evento_id_seq OWNED BY brasil_saas.bc_fis_nfe_evento.id;


--
-- Name: bc_fis_nfe_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfe_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfe_id_seq OWNED BY brasil_saas.bc_fis_nfe.id;


--
-- Name: bc_fis_nfe_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfe_item (
    id bigint NOT NULL,
    nfe_id bigint NOT NULL,
    produto_id bigint,
    numero_item integer NOT NULL,
    ncm character varying(8),
    cfop character varying(4),
    cest character varying(7),
    quantidade numeric(15,4) NOT NULL,
    unidade character varying(10),
    valor_unitario numeric(15,4) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    aliquota_icms numeric(7,4),
    valor_icms numeric(15,2),
    aliquota_ipi numeric(7,4),
    valor_ipi numeric(15,2),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    codigo_produto character varying(60),
    codigo_barras character varying(20),
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_nfe_item; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfe_item IS 'Itens da NF-e';


--
-- Name: COLUMN bc_fis_nfe_item.codigo_produto; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfe_item.codigo_produto IS 'cProd: codigo do produto no fornecedor. Nao e o codigo interno do ERP.';


--
-- Name: COLUMN bc_fis_nfe_item.codigo_barras; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfe_item.codigo_barras IS 'cEAN do item, so quando o emissor escreveu digitos. Texto como "SEM GTIN" vira NULL.';


--
-- Name: COLUMN bc_fis_nfe_item.uuid; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfe_item.uuid IS 'Chave publica do item. NULL so em linha criada antes da V103.';


--
-- Name: COLUMN bc_fis_nfe_item.deleted_at; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfe_item.deleted_at IS 'Item corrigido nao se apaga: a nota e documento fiscal e o historico precisa ficar.';


--
-- Name: bc_fis_nfe_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfe_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfe_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfe_item_id_seq OWNED BY brasil_saas.bc_fis_nfe_item.id;


--
-- Name: bc_fis_nfse; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfse (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    cliente_id bigint,
    pessoa_id bigint,
    servico_id bigint,
    numero bigint,
    codigo_verificacao character varying(50),
    lc116_codigo character varying(10),
    codigo_tributacao_municipal character varying(20),
    data_emissao timestamp without time zone,
    status character varying(20) DEFAULT 'DIGITADA'::character varying NOT NULL,
    xml text,
    pdf_url character varying(500),
    base_calculo numeric(15,2) DEFAULT 0 NOT NULL,
    aliquota_iss numeric(7,4) DEFAULT 0 NOT NULL,
    valor_iss numeric(15,2) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    tipo_operacao character(1) DEFAULT 'S'::bpchar NOT NULL,
    xml_documento_id character varying(50),
    pdf_documento_id character varying(50),
    chave_nota_nacional character varying(50),
    serie_rps character varying(10),
    numero_rps character varying(20)
);


--
-- Name: TABLE bc_fis_nfse; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfse IS 'Notas fiscais de serviço eletrônicas';


--
-- Name: COLUMN bc_fis_nfse.tipo_operacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse.tipo_operacao IS 'E=entrada, S=saída';


--
-- Name: COLUMN bc_fis_nfse.xml_documento_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse.xml_documento_id IS 'Id do documento no MongoDB (tipoEntidade nfse_xml). Guarda 5 anos.';


--
-- Name: COLUMN bc_fis_nfse.pdf_documento_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse.pdf_documento_id IS 'Id do documento no MongoDB (tipoEntidade nfse_pdf). Expira em 60 dias.';


--
-- Name: COLUMN bc_fis_nfse.chave_nota_nacional; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse.chave_nota_nacional IS 'Chave da nota nacional devolvida pela prefeitura (44 digitos).';


--
-- Name: bc_fis_nfse_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfse_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfse_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfse_id_seq OWNED BY brasil_saas.bc_fis_nfse.id;


--
-- Name: bc_fis_nfse_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfse_item (
    id bigint NOT NULL,
    nfse_id bigint NOT NULL,
    servico_id bigint,
    descricao text,
    quantidade numeric(15,4) DEFAULT 1 NOT NULL,
    valor_unitario numeric(15,4) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_fis_nfse_item; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfse_item IS 'Itens da NFS-e';


--
-- Name: bc_fis_nfse_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfse_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfse_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfse_item_id_seq OWNED BY brasil_saas.bc_fis_nfse_item.id;


--
-- Name: bc_fis_nfse_retorno; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_nfse_retorno (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nfse_id bigint,
    operacao character varying(20) NOT NULL,
    sucesso boolean,
    http_status integer,
    duracao_ms bigint,
    mensagem text,
    codigo character varying(20),
    alertas text,
    documento_id character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    created_by bigint,
    updated_by bigint
);


--
-- Name: TABLE bc_fis_nfse_retorno; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_nfse_retorno IS 'Uma linha por chamada a prefeitura: emissao, cancelamento, consulta. O JSON bruto da resposta fica no Mongo (documento_id); o que da para consultar fica aqui. E o registro que sobrevive ao fechamento da tela de erro.';


--
-- Name: COLUMN bc_fis_nfse_retorno.sucesso; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse_retorno.sucesso IS 'true aceitou; false recusou (com mensagem); NULL nao deu para saber — unico caso em que reemitir e perigoso.';


--
-- Name: COLUMN bc_fis_nfse_retorno.mensagem; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse_retorno.mensagem IS 'Texto da prefeitura, literal. Sobrevive ao fechamento da tela.';


--
-- Name: COLUMN bc_fis_nfse_retorno.codigo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse_retorno.codigo IS 'Codigo de erro da prefeitura, extraido da mensagem (ex.: 1001).';


--
-- Name: COLUMN bc_fis_nfse_retorno.documento_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_fis_nfse_retorno.documento_id IS 'Id do documento no MongoDB (tipoEntidade nfse_retorno). Guarda o JSON bruto da resposta.';


--
-- Name: bc_fis_nfse_retorno_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_nfse_retorno_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_nfse_retorno_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_nfse_retorno_id_seq OWNED BY brasil_saas.bc_fis_nfse_retorno.id;


--
-- Name: bc_fis_regra_tributaria; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_regra_tributaria (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    ncm character varying(8),
    cfop character varying(4),
    uf_origem character(2),
    uf_destino character(2),
    cst_icms character varying(5),
    aliquota_icms numeric(7,4),
    cst_ipi character varying(5),
    aliquota_ipi numeric(7,4),
    cst_pis character varying(5),
    aliquota_pis numeric(7,4),
    cst_cofins character varying(5),
    aliquota_cofins numeric(7,4),
    aliquota_st numeric(7,4),
    ativa boolean DEFAULT true NOT NULL,
    prioridade integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_regra_tributaria; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_regra_tributaria IS 'Regras de tributação por NCM/CFOP/UF';


--
-- Name: bc_fis_regra_tributaria_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_regra_tributaria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_regra_tributaria_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_regra_tributaria_id_seq OWNED BY brasil_saas.bc_fis_regra_tributaria.id;


--
-- Name: bc_fis_reinf; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_reinf (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    competencia character varying(7) NOT NULL,
    evento character varying(20),
    arquivo_url character varying(500),
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_reinf; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_reinf IS 'EFD-REINF';


--
-- Name: bc_fis_reinf_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_reinf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_reinf_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_reinf_id_seq OWNED BY brasil_saas.bc_fis_reinf.id;


--
-- Name: bc_fis_servico_lc116; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_servico_lc116 (
    id bigint NOT NULL,
    codigo character varying(10) NOT NULL,
    descricao text NOT NULL,
    aliquota_min numeric(7,4),
    aliquota_max numeric(7,4),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_servico_lc116; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_servico_lc116 IS 'Itens da Lista de Serviços da LC 116/2003 (oficial)';


--
-- Name: bc_fis_servico_lc116_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_servico_lc116_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_servico_lc116_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_servico_lc116_id_seq OWNED BY brasil_saas.bc_fis_servico_lc116.id;


--
-- Name: bc_fis_sped_contribuicoes; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_sped_contribuicoes (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    competencia character varying(7) NOT NULL,
    arquivo_url character varying(500),
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    gerado_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_sped_contribuicoes; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_sped_contribuicoes IS 'Gerações de SPED Contribuições (PIS/COFINS)';


--
-- Name: bc_fis_sped_contribuicoes_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_sped_contribuicoes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_sped_contribuicoes_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_sped_contribuicoes_id_seq OWNED BY brasil_saas.bc_fis_sped_contribuicoes.id;


--
-- Name: bc_fis_sped_fiscal; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_fis_sped_fiscal (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    competencia character varying(7) NOT NULL,
    arquivo_url character varying(500),
    status character varying(20) DEFAULT 'PENDENTE'::character varying NOT NULL,
    gerado_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_fis_sped_fiscal; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_fis_sped_fiscal IS 'Gerações de SPED Fiscal (ICMS/IPI)';


--
-- Name: bc_fis_sped_fiscal_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_fis_sped_fiscal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_fis_sped_fiscal_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_fis_sped_fiscal_id_seq OWNED BY brasil_saas.bc_fis_sped_fiscal.id;


--
-- Name: bc_ia_analise_preditiva; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_analise_preditiva (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    tipo character varying(50),
    entidade character varying(50),
    entidade_id bigint,
    periodo character varying(20),
    dias_previsao integer DEFAULT 30,
    valor_atual numeric(15,2),
    valor_previsto numeric(15,2),
    valor_minimo numeric(15,2),
    valor_maximo numeric(15,2),
    confianca numeric(5,2),
    status character varying(20),
    data_analise date,
    data_proxima_analise date,
    criado_por bigint,
    data_criacao date DEFAULT CURRENT_DATE,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ia_analise_preditiva_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_analise_preditiva_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_analise_preditiva_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_analise_preditiva_id_seq OWNED BY brasil_saas.bc_ia_analise_preditiva.id;


--
-- Name: bc_ia_chat_mensagem; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_chat_mensagem (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    sessao_id bigint NOT NULL,
    conteudo text NOT NULL,
    tipo character varying(20) NOT NULL,
    tokens integer,
    tempo_resposta_ms bigint,
    modelo_ia character varying(50),
    data_envio timestamp without time zone DEFAULT now(),
    classificacao integer,
    feedback text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ia_chat_mensagem_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_chat_mensagem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_chat_mensagem_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_chat_mensagem_id_seq OWNED BY brasil_saas.bc_ia_chat_mensagem.id;


--
-- Name: bc_ia_chat_message; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_chat_message (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id bigint NOT NULL,
    content text NOT NULL,
    message_type character varying(20) NOT NULL,
    sender character varying(100),
    token_count bigint DEFAULT 0,
    response_time_ms bigint,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ia_chat_message; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ia_chat_message IS 'Messages in chat sessions';


--
-- Name: bc_ia_chat_message_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_chat_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_chat_message_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_chat_message_id_seq OWNED BY brasil_saas.bc_ia_chat_message.id;


--
-- Name: bc_ia_chat_sessao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_chat_sessao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    titulo character varying(200),
    usuario_id bigint NOT NULL,
    modelo_ia character varying(50) DEFAULT 'gpt-4'::character varying,
    temperatura double precision DEFAULT 0.7,
    max_tokens integer DEFAULT 4096,
    ativo boolean DEFAULT true,
    favorito boolean DEFAULT false,
    data_criacao timestamp without time zone DEFAULT now(),
    data_atualizacao timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ia_chat_sessao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_chat_sessao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_chat_sessao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_chat_sessao_id_seq OWNED BY brasil_saas.bc_ia_chat_sessao.id;


--
-- Name: bc_ia_chat_session; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_chat_session (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    title character varying(200) NOT NULL,
    context text,
    model_name character varying(100) DEFAULT 'gpt-4'::character varying,
    temperature double precision DEFAULT 0.7,
    max_tokens integer DEFAULT 4000,
    session_type character varying(50) DEFAULT 'GENERAL'::character varying,
    is_active boolean DEFAULT true,
    token_count bigint DEFAULT 0,
    cost_usd double precision DEFAULT 0.0,
    user_id bigint,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ia_chat_session; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ia_chat_session IS 'Chat sessions with AI assistant';


--
-- Name: bc_ia_chat_session_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_chat_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_chat_session_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_chat_session_id_seq OWNED BY brasil_saas.bc_ia_chat_session.id;


--
-- Name: bc_ia_classificacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_classificacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    tipo character varying(50),
    categoria character varying(100),
    tags text,
    confianca double precision,
    classificacao_manual character varying(100),
    classificacao_ia character varying(100),
    status character varying(20),
    entidade_id bigint,
    aprovado_por bigint,
    data_aprovacao timestamp without time zone,
    criado_por bigint,
    data_criacao timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ia_classificacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_classificacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_classificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_classificacao_id_seq OWNED BY brasil_saas.bc_ia_classificacao.id;


--
-- Name: bc_ia_config; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_config (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    api_key text,
    api_endpoint character varying(500) DEFAULT 'https://api.openai.com/v1'::character varying,
    default_model character varying(100) DEFAULT 'gpt-4'::character varying,
    temperature double precision DEFAULT 0.7,
    max_tokens integer DEFAULT 4000,
    timeout_seconds integer DEFAULT 60,
    is_enabled boolean DEFAULT false,
    max_daily_tokens bigint DEFAULT 100000,
    daily_token_usage bigint DEFAULT 0,
    last_reset_date date,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ia_config; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ia_config IS 'Configuration for AI integration (OpenAI, etc.)';


--
-- Name: bc_ia_config_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_config_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_config_id_seq OWNED BY brasil_saas.bc_ia_config.id;


--
-- Name: bc_ia_embedding; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_embedding (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    entidade_tipo character varying(50) NOT NULL,
    entidade_id bigint NOT NULL,
    texto text NOT NULL,
    embedding_vector double precision[],
    dimensoes integer,
    modelo character varying(50) DEFAULT 'text-embedding-3-small'::character varying,
    tamanho_texto integer,
    tokens integer,
    data_criacao timestamp without time zone DEFAULT now(),
    data_atualizacao timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ia_embedding_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_embedding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_embedding_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_embedding_id_seq OWNED BY brasil_saas.bc_ia_embedding.id;


--
-- Name: bc_ia_prompt; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_prompt (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    conteudo text NOT NULL,
    categoria character varying(50),
    tipo character varying(20) DEFAULT 'TEXT'::character varying,
    temperatura double precision DEFAULT 0.7,
    max_tokens integer DEFAULT 4096,
    ativo boolean DEFAULT true,
    publico boolean DEFAULT false,
    favorito boolean DEFAULT false,
    contador_uso integer DEFAULT 0,
    criado_por bigint,
    data_criacao timestamp without time zone DEFAULT now(),
    data_atualizacao timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ia_prompt_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_prompt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_prompt_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_prompt_id_seq OWNED BY brasil_saas.bc_ia_prompt.id;


--
-- Name: bc_ia_prompt_template; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ia_prompt_template (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50),
    content text NOT NULL,
    description text,
    variables jsonb,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ia_prompt_template; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ia_prompt_template IS 'Prompt templates for AI interactions';


--
-- Name: bc_ia_prompt_template_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ia_prompt_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ia_prompt_template_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ia_prompt_template_id_seq OWNED BY brasil_saas.bc_ia_prompt_template.id;


--
-- Name: bc_migration_log; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_migration_log (
    id bigint NOT NULL,
    migration character varying(10) NOT NULL,
    tabela_origem character varying(80),
    tabela_destino character varying(80),
    registros_origem bigint,
    registros_destino bigint,
    divergencias bigint DEFAULT 0 NOT NULL,
    detalhes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE bc_migration_log; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_migration_log IS 'Trilha da migração de dados do legado';


--
-- Name: bc_migration_log_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_migration_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_migration_log_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_migration_log_id_seq OWNED BY brasil_saas.bc_migration_log.id;


--
-- Name: bc_prod_apontamento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_prod_apontamento (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    producao_id bigint NOT NULL,
    item_producao_id bigint,
    funcionario_id bigint,
    data_apontamento timestamp without time zone,
    horas_trabalhadas numeric(10,2) DEFAULT 0,
    quantidade_produzida numeric(15,4) DEFAULT 0,
    quantidade_refugo numeric(15,4) DEFAULT 0,
    status character varying(20) DEFAULT 'INICIADO'::character varying,
    observacoes text,
    maquina_equipamento_id bigint,
    turno character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_prod_apontamento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_prod_apontamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_prod_apontamento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_prod_apontamento_id_seq OWNED BY brasil_saas.bc_prod_apontamento.id;


--
-- Name: bc_prod_estrutura; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_prod_estrutura (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    produto_pai_id bigint NOT NULL,
    produto_filho_id bigint NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    perda_percentual numeric(7,4) DEFAULT 0 NOT NULL,
    nivel integer DEFAULT 1 NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    CONSTRAINT ck_prod_estrutura_distinto CHECK ((produto_pai_id <> produto_filho_id)),
    CONSTRAINT ck_prod_estrutura_nivel CHECK ((nivel > 0)),
    CONSTRAINT ck_prod_estrutura_perda CHECK (((perda_percentual >= (0)::numeric) AND (perda_percentual < (100)::numeric))),
    CONSTRAINT ck_prod_estrutura_quantidade CHECK ((quantidade > (0)::numeric))
);


--
-- Name: bc_prod_estrutura_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_prod_estrutura_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_prod_estrutura_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_prod_estrutura_id_seq OWNED BY brasil_saas.bc_prod_estrutura.id;


--
-- Name: bc_prod_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_prod_item (
    id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    deleted_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    uuid uuid NOT NULL,
    empresa_id bigint NOT NULL,
    custo_total numeric(15,2),
    custo_unitario numeric(15,2),
    produto_id bigint NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    producao_id bigint NOT NULL
);


--
-- Name: bc_prod_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

ALTER TABLE brasil_saas.bc_prod_item ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME brasil_saas.bc_prod_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bc_prod_ordem; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_prod_ordem (
    id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    deleted_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    uuid uuid NOT NULL,
    empresa_id bigint NOT NULL,
    custo_total numeric(15,2),
    data_fim timestamp(6) without time zone,
    data_inicio timestamp(6) without time zone,
    densidade numeric(38,2),
    numero character varying(255) NOT NULL,
    produto_final_id bigint NOT NULL,
    quantidade_planejada numeric(15,4),
    status character varying(255) NOT NULL,
    tipo_producao character varying(50),
    unidade_medida character varying(20)
);


--
-- Name: bc_prod_ordem_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

ALTER TABLE brasil_saas.bc_prod_ordem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME brasil_saas.bc_prod_ordem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bc_prod_romaneio; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_prod_romaneio (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    numero character varying(50) NOT NULL,
    producao_id bigint NOT NULL,
    data_romaneio date DEFAULT CURRENT_DATE NOT NULL,
    destino character varying(150),
    responsavel_id bigint,
    veiculo_id bigint,
    status character varying(20) DEFAULT 'ABERTO'::character varying NOT NULL,
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_prod_romaneio_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_prod_romaneio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_prod_romaneio_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_prod_romaneio_id_seq OWNED BY brasil_saas.bc_prod_romaneio.id;


--
-- Name: bc_prod_romaneio_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_prod_romaneio_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    romaneio_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    descricao character varying(200),
    quantidade numeric(15,4) NOT NULL,
    unidade_medida character varying(20) NOT NULL,
    lote character varying(100),
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: bc_prod_romaneio_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_prod_romaneio_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_prod_romaneio_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_prod_romaneio_item_id_seq OWNED BY brasil_saas.bc_prod_romaneio_item.id;


--
-- Name: bc_rh_cargo; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_rh_cargo (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    salario_base numeric(15,2) DEFAULT 0 NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_rh_cargo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_rh_cargo IS 'Cargos';


--
-- Name: bc_rh_cargo_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_rh_cargo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_rh_cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_rh_cargo_id_seq OWNED BY brasil_saas.bc_rh_cargo.id;


--
-- Name: bc_rh_folha; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_rh_folha (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    competencia character varying(7) NOT NULL,
    status character varying(255) DEFAULT 'ABERTA'::character varying NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    titulo_id bigint,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_rh_folha; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_rh_folha IS 'Folhas de pagamento por competência';


--
-- Name: COLUMN bc_rh_folha.competencia; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_folha.competencia IS 'Formato YYYY-MM';


--
-- Name: COLUMN bc_rh_folha.status; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_folha.status IS 'ABERTA, PROCESSADA ou CANCELADA';


--
-- Name: COLUMN bc_rh_folha.titulo_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_folha.titulo_id IS 'Título a pagar gerado no financeiro';


--
-- Name: bc_rh_folha_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_rh_folha_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_rh_folha_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_rh_folha_id_seq OWNED BY brasil_saas.bc_rh_folha.id;


--
-- Name: bc_rh_folha_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_rh_folha_item (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    folha_id bigint NOT NULL,
    funcionario_id bigint NOT NULL,
    tipo character varying(255) NOT NULL,
    descricao character varying(200),
    valor numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: COLUMN bc_rh_folha_item.tipo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_folha_item.tipo IS 'PROVENTO ou DESCONTO';


--
-- Name: bc_rh_folha_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_rh_folha_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_rh_folha_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_rh_folha_item_id_seq OWNED BY brasil_saas.bc_rh_folha_item.id;


--
-- Name: bc_rh_funcionario; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_rh_funcionario (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    pessoa_id bigint NOT NULL,
    cargo_id bigint,
    matricula character varying(30),
    data_admissao date,
    data_demissao date,
    salario numeric(15,2) DEFAULT 0 NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    foto_url text,
    foto_tipo_conteudo character varying(50),
    foto_tamanho bigint,
    percentual_comissao numeric(5,2),
    tipo_colaborador character varying(30),
    usuario_id bigint,
    valor_hora numeric(15,2)
);


--
-- Name: TABLE bc_rh_funcionario; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_rh_funcionario IS 'Funcionários vinculados a uma pessoa do cadastro';


--
-- Name: COLUMN bc_rh_funcionario.foto_url; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_funcionario.foto_url IS 'URL da foto do funcionário';


--
-- Name: COLUMN bc_rh_funcionario.foto_tipo_conteudo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_funcionario.foto_tipo_conteudo IS 'Tipo MIME da foto do funcionário';


--
-- Name: COLUMN bc_rh_funcionario.foto_tamanho; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_rh_funcionario.foto_tamanho IS 'Tamanho em bytes da foto do funcionário';


--
-- Name: bc_rh_funcionario_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_rh_funcionario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_rh_funcionario_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_rh_funcionario_id_seq OWNED BY brasil_saas.bc_rh_funcionario.id;


--
-- Name: bc_srv_ordem_servico; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_srv_ordem_servico (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    numero character varying(20) NOT NULL,
    equipamento character varying(200),
    descricao text,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    usuario_id bigint,
    abertura_at timestamp without time zone DEFAULT now() NOT NULL,
    previsao_at timestamp without time zone,
    fechamento_at timestamp without time zone,
    laudo text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_srv_ordem_servico_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_srv_ordem_servico_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_srv_ordem_servico_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_srv_ordem_servico_id_seq OWNED BY brasil_saas.bc_srv_ordem_servico.id;


--
-- Name: bc_srv_os_apontamento; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_srv_os_apontamento (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    os_id bigint NOT NULL,
    usuario_id bigint NOT NULL,
    data_apontamento timestamp without time zone DEFAULT now() NOT NULL,
    horas numeric(7,2) NOT NULL,
    descricao character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_srv_os_apontamento_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_srv_os_apontamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_srv_os_apontamento_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_srv_os_apontamento_id_seq OWNED BY brasil_saas.bc_srv_os_apontamento.id;


--
-- Name: bc_srv_os_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_srv_os_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    os_id bigint NOT NULL,
    produto_id bigint,
    servico_id bigint,
    quantidade numeric(15,3) NOT NULL,
    valor_unitario numeric(15,4) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_srv_os_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_srv_os_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_srv_os_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_srv_os_item_id_seq OWNED BY brasil_saas.bc_srv_os_item.id;


--
-- Name: bc_ven_bonificacao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_bonificacao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    pedido_origem_id bigint,
    numero character varying(30) NOT NULL,
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    data_emissao date DEFAULT CURRENT_DATE NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    motivo character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ven_bonificacao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_bonificacao IS 'Bonificacoes comerciais';


--
-- Name: bc_ven_bonificacao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_bonificacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_bonificacao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_bonificacao_id_seq OWNED BY brasil_saas.bc_ven_bonificacao.id;


--
-- Name: bc_ven_bonificacao_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_bonificacao_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    bonificacao_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    valor_referencia numeric(15,4) DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ven_bonificacao_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_bonificacao_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_bonificacao_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_bonificacao_item_id_seq OWNED BY brasil_saas.bc_ven_bonificacao_item.id;


--
-- Name: bc_ven_contrato; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_contrato (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    numero character varying(30) NOT NULL,
    descricao character varying(255),
    tipo character varying(30) DEFAULT 'COMERCIAL'::character varying NOT NULL,
    data_inicio date NOT NULL,
    data_fim date,
    valor_mensal numeric(15,2),
    dia_faturamento integer,
    renovacao_automatica boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'ATIVO'::character varying NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ven_contrato; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_contrato IS 'Contratos comerciais e recorrencia';


--
-- Name: bc_ven_contrato_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_contrato_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_contrato_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_contrato_id_seq OWNED BY brasil_saas.bc_ven_contrato.id;


--
-- Name: bc_ven_contrato_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_contrato_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    contrato_id bigint NOT NULL,
    produto_id bigint,
    servico_id bigint,
    quantidade numeric(15,4) DEFAULT 1 NOT NULL,
    valor_unitario numeric(15,4) DEFAULT 0 NOT NULL,
    recorrencia character varying(20),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ven_contrato_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_contrato_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_contrato_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_contrato_item_id_seq OWNED BY brasil_saas.bc_ven_contrato_item.id;


--
-- Name: bc_ven_devolucao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_devolucao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    pedido_id bigint,
    cliente_id bigint NOT NULL,
    numero character varying(30) NOT NULL,
    tipo character varying(20) DEFAULT 'DEVOLUCAO'::character varying NOT NULL,
    motivo character varying(100),
    status character varying(20) DEFAULT 'ABERTA'::character varying NOT NULL,
    data_solicitacao date DEFAULT CURRENT_DATE NOT NULL,
    data_conclusao date,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ven_devolucao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_devolucao IS 'Devolucoes e trocas de vendas';


--
-- Name: bc_ven_devolucao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_devolucao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_devolucao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_devolucao_id_seq OWNED BY brasil_saas.bc_ven_devolucao.id;


--
-- Name: bc_ven_devolucao_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_devolucao_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    devolucao_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    valor_unitario numeric(15,4) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    lote_id bigint,
    numero_serie_id bigint,
    destino_estoque character varying(20) DEFAULT 'DISPONIVEL'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: bc_ven_devolucao_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_devolucao_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_devolucao_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_devolucao_item_id_seq OWNED BY brasil_saas.bc_ven_devolucao_item.id;


--
-- Name: bc_ven_pedido; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_pedido (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    empresa_id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    numero character varying(255),
    tipo character varying(255) DEFAULT 'PEDIDO'::character varying NOT NULL,
    status character varying(255) DEFAULT 'ABERTO'::character varying NOT NULL,
    condicao_pagamento_id bigint,
    data_emissao date NOT NULL,
    data_entrega date,
    valor_produtos numeric(15,2) DEFAULT 0 NOT NULL,
    valor_servicos numeric(15,2) DEFAULT 0 NOT NULL,
    valor_desconto numeric(15,2) DEFAULT 0 NOT NULL,
    valor_frete numeric(15,2) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) DEFAULT 0 NOT NULL,
    titulo_id bigint,
    observacao text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    vendedor_id bigint,
    tabela_preco_id bigint,
    percentual_desconto numeric(7,4) DEFAULT 0,
    canal_venda character varying(30),
    origem character varying(30)
);


--
-- Name: TABLE bc_ven_pedido; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_pedido IS 'Pedidos de venda e orçamentos';


--
-- Name: COLUMN bc_ven_pedido.tipo; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_ven_pedido.tipo IS 'ORCAMENTO ou PEDIDO';


--
-- Name: COLUMN bc_ven_pedido.status; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_ven_pedido.status IS 'ABERTO, FATURADO ou CANCELADO';


--
-- Name: COLUMN bc_ven_pedido.titulo_id; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON COLUMN brasil_saas.bc_ven_pedido.titulo_id IS 'Título a receber gerado no financeiro';


--
-- Name: bc_ven_pedido_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_pedido_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_pedido_id_seq OWNED BY brasil_saas.bc_ven_pedido.id;


--
-- Name: bc_ven_pedido_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_pedido_item (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    pedido_id bigint NOT NULL,
    numero_item integer NOT NULL,
    produto_id bigint,
    servico_id bigint,
    descricao character varying(300),
    quantidade numeric(15,3) NOT NULL,
    unidade character varying(10),
    valor_unitario numeric(15,4) NOT NULL,
    valor_desconto numeric(15,2) DEFAULT 0 NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    criado_estoque boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone,
    uuid uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: bc_ven_pedido_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_pedido_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_pedido_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_pedido_item_id_seq OWNED BY brasil_saas.bc_ven_pedido_item.id;


--
-- Name: bc_ven_regra_comissao; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_regra_comissao (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    vendedor_id bigint,
    vigencia_inicio date,
    vigencia_fim date,
    meta_valor numeric(15,2),
    faixa_valor_min numeric(15,2) DEFAULT 0 NOT NULL,
    faixa_valor_max numeric(15,2),
    percentual numeric(7,4) NOT NULL,
    base_calculo character varying(30) DEFAULT 'VALOR_LIQUIDO'::character varying NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ven_regra_comissao; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_regra_comissao IS 'Regras de comissao por vendedor, meta e faixa';


--
-- Name: bc_ven_regra_comissao_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_regra_comissao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_regra_comissao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_regra_comissao_id_seq OWNED BY brasil_saas.bc_ven_regra_comissao.id;


--
-- Name: bc_ven_tabela_preco; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_tabela_preco (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    codigo character varying(30),
    descricao character varying(255),
    moeda character varying(3) DEFAULT 'BRL'::bpchar NOT NULL,
    vigencia_inicio date,
    vigencia_fim date,
    percentual_desconto_maximo numeric(7,4) DEFAULT 0 NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ven_tabela_preco; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_tabela_preco IS 'Tabelas de preco comerciais por empresa';


--
-- Name: bc_ven_tabela_preco_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_tabela_preco_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_tabela_preco_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_tabela_preco_id_seq OWNED BY brasil_saas.bc_ven_tabela_preco.id;


--
-- Name: bc_ven_tabela_preco_item; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.bc_ven_tabela_preco_item (
    id bigint NOT NULL,
    uuid uuid DEFAULT gen_random_uuid(),
    empresa_id bigint NOT NULL,
    tabela_preco_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    preco numeric(15,4) NOT NULL,
    preco_minimo numeric(15,4),
    percentual_desconto_maximo numeric(7,4) DEFAULT 0 NOT NULL,
    vigencia_inicio date,
    vigencia_fim date,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    created_by bigint,
    updated_by bigint,
    deleted_at timestamp without time zone
);


--
-- Name: TABLE bc_ven_tabela_preco_item; Type: COMMENT; Schema: brasil_saas; Owner: -
--

COMMENT ON TABLE brasil_saas.bc_ven_tabela_preco_item IS 'Precos de produtos por tabela comercial';


--
-- Name: bc_ven_tabela_preco_item_id_seq; Type: SEQUENCE; Schema: brasil_saas; Owner: -
--

CREATE SEQUENCE brasil_saas.bc_ven_tabela_preco_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bc_ven_tabela_preco_item_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas; Owner: -
--

ALTER SEQUENCE brasil_saas.bc_ven_tabela_preco_item_id_seq OWNED BY brasil_saas.bc_ven_tabela_preco_item.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: brasil_saas; Owner: -
--

CREATE TABLE brasil_saas.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: dim_cliente; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.dim_cliente (
    id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    cpf_cnpj character varying(20) NOT NULL,
    tipo_pessoa character varying(20) NOT NULL,
    segmento character varying(100),
    regiao character varying(100),
    estado character varying(2),
    cidade character varying(100),
    grupo_cliente character varying(100),
    classificacao character varying(20),
    data_primeira_compra date,
    data_ultima_compra date,
    ativo boolean DEFAULT true NOT NULL,
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: dim_cliente_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.dim_cliente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_cliente_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.dim_cliente_id_seq OWNED BY brasil_saas_dl.dim_cliente.id;


--
-- Name: dim_empresa; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.dim_empresa (
    id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    cnpj character varying(20),
    razao_social character varying(200),
    grupo_economico character varying(100),
    segmento character varying(100),
    porte character varying(20),
    data_fundacao date,
    ativo boolean DEFAULT true NOT NULL,
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: dim_empresa_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.dim_empresa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_empresa_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.dim_empresa_id_seq OWNED BY brasil_saas_dl.dim_empresa.id;


--
-- Name: dim_produto; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.dim_produto (
    id bigint NOT NULL,
    produto_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    codigo character varying(50) NOT NULL,
    nome character varying(200) NOT NULL,
    descricao text,
    categoria_id bigint,
    categoria_nome character varying(100),
    marca_id bigint,
    marca_nome character varying(100),
    unidade character varying(10) NOT NULL,
    tipo_produto character varying(50) NOT NULL,
    familia_produto character varying(100),
    grupo_produto character varying(100),
    linha_produto character varying(100),
    ncm character varying(20),
    cest character varying(20),
    cst character varying(20),
    peso_bruto numeric(15,6),
    peso_liquido numeric(15,6),
    volume numeric(15,6),
    ativo boolean DEFAULT true NOT NULL,
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: dim_produto_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.dim_produto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_produto_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.dim_produto_id_seq OWNED BY brasil_saas_dl.dim_produto.id;


--
-- Name: dim_tempo; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.dim_tempo (
    id bigint NOT NULL,
    data date NOT NULL,
    dia_da_semana integer NOT NULL,
    nome_dia_da_semana character varying(20) NOT NULL,
    dia_do_mes integer NOT NULL,
    dia_do_ano integer NOT NULL,
    semana_do_ano integer NOT NULL,
    mes integer NOT NULL,
    nome_mes character varying(20) NOT NULL,
    trimestre integer NOT NULL,
    ano integer NOT NULL,
    eh_fim_de_semana boolean NOT NULL,
    eh_feriado boolean DEFAULT false NOT NULL,
    nome_feriado character varying(100),
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: dim_tempo_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.dim_tempo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_tempo_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.dim_tempo_id_seq OWNED BY brasil_saas_dl.dim_tempo.id;


--
-- Name: ft_compras; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.ft_compras (
    id bigint NOT NULL,
    data_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    fornecedor_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    categoria_id bigint,
    pedido_compra_id bigint NOT NULL,
    item_pedido_id bigint,
    quantidade numeric(15,4) NOT NULL,
    valor_unitario numeric(15,2) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    tipo_compra character varying(50) NOT NULL,
    status_pedido character varying(50) NOT NULL,
    data_pedido date NOT NULL,
    data_entrega date,
    data_recebimento date,
    condicao_pagamento character varying(50),
    prazo_entrega integer,
    frete numeric(15,2),
    impostos numeric(15,2),
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: ft_compras_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.ft_compras_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ft_compras_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.ft_compras_id_seq OWNED BY brasil_saas_dl.ft_compras.id;


--
-- Name: ft_estoque; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.ft_estoque (
    id bigint NOT NULL,
    data_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    categoria_id bigint,
    centro_custo_id bigint,
    tipo_movimentacao character varying(50) NOT NULL,
    quantidade numeric(15,4) NOT NULL,
    valor_unitario numeric(15,2),
    valor_total numeric(15,2),
    saldo_anterior numeric(15,4),
    saldo_atual numeric(15,4),
    data_movimentacao date NOT NULL,
    documento_origem character varying(100),
    documento_id bigint,
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: ft_estoque_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.ft_estoque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ft_estoque_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.ft_estoque_id_seq OWNED BY brasil_saas_dl.ft_estoque.id;


--
-- Name: ft_financeiro; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.ft_financeiro (
    id bigint NOT NULL,
    data_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    tipo_lancamento character varying(50) NOT NULL,
    categoria_lancamento character varying(100) NOT NULL,
    centro_custo_id bigint,
    cliente_fornecedor_id bigint,
    cliente_fornecedor_tipo character varying(20),
    titulo_id bigint,
    valor numeric(15,2) NOT NULL,
    valor_liquido numeric(15,2),
    data_vencimento date,
    data_pagamento date,
    status character varying(50) NOT NULL,
    forma_pagamento character varying(50),
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: ft_financeiro_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.ft_financeiro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ft_financeiro_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.ft_financeiro_id_seq OWNED BY brasil_saas_dl.ft_financeiro.id;


--
-- Name: ft_producao; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.ft_producao (
    id bigint NOT NULL,
    data_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    ordem_producao_id bigint NOT NULL,
    produto_id bigint NOT NULL,
    quantidade_produzida numeric(15,4) NOT NULL,
    quantidade_prevista numeric(15,4),
    tempo_producao_minutos integer,
    tempo_padrao_minutos integer,
    custo_material numeric(15,2),
    custo_mao_obra numeric(15,2),
    custo_indireto numeric(15,2),
    custo_total numeric(15,2),
    status character varying(50) NOT NULL,
    data_inicio date,
    data_fim date,
    centro_custo_id bigint,
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: ft_producao_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.ft_producao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ft_producao_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.ft_producao_id_seq OWNED BY brasil_saas_dl.ft_producao.id;


--
-- Name: ft_vendas; Type: TABLE; Schema: brasil_saas_dl; Owner: -
--

CREATE TABLE brasil_saas_dl.ft_vendas (
    id bigint NOT NULL,
    data_id bigint NOT NULL,
    empresa_id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    vendedor_id bigint,
    produto_id bigint NOT NULL,
    categoria_id bigint,
    pedido_venda_id bigint NOT NULL,
    item_pedido_id bigint,
    quantidade numeric(15,4) NOT NULL,
    valor_unitario numeric(15,2) NOT NULL,
    valor_total numeric(15,2) NOT NULL,
    valor_custo numeric(15,2),
    margem_bruta numeric(15,2),
    percentual_margem numeric(10,2),
    tipo_venda character varying(50) NOT NULL,
    status_pedido character varying(50) NOT NULL,
    data_pedido date NOT NULL,
    data_entrega date,
    data_faturamento date,
    condicao_pagamento character varying(50),
    prazo_entrega integer,
    frete numeric(15,2),
    desconto numeric(15,2),
    impostos numeric(15,2),
    data_criacao date DEFAULT CURRENT_DATE
);


--
-- Name: ft_vendas_id_seq; Type: SEQUENCE; Schema: brasil_saas_dl; Owner: -
--

CREATE SEQUENCE brasil_saas_dl.ft_vendas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ft_vendas_id_seq; Type: SEQUENCE OWNED BY; Schema: brasil_saas_dl; Owner: -
--

ALTER SEQUENCE brasil_saas_dl.ft_vendas_id_seq OWNED BY brasil_saas_dl.ft_vendas.id;


--
-- Name: base_cep; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base_cep (
    cep character varying(8) NOT NULL,
    logradouro character varying(255),
    bairro character varying(255),
    cidade character varying(255),
    uf character varying(2)
);


--
-- Name: fcaixa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fcaixa (
    codcaixa integer NOT NULL,
    descricaocaixa character varying(255) NOT NULL,
    agencia character varying(50),
    nomebanco character varying(100),
    numeroconta character varying(50),
    saldobanco numeric(15,2) DEFAULT 0.0
);


--
-- Name: fcaixa_codcaixa_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fcaixa_codcaixa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fcaixa_codcaixa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fcaixa_codcaixa_seq OWNED BY public.fcaixa.codcaixa;


--
-- Name: fcentrocusto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fcentrocusto (
    codcusto integer NOT NULL,
    descricaocusto character varying(255) NOT NULL,
    ativo character varying(1) DEFAULT 'S'::character varying,
    aceitalancamento character varying(1) DEFAULT 'S'::character varying,
    tipo character varying(1) DEFAULT 'D'::character varying
);


--
-- Name: fcentrocusto_codcusto_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fcentrocusto_codcusto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fcentrocusto_codcusto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fcentrocusto_codcusto_seq OWNED BY public.fcentrocusto.codcusto;


--
-- Name: fcfo_codcfo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fcfo_codcfo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fcfo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fcfo (
    codcfo public.docod DEFAULT nextval('public.fcfo_codcfo_seq'::regclass) NOT NULL,
    nomefantasia character varying(255),
    nomerazao character varying(255),
    endereco character varying(255),
    bairro character varying(255),
    cidade character varying(255),
    cep character varying(255),
    uf public.dom2,
    telefone character varying(255),
    celular character varying(255),
    tipo public.dom1,
    cnpj character varying(255),
    inscestadual character varying(255),
    inscmunicipal character varying(255),
    contato character varying(255),
    obs character varying(255),
    datacad public.dodata,
    mail character varying(255),
    html character varying(255),
    codpais public.dom5,
    pais character varying(255),
    numero character varying(255),
    codmunicipio character varying(255),
    tabelapercentual public.dovalor,
    idcidade public.docod,
    datanascimento public.dodata,
    natureza_juridica character varying(2) DEFAULT 'PJ'::character varying,
    tipo_doc_identidade character varying(3),
    nirf character varying(255),
    classificacao_telefone character varying(255),
    classificacao_celular character varying(255)
);


--
-- Name: fcondicao_codcondicao_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fcondicao_codcondicao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fcondicao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fcondicao (
    codcondicao integer DEFAULT nextval('public.fcondicao_codcondicao_seq'::regclass) NOT NULL,
    descricaocondicao character varying(255),
    numeroparcela public.docod,
    baixa1 public.dom1,
    par1 public.docod,
    par2 public.docod,
    par3 public.docod,
    par4 public.docod,
    par5 public.docod,
    par6 public.docod,
    par7 public.docod,
    par8 public.docod,
    par9 public.docod,
    par10 public.docod,
    par11 public.docod,
    par12 public.docod,
    par13 public.docod,
    par14 public.docod,
    par15 public.docod
);


--
-- Name: fcusto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fcusto (
    codcusto public.docod NOT NULL,
    codmascara public.dom5,
    mascaranivel public.dom2,
    descricaocusto character varying(255),
    idgrupo public.docod,
    custotipo public.dom1,
    custoativo public.dom1,
    aceitalan public.dom1,
    descricaocustogrupo character varying(255),
    valoragenda public.dovalor
);


--
-- Name: fcusto_codcusto_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fcusto_codcusto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fcusto_codcusto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fcusto_codcusto_seq OWNED BY public.fcusto.codcusto;


--
-- Name: fdatas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fdatas (
    iddata public.docod NOT NULL,
    datainicial public.dodata,
    datafinal public.dodata
);


--
-- Name: fdatas_iddata_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fdatas_iddata_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fdatas_iddata_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fdatas_iddata_seq OWNED BY public.fdatas.iddata;


--
-- Name: fdia; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fdia (
    refdia integer NOT NULL,
    baixadia public.dom1,
    datadia public.dodata,
    valorabertura public.dovalor,
    usuariodia public.docod,
    obsdia character varying(255)
);


--
-- Name: fdia_refdia_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fdia_refdia_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fdia_refdia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fdia_refdia_seq OWNED BY public.fdia.refdia;


--
-- Name: fdocumento_coddoc_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fdocumento_coddoc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fdocumento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fdocumento (
    coddoc public.docod DEFAULT nextval('public.fdocumento_coddoc_seq'::regclass) NOT NULL,
    descricaodoc character varying(255),
    doccontabil public.dom1
);


--
-- Name: fempresa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fempresa (
    codigo public.docod NOT NULL,
    nome character varying(255),
    nomerelatorio character varying(255),
    inscricaoestadual character varying(255),
    cnpj character varying(255),
    endereco character varying(255),
    bairro character varying(255),
    cidade character varying(255),
    cep character varying(255),
    uf public.dom2,
    telefone character varying(255),
    logo bytea,
    obs public.dmemo,
    nomefazenda character varying(255)
);


--
-- Name: fempresa_codigo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fempresa_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fempresa_codigo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fempresa_codigo_seq OWNED BY public.fempresa.codigo;


--
-- Name: fempresa_vinculo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fempresa_vinculo (
    codvinculo integer NOT NULL,
    codmatriz integer NOT NULL,
    codfilial integer
);


--
-- Name: fempresa_vinculo_codvinculo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fempresa_vinculo_codvinculo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fempresa_vinculo_codvinculo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fempresa_vinculo_codvinculo_seq OWNED BY public.fempresa_vinculo.codvinculo;


--
-- Name: fextrato; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fextrato (
    idlanextrato public.docod NOT NULL,
    extratoidempresa public.docod,
    extratodata public.dodata,
    extratoidcaixa public.docod,
    extratoidcfo public.docod,
    extratodocumento character varying(255),
    extratovalor public.dovalor,
    extratobaixado public.dom1,
    extratodatabaixa public.dodata,
    extratohistorico character varying(255),
    extratousuario character varying(255),
    extratoidlan public.docod,
    extratoserie public.dom2,
    extratotipocd public.dom1,
    extratooperacao character varying(255),
    extratonomefavorecido character varying(255),
    extratocheque public.docod,
    extratodatacheque public.dodata,
    extratopre public.dom1,
    extratolancamentohistorico character varying(255)
);


--
-- Name: fextrato_idlanextrato_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fextrato_idlanextrato_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fextrato_idlanextrato_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fextrato_idlanextrato_seq OWNED BY public.fextrato.idlanextrato;


--
-- Name: ffinanceiro; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ffinanceiro (
    codfinanceiro integer NOT NULL,
    codmovimento integer,
    codcliente integer NOT NULL,
    datavencimento date NOT NULL,
    valor numeric(15,2) DEFAULT 0.00 NOT NULL,
    tipolancamento character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'PENDENTE'::character varying NOT NULL
);


--
-- Name: ffinanceiro_codfinanceiro_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ffinanceiro_codfinanceiro_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ffinanceiro_codfinanceiro_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ffinanceiro_codfinanceiro_seq OWNED BY public.ffinanceiro.codfinanceiro;


--
-- Name: ffuncionario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ffuncionario (
    codfuncionario public.docod NOT NULL,
    nomefuncionario character varying(255),
    comissao public.dovalor,
    ativo public.dom1,
    login_db character varying(255)
);


--
-- Name: ffuncionario_codfuncionario_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ffuncionario_codfuncionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ffuncionario_codfuncionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ffuncionario_codfuncionario_seq OWNED BY public.ffuncionario.codfuncionario;


--
-- Name: fitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fitem (
    refitem public.docod NOT NULL,
    idlanmov public.docod,
    idcfoitem smallint,
    idempresaitem public.docod,
    dataitem public.dodata,
    idproduto public.docod,
    unidadeitem public.dom2,
    produtonomeitem character varying(255),
    tipoitem public.dom1,
    quantidadeitem public.dmkqt,
    valorunitarioitem public.dovalor,
    totalitem public.dovalor,
    codvariacao integer
);


--
-- Name: fitem_refitem_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fitem_refitem_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fitem_refitem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fitem_refitem_seq OWNED BY public.fitem.refitem;


--
-- Name: flan_idlan_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flan_idlan_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flan (
    idlan public.docod DEFAULT nextval('public.flan_idlan_seq'::regclass) NOT NULL,
    datalan public.dodata,
    idempresa public.docod,
    idtipo public.docod,
    idcd public.dom1,
    baixado public.dom1,
    idcfo public.docod,
    idcustolan public.docod,
    idcustomascaralan public.dom5,
    idtipodoc public.docod,
    serie public.dom2,
    idmoeda public.docod,
    moedanome character varying(255),
    documento character varying(255),
    duplicata character varying(255),
    dataemissao public.dodata,
    valorlancamento public.dovalor,
    datavencimento public.dodata,
    usuario character varying(255),
    usuarioedicao character varying(255),
    obslan character varying(255),
    databaixa public.dodata,
    idcaixa public.docod,
    valorbaixado public.dovalor,
    valorquitado public.dovalor,
    valordesconto public.dovalor,
    valorjuro public.dovalor,
    valordiferenca public.dovalor,
    obsbaixa character varying(255),
    idos public.docod,
    idparcela public.docod,
    id_pessoa_parceiro integer
);


--
-- Name: fmov; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fmov (
    idmov public.docod NOT NULL,
    datalan public.dodata,
    idempresamov public.docod,
    baixamov public.dom1,
    datamov public.dodata,
    idcfomov public.docod,
    idveiculomov public.docod,
    idcustomov public.docod,
    idcustomascaramov public.dom5,
    placamov character varying(255),
    nomemotorista character varying(255),
    modeloveiculomov character varying(255),
    requisicaomov character varying(255),
    notamov character varying(255),
    idfuncionariomov public.docod,
    idpgtomov public.docod,
    idmoedamov public.docod,
    moedamov character varying(255),
    valorbrutomov public.dovalor,
    valordescontomov public.dovalor,
    valorliquidomov public.dovalor,
    obsmov character varying(255),
    usariomov character varying(255),
    obsmovfechamento character varying(255),
    datafechamentomov public.dodata,
    prismamov character varying(255),
    seriemov public.dom2,
    idcaixamov public.docod,
    idagendamento public.docod,
    id_pessoa_cliente integer,
    id_pessoa_funcionario integer
);


--
-- Name: fmov_idmov_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fmov_idmov_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fmov_idmov_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fmov_idmov_seq OWNED BY public.fmov.idmov;


--
-- Name: fmovimento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fmovimento (
    codmovimento integer NOT NULL,
    codcliente integer NOT NULL,
    dataemissao date NOT NULL,
    totalfatura numeric(15,2) DEFAULT 0.00 NOT NULL,
    tipomovimento character varying(255) DEFAULT 'OS'::character varying NOT NULL
);


--
-- Name: fmovimento_codmovimento_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fmovimento_codmovimento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fmovimento_codmovimento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fmovimento_codmovimento_seq OWNED BY public.fmovimento.codmovimento;


--
-- Name: fmovimento_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fmovimento_item (
    coditem integer NOT NULL,
    codmovimento integer NOT NULL,
    codproduto integer NOT NULL,
    quantidade numeric(15,2) DEFAULT 1.00 NOT NULL,
    valorunitario numeric(15,2) DEFAULT 0.00 NOT NULL,
    totalitem numeric(15,2) DEFAULT 0.00 NOT NULL,
    codvariacao integer
);


--
-- Name: fmovimento_item_coditem_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fmovimento_item_coditem_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fmovimento_item_coditem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fmovimento_item_coditem_seq OWNED BY public.fmovimento_item.coditem;


--
-- Name: fnota; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fnota (
    id_nota integer NOT NULL,
    id_venda integer,
    numero_nota character varying(255) NOT NULL,
    serie character varying(5),
    modelo character varying(5),
    chave_acesso character varying(255),
    data_emissao date DEFAULT CURRENT_DATE,
    centro_custo integer,
    valor_total numeric(15,2) DEFAULT 0.00,
    status character varying(255) DEFAULT 'EMITIDA'::character varying,
    observacao text,
    codmovimento integer
);


--
-- Name: fnota_id_nota_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fnota_id_nota_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fnota_id_nota_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fnota_id_nota_seq OWNED BY public.fnota.id_nota;


--
-- Name: fnota_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fnota_item (
    id_item integer NOT NULL,
    id_nota integer NOT NULL,
    codvariacao integer,
    quantidade numeric(15,2) DEFAULT 1.00 NOT NULL,
    valor_unitario numeric(15,2) DEFAULT 0.00 NOT NULL,
    total_item numeric(15,2) DEFAULT 0.00 NOT NULL,
    ncm character varying(255),
    cfop character varying(255),
    icms numeric(5,2),
    pis numeric(5,2),
    cofins numeric(5,2),
    iss numeric(5,2)
);


--
-- Name: fnota_item_id_item_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fnota_item_id_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fnota_item_id_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fnota_item_id_item_seq OWNED BY public.fnota_item.id_item;


--
-- Name: fpessoa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fpessoa (
    id_pessoa integer NOT NULL,
    tipo_pessoa character varying(2) DEFAULT 'PJ'::character varying,
    nome_razao character varying(255) NOT NULL,
    nome_fantasia character varying(255),
    cpf_cnpj character varying(255),
    rg_ie character varying(255),
    im character varying(255),
    cep character varying(255),
    logradouro character varying(255),
    numero character varying(255),
    bairro character varying(255),
    cidade character varying(255),
    uf character varying(2),
    codmunicipio character varying(255),
    idcidade integer,
    telefone character varying(255),
    celular character varying(255),
    contato character varying(255),
    email character varying(255),
    site character varying(255),
    obs character varying(255),
    datacad date DEFAULT CURRENT_DATE,
    datanascimento date,
    comissao numeric(15,4) DEFAULT 0,
    is_cliente boolean DEFAULT false,
    is_fornecedor boolean DEFAULT false,
    is_funcionario boolean DEFAULT false,
    id_usuario integer,
    old_codfuncionario integer
);


--
-- Name: fpessoa_id_pessoa_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fpessoa_id_pessoa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fpessoa_id_pessoa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fpessoa_id_pessoa_seq OWNED BY public.fpessoa.id_pessoa;


--
-- Name: gen_fproduto_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fproduto_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto (
    codproduto public.docod DEFAULT nextval('public.gen_fproduto_id'::regclass) NOT NULL,
    descricaoproduto character varying(255),
    unidadeproduto public.dom2,
    precocusto public.dovalor,
    precovenda public.dovalor,
    tipoproduto character varying(255),
    idgrupoproduto public.docod,
    origem character varying(2),
    ncm character varying(255),
    codigo_issqn character varying(20),
    valor_servico numeric(15,2),
    municipio_servico character varying(120),
    aliquota_issqn numeric(8,4)
);


--
-- Name: fproduto_ecommerce; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto_ecommerce (
    codecommerce integer NOT NULL,
    codproduto integer NOT NULL,
    peso_gramas integer DEFAULT 0,
    comprimento_cm numeric(10,2) DEFAULT 0.00,
    largura_cm numeric(10,2) DEFAULT 0.00,
    altura_cm numeric(10,2) DEFAULT 0.00,
    descricao_longa text,
    palavras_chave text
);


--
-- Name: fproduto_ecommerce_codecommerce_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_ecommerce_codecommerce_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_ecommerce_codecommerce_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_ecommerce_codecommerce_seq OWNED BY public.fproduto_ecommerce.codecommerce;


--
-- Name: fproduto_fiscal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto_fiscal (
    codproduto integer NOT NULL,
    cest character varying(255),
    icms numeric(5,2),
    pis numeric(5,2),
    cofins numeric(5,2),
    iss numeric(5,2)
);


--
-- Name: fproduto_fiscal_codproduto_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_fiscal_codproduto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_fiscal_codproduto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_fiscal_codproduto_seq OWNED BY public.fproduto_fiscal.codproduto;


--
-- Name: fproduto_imagem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto_imagem (
    codimagem integer NOT NULL,
    codvariacao integer NOT NULL,
    url_caminho character varying(500) NOT NULL,
    is_principal boolean DEFAULT false
);


--
-- Name: fproduto_imagem_codimagem_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_imagem_codimagem_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_imagem_codimagem_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_imagem_codimagem_seq OWNED BY public.fproduto_imagem.codimagem;


--
-- Name: fproduto_kit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto_kit (
    codkit integer NOT NULL,
    codproduto_filho integer NOT NULL,
    quantidade integer DEFAULT 1
);


--
-- Name: fproduto_kit_codkit_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_kit_codkit_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_kit_codkit_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_kit_codkit_seq OWNED BY public.fproduto_kit.codkit;


--
-- Name: fproduto_kit_codproduto_filho_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_kit_codproduto_filho_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_kit_codproduto_filho_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_kit_codproduto_filho_seq OWNED BY public.fproduto_kit.codproduto_filho;


--
-- Name: fproduto_movimento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto_movimento (
    codmov integer NOT NULL,
    codvariacao integer NOT NULL,
    tipo_mov character varying(255),
    quantidade numeric(15,4) NOT NULL,
    data_mov timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    documento character varying(255),
    observacao text,
    CONSTRAINT fproduto_movimento_tipo_mov_check CHECK (((tipo_mov)::text = ANY (ARRAY[('ENTRADA'::character varying)::text, ('SAIDA'::character varying)::text])))
);


--
-- Name: fproduto_movimento_codmov_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_movimento_codmov_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_movimento_codmov_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_movimento_codmov_seq OWNED BY public.fproduto_movimento.codmov;


--
-- Name: fproduto_variacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fproduto_variacao (
    codvariacao integer NOT NULL,
    codproduto integer NOT NULL,
    cor character varying(255),
    tamanho character varying(255),
    codigo_barras character varying(255),
    preco_fornecedor numeric(15,2),
    preco_venda numeric(15,2),
    saldo_estoque numeric(15,4) DEFAULT 0,
    nome_especifico character varying(255),
    lote character varying(255),
    validade date,
    observacao text
);


--
-- Name: fproduto_variacao_codvariacao_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fproduto_variacao_codvariacao_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fproduto_variacao_codvariacao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fproduto_variacao_codvariacao_seq OWNED BY public.fproduto_variacao.codvariacao;


--
-- Name: frecibo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.frecibo (
    idrecibo public.docod NOT NULL,
    cliforrecibo public.docod,
    nomerecibo character varying(255),
    datarecibo public.dodata,
    valorrecibo public.dovalor,
    historicorecibo public.dmemo,
    usuariorecibo character varying(255),
    idempersarecibo public.docod,
    vencimetorecibo public.dodata
);


--
-- Name: frecibo_idrecibo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.frecibo_idrecibo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: frecibo_idrecibo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.frecibo_idrecibo_seq OWNED BY public.frecibo.idrecibo;


--
-- Name: ftipo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ftipo (
    codtipo public.docod NOT NULL,
    descricaotipo character varying(255),
    tipoconta public.dom1
);


--
-- Name: ftipo_codtipo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ftipo_codtipo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ftipo_codtipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ftipo_codtipo_seq OWNED BY public.ftipo.codtipo;


--
-- Name: ftipopagamento_codtipo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ftipopagamento_codtipo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ftipopagamento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ftipopagamento (
    codtipo public.docod DEFAULT nextval('public.ftipopagamento_codtipo_seq'::regclass) NOT NULL,
    descricaopagamento character varying(255),
    seriepagamento public.dom2
);


--
-- Name: fusuario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fusuario (
    codigo public.docod NOT NULL,
    nome character varying(255),
    senha character varying(255),
    datalimite public.dodata,
    acessomodulo public.dom1,
    cupom public.dom1,
    edita public.dom1,
    excluir public.dom1,
    acessomodulo1 public.dom1,
    acessomodulo2 public.dom1,
    acessomodulo3 public.dom1,
    acessomodulo4 public.dom1,
    diretoriopecuaria character varying(255),
    foto public.dom1
);


--
-- Name: fusuario_codigo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fusuario_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fusuario_codigo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fusuario_codigo_seq OWNED BY public.fusuario.codigo;


--
-- Name: fvenda; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fvenda (
    id_venda integer NOT NULL,
    id_cliente integer,
    data_venda date DEFAULT CURRENT_DATE,
    condicao_pagamento integer,
    tipo_pagamento integer,
    centro_custo integer,
    valor_total numeric(15,2) DEFAULT 0.00,
    status character varying(255) DEFAULT 'ABERTA'::character varying,
    observacao text,
    id_recibo integer
);


--
-- Name: fvenda_id_venda_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fvenda_id_venda_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fvenda_id_venda_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fvenda_id_venda_seq OWNED BY public.fvenda.id_venda;


--
-- Name: fvenda_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fvenda_item (
    id_item integer NOT NULL,
    id_venda integer NOT NULL,
    codvariacao integer,
    quantidade numeric(15,2) DEFAULT 1.00 NOT NULL,
    valor_unitario numeric(15,2) DEFAULT 0.00 NOT NULL,
    total_item numeric(15,2) DEFAULT 0.00 NOT NULL
);


--
-- Name: fvenda_item_id_item_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fvenda_item_id_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fvenda_item_id_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fvenda_item_id_item_seq OWNED BY public.fvenda_item.id_item;


--
-- Name: gen_fcfo_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fcfo_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_fcusto_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fcusto_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_fdia_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fdia_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_fextrato_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fextrato_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_ffuncionario_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_ffuncionario_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_fitem_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fitem_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_flan_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_flan_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_fmov_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_fmov_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_frecibo_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_frecibo_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gen_tmunicipo_id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gen_tmunicipo_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gparametro; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gparametro (
    idparametro public.docod NOT NULL,
    modulo1 public.dom1,
    modulo2 public.dom1,
    modulo3 public.dom1,
    modulo4 public.dom1,
    usarateio public.dom1,
    data public.dodata
);


--
-- Name: gparametro_idparametro_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gparametro_idparametro_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gparametro_idparametro_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gparametro_idparametro_seq OWNED BY public.gparametro.idparametro;


--
-- Name: tcnae_servico; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tcnae_servico (
    cnae character varying(12) NOT NULL,
    cnae_descricao text,
    codigo_item character varying(12) NOT NULL
);


--
-- Name: tissqn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tissqn (
    id integer NOT NULL,
    cod_ibge integer NOT NULL,
    uf character varying(2) NOT NULL,
    municipio character varying(150) NOT NULL,
    codigo_servico character varying(20) NOT NULL,
    codigo_municipal character varying(20),
    aliquota numeric(5,2) DEFAULT 5 NOT NULL,
    vigencia date,
    descricao text
);


--
-- Name: tissqn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tissqn_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tissqn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tissqn_id_seq OWNED BY public.tissqn.id;


--
-- Name: tmp_restaura; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tmp_restaura (
    x text
);


--
-- Name: tmunicipio_refmunicipio_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tmunicipio_refmunicipio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tmunicipio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tmunicipio (
    refmunicipio public.docod DEFAULT nextval('public.tmunicipio_refmunicipio_seq'::regclass) NOT NULL,
    nomemunucipio character varying(255),
    unfmunicipio public.dom2,
    paismunicipio character varying(255),
    paiscodigo public.dom5,
    codigoibge character varying(255)
);


--
-- Name: tmunicipio_ref_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tmunicipio_ref_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tncm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tncm (
    codigo character varying(255) NOT NULL,
    descricao text
);


--
-- Name: tservico_lc116; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tservico_lc116 (
    codigo_item character varying(12) NOT NULL,
    descricao text
);


--
-- Name: bc_bi_dashboard id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_dashboard_id_seq'::regclass);


--
-- Name: bc_bi_dashboard_widget id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard_widget ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_dashboard_widget_id_seq'::regclass);


--
-- Name: bc_bi_indicador id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_indicador ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_indicador_id_seq'::regclass);


--
-- Name: bc_bi_kpi id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_kpi ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_kpi_id_seq'::regclass);


--
-- Name: bc_bi_relatorio id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_relatorio_id_seq'::regclass);


--
-- Name: bc_bi_relatorio_agendado id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio_agendado ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_relatorio_agendado_id_seq'::regclass);


--
-- Name: bc_bi_report id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_report_id_seq'::regclass);


--
-- Name: bc_bi_report_parameter id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report_parameter ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_bi_report_parameter_id_seq'::regclass);


--
-- Name: bc_cad_base_cep id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_base_cep ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_base_cep_id_seq'::regclass);


--
-- Name: bc_cad_categoria id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_categoria ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_categoria_id_seq'::regclass);


--
-- Name: bc_cad_cliente id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_cliente ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_cliente_id_seq'::regclass);


--
-- Name: bc_cad_contato id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_contato ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_contato_id_seq'::regclass);


--
-- Name: bc_cad_documento_fiscal id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_documento_fiscal ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_documento_fiscal_id_seq'::regclass);


--
-- Name: bc_cad_endereco id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_endereco ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_endereco_id_seq'::regclass);


--
-- Name: bc_cad_fornecedor id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_fornecedor ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_fornecedor_id_seq'::regclass);


--
-- Name: bc_cad_marca id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_marca ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_marca_id_seq'::regclass);


--
-- Name: bc_cad_municipio id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_municipio ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_municipio_id_seq'::regclass);


--
-- Name: bc_cad_papel id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_papel ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_papel_id_seq'::regclass);


--
-- Name: bc_cad_pessoa id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_pessoa_id_seq'::regclass);


--
-- Name: bc_cad_pessoa_fisica id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_fisica ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_pessoa_fisica_id_seq'::regclass);


--
-- Name: bc_cad_pessoa_juridica id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_juridica ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_pessoa_juridica_id_seq'::regclass);


--
-- Name: bc_cad_produto id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_produto_id_seq'::regclass);


--
-- Name: bc_cad_produto_ecommerce id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_ecommerce ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_produto_ecommerce_id_seq'::regclass);


--
-- Name: bc_cad_produto_imagem id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_imagem ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_produto_imagem_id_seq'::regclass);


--
-- Name: bc_cad_produto_kit id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_kit ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_produto_kit_id_seq'::regclass);


--
-- Name: bc_cad_produto_variacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_variacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_produto_variacao_id_seq'::regclass);


--
-- Name: bc_cad_servico id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_servico ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_servico_id_seq'::regclass);


--
-- Name: bc_cad_transportadora id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_transportadora ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_transportadora_id_seq'::regclass);


--
-- Name: bc_cad_unidade_medida id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_unidade_medida ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_cad_unidade_medida_id_seq'::regclass);


--
-- Name: bc_com_conferencia_fatura id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_conferencia_fatura_id_seq'::regclass);


--
-- Name: bc_com_contrato id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_contrato ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_contrato_id_seq'::regclass);


--
-- Name: bc_com_cotacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_cotacao_id_seq'::regclass);


--
-- Name: bc_com_cotacao_fornecedor id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_cotacao_fornecedor_id_seq'::regclass);


--
-- Name: bc_com_cotacao_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_cotacao_item_id_seq'::regclass);


--
-- Name: bc_com_pedido id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_pedido_id_seq'::regclass);


--
-- Name: bc_com_pedido_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_pedido_item_id_seq'::regclass);


--
-- Name: bc_com_recebimento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_recebimento_id_seq'::regclass);


--
-- Name: bc_com_recebimento_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_recebimento_item_id_seq'::regclass);


--
-- Name: bc_com_solicitacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_solicitacao_id_seq'::regclass);


--
-- Name: bc_com_solicitacao_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_com_solicitacao_item_id_seq'::regclass);


--
-- Name: bc_core_auditoria id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_auditoria ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_auditoria_id_seq'::regclass);


--
-- Name: bc_core_configuracao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_configuracao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_configuracao_id_seq'::regclass);


--
-- Name: bc_core_empresa id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_empresa_id_seq'::regclass);


--
-- Name: bc_core_empresa_vinculo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa_vinculo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_empresa_vinculo_id_seq'::regclass);


--
-- Name: bc_core_log_acesso id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_log_acesso ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_log_acesso_id_seq'::regclass);


--
-- Name: bc_core_modulo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_modulo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_modulo_id_seq'::regclass);


--
-- Name: bc_core_notificacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_notificacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_notificacao_id_seq'::regclass);


--
-- Name: bc_core_perfil id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_perfil_id_seq'::regclass);


--
-- Name: bc_core_perfil_permissao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil_permissao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_perfil_permissao_id_seq'::regclass);


--
-- Name: bc_core_permissao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_permissao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_permissao_id_seq'::regclass);


--
-- Name: bc_core_sessao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_sessao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_sessao_id_seq'::regclass);


--
-- Name: bc_core_usuario id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_usuario_id_seq'::regclass);


--
-- Name: bc_core_usuario_modulo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_modulo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_usuario_modulo_id_seq'::regclass);


--
-- Name: bc_core_usuario_perfil id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_perfil ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_core_usuario_perfil_id_seq'::regclass);


--
-- Name: bc_crm_atividade id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_crm_atividade_id_seq'::regclass);


--
-- Name: bc_crm_oportunidade id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_oportunidade ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_crm_oportunidade_id_seq'::regclass);


--
-- Name: bc_est_deposito id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_deposito ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_deposito_id_seq'::regclass);


--
-- Name: bc_est_endereco id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_endereco ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_endereco_id_seq'::regclass);


--
-- Name: bc_est_expedicao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_expedicao_id_seq'::regclass);


--
-- Name: bc_est_expedicao_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_expedicao_item_id_seq'::regclass);


--
-- Name: bc_est_inventario id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_inventario_id_seq'::regclass);


--
-- Name: bc_est_inventario_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_inventario_item_id_seq'::regclass);


--
-- Name: bc_est_lote id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_lote ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_lote_id_seq'::regclass);


--
-- Name: bc_est_movimentacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_movimentacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_movimentacao_id_seq'::regclass);


--
-- Name: bc_est_reserva id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_reserva_id_seq'::regclass);


--
-- Name: bc_est_saldo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_saldo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_saldo_id_seq'::regclass);


--
-- Name: bc_est_serie id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_serie_id_seq'::regclass);


--
-- Name: bc_est_transferencia id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_transferencia_id_seq'::regclass);


--
-- Name: bc_est_transferencia_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_est_transferencia_item_id_seq'::regclass);


--
-- Name: bc_fin_analise_rentabilidade id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_analise_rentabilidade ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_analise_rentabilidade_id_seq'::regclass);


--
-- Name: bc_fin_aplicacao_financeira id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aplicacao_financeira ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_aplicacao_financeira_id_seq'::regclass);


--
-- Name: bc_fin_aprovacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_aprovacao_id_seq'::regclass);


--
-- Name: bc_fin_baixa id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_baixa_id_seq'::regclass);


--
-- Name: bc_fin_boleto id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_boleto ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_boleto_id_seq'::regclass);


--
-- Name: bc_fin_caixa id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_caixa ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_caixa_id_seq'::regclass);


--
-- Name: bc_fin_centro_custo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_centro_custo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_centro_custo_id_seq'::regclass);


--
-- Name: bc_fin_conciliacao_bancaria id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_bancaria ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_conciliacao_bancaria_id_seq'::regclass);


--
-- Name: bc_fin_conciliacao_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_conciliacao_item_id_seq'::regclass);


--
-- Name: bc_fin_condicao_pagamento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_condicao_pagamento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_condicao_pagamento_id_seq'::regclass);


--
-- Name: bc_fin_conta_bancaria id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conta_bancaria ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_conta_bancaria_id_seq'::regclass);


--
-- Name: bc_fin_emprestimo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_emprestimo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_emprestimo_id_seq'::regclass);


--
-- Name: bc_fin_extrato id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_extrato ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_extrato_id_seq'::regclass);


--
-- Name: bc_fin_fluxo_aprovacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_fluxo_aprovacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_fluxo_aprovacao_id_seq'::regclass);


--
-- Name: bc_fin_integracao_bancaria id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_integracao_bancaria ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_integracao_bancaria_id_seq'::regclass);


--
-- Name: bc_fin_lancamento_contabil id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_contabil ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_lancamento_contabil_id_seq'::regclass);


--
-- Name: bc_fin_lancamento_partida id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_lancamento_partida_id_seq'::regclass);


--
-- Name: bc_fin_orcamento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_orcamento_id_seq'::regclass);


--
-- Name: bc_fin_orcamento_realizado id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento_realizado ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_orcamento_realizado_id_seq'::regclass);


--
-- Name: bc_fin_periodo_contabil id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_periodo_contabil ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_periodo_contabil_id_seq'::regclass);


--
-- Name: bc_fin_plano_contas id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_plano_contas ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_plano_contas_id_seq'::regclass);


--
-- Name: bc_fin_projecao_fluxo_caixa id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_projecao_fluxo_caixa ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_projecao_fluxo_caixa_id_seq'::regclass);


--
-- Name: bc_fin_provisao_pdd id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_provisao_pdd ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_provisao_pdd_id_seq'::regclass);


--
-- Name: bc_fin_remessa id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_remessa_id_seq'::regclass);


--
-- Name: bc_fin_remessa_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_remessa_item_id_seq'::regclass);


--
-- Name: bc_fin_renegociacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_renegociacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_renegociacao_id_seq'::regclass);


--
-- Name: bc_fin_retorno_bancario id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_bancario ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_retorno_bancario_id_seq'::regclass);


--
-- Name: bc_fin_retorno_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_retorno_item_id_seq'::regclass);


--
-- Name: bc_fin_tipo_pagamento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_tipo_pagamento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_tipo_pagamento_id_seq'::regclass);


--
-- Name: bc_fin_titulo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_titulo_id_seq'::regclass);


--
-- Name: bc_fin_titulo_parcela id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo_parcela ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fin_titulo_parcela_id_seq'::regclass);


--
-- Name: bc_fis_apuracao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_apuracao_id_seq'::regclass);


--
-- Name: bc_fis_certificado_digital id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_certificado_digital ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_certificado_digital_id_seq'::regclass);


--
-- Name: bc_fis_cest id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cest ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_cest_id_seq'::regclass);


--
-- Name: bc_fis_cfop id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cfop ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_cfop_id_seq'::regclass);


--
-- Name: bc_fis_cnae_servico id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cnae_servico ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_cnae_servico_id_seq'::regclass);


--
-- Name: bc_fis_cte id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_cte_id_seq'::regclass);


--
-- Name: bc_fis_cte_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_cte_item_id_seq'::regclass);


--
-- Name: bc_fis_ecd id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecd ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_ecd_id_seq'::regclass);


--
-- Name: bc_fis_ecf id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecf ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_ecf_id_seq'::regclass);


--
-- Name: bc_fis_esocial id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_esocial ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_esocial_id_seq'::regclass);


--
-- Name: bc_fis_imposto id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_imposto ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_imposto_id_seq'::regclass);


--
-- Name: bc_fis_issqn id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_issqn ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_issqn_id_seq'::regclass);


--
-- Name: bc_fis_manifestacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_manifestacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_manifestacao_id_seq'::regclass);


--
-- Name: bc_fis_mdfe id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_mdfe ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_mdfe_id_seq'::regclass);


--
-- Name: bc_fis_nbs id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nbs ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nbs_id_seq'::regclass);


--
-- Name: bc_fis_ncm id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ncm ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_ncm_id_seq'::regclass);


--
-- Name: bc_fis_nfce id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfce_id_seq'::regclass);


--
-- Name: bc_fis_nfce_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfce_item_id_seq'::regclass);


--
-- Name: bc_fis_nfe id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfe_id_seq'::regclass);


--
-- Name: bc_fis_nfe_evento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_evento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfe_evento_id_seq'::regclass);


--
-- Name: bc_fis_nfe_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfe_item_id_seq'::regclass);


--
-- Name: bc_fis_nfse id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfse_id_seq'::regclass);


--
-- Name: bc_fis_nfse_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfse_item_id_seq'::regclass);


--
-- Name: bc_fis_nfse_retorno id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_retorno ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_nfse_retorno_id_seq'::regclass);


--
-- Name: bc_fis_regra_tributaria id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_regra_tributaria ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_regra_tributaria_id_seq'::regclass);


--
-- Name: bc_fis_reinf id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_reinf ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_reinf_id_seq'::regclass);


--
-- Name: bc_fis_servico_lc116 id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_servico_lc116 ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_servico_lc116_id_seq'::regclass);


--
-- Name: bc_fis_sped_contribuicoes id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_contribuicoes ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_sped_contribuicoes_id_seq'::regclass);


--
-- Name: bc_fis_sped_fiscal id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_fiscal ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_fis_sped_fiscal_id_seq'::regclass);


--
-- Name: bc_ia_analise_preditiva id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_analise_preditiva ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_analise_preditiva_id_seq'::regclass);


--
-- Name: bc_ia_chat_mensagem id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_mensagem ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_chat_mensagem_id_seq'::regclass);


--
-- Name: bc_ia_chat_message id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_message ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_chat_message_id_seq'::regclass);


--
-- Name: bc_ia_chat_sessao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_sessao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_chat_sessao_id_seq'::regclass);


--
-- Name: bc_ia_chat_session id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_session ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_chat_session_id_seq'::regclass);


--
-- Name: bc_ia_classificacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_classificacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_classificacao_id_seq'::regclass);


--
-- Name: bc_ia_config id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_config ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_config_id_seq'::regclass);


--
-- Name: bc_ia_embedding id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_embedding ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_embedding_id_seq'::regclass);


--
-- Name: bc_ia_prompt id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_prompt_id_seq'::regclass);


--
-- Name: bc_ia_prompt_template id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt_template ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ia_prompt_template_id_seq'::regclass);


--
-- Name: bc_migration_log id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_migration_log ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_migration_log_id_seq'::regclass);


--
-- Name: bc_prod_apontamento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_apontamento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_prod_apontamento_id_seq'::regclass);


--
-- Name: bc_prod_estrutura id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_estrutura ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_prod_estrutura_id_seq'::regclass);


--
-- Name: bc_prod_romaneio id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_prod_romaneio_id_seq'::regclass);


--
-- Name: bc_prod_romaneio_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_prod_romaneio_item_id_seq'::regclass);


--
-- Name: bc_rh_cargo id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_cargo ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_rh_cargo_id_seq'::regclass);


--
-- Name: bc_rh_folha id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_rh_folha_id_seq'::regclass);


--
-- Name: bc_rh_folha_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_rh_folha_item_id_seq'::regclass);


--
-- Name: bc_rh_funcionario id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_funcionario ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_rh_funcionario_id_seq'::regclass);


--
-- Name: bc_srv_ordem_servico id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_srv_ordem_servico_id_seq'::regclass);


--
-- Name: bc_srv_os_apontamento id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_apontamento ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_srv_os_apontamento_id_seq'::regclass);


--
-- Name: bc_srv_os_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_srv_os_item_id_seq'::regclass);


--
-- Name: bc_ven_bonificacao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_bonificacao_id_seq'::regclass);


--
-- Name: bc_ven_bonificacao_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_bonificacao_item_id_seq'::regclass);


--
-- Name: bc_ven_contrato id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_contrato_id_seq'::regclass);


--
-- Name: bc_ven_contrato_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_contrato_item_id_seq'::regclass);


--
-- Name: bc_ven_devolucao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_devolucao_id_seq'::regclass);


--
-- Name: bc_ven_devolucao_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_devolucao_item_id_seq'::regclass);


--
-- Name: bc_ven_pedido id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_pedido_id_seq'::regclass);


--
-- Name: bc_ven_pedido_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_pedido_item_id_seq'::regclass);


--
-- Name: bc_ven_regra_comissao id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_regra_comissao ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_regra_comissao_id_seq'::regclass);


--
-- Name: bc_ven_tabela_preco id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_tabela_preco_id_seq'::regclass);


--
-- Name: bc_ven_tabela_preco_item id; Type: DEFAULT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item ALTER COLUMN id SET DEFAULT nextval('brasil_saas.bc_ven_tabela_preco_item_id_seq'::regclass);


--
-- Name: dim_cliente id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_cliente ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.dim_cliente_id_seq'::regclass);


--
-- Name: dim_empresa id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_empresa ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.dim_empresa_id_seq'::regclass);


--
-- Name: dim_produto id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_produto ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.dim_produto_id_seq'::regclass);


--
-- Name: dim_tempo id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_tempo ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.dim_tempo_id_seq'::regclass);


--
-- Name: ft_compras id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_compras ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.ft_compras_id_seq'::regclass);


--
-- Name: ft_estoque id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_estoque ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.ft_estoque_id_seq'::regclass);


--
-- Name: ft_financeiro id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_financeiro ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.ft_financeiro_id_seq'::regclass);


--
-- Name: ft_producao id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_producao ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.ft_producao_id_seq'::regclass);


--
-- Name: ft_vendas id; Type: DEFAULT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_vendas ALTER COLUMN id SET DEFAULT nextval('brasil_saas_dl.ft_vendas_id_seq'::regclass);


--
-- Name: fcaixa codcaixa; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcaixa ALTER COLUMN codcaixa SET DEFAULT nextval('public.fcaixa_codcaixa_seq'::regclass);


--
-- Name: fcentrocusto codcusto; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcentrocusto ALTER COLUMN codcusto SET DEFAULT nextval('public.fcentrocusto_codcusto_seq'::regclass);


--
-- Name: fcusto codcusto; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcusto ALTER COLUMN codcusto SET DEFAULT nextval('public.fcusto_codcusto_seq'::regclass);


--
-- Name: fdatas iddata; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fdatas ALTER COLUMN iddata SET DEFAULT nextval('public.fdatas_iddata_seq'::regclass);


--
-- Name: fdia refdia; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fdia ALTER COLUMN refdia SET DEFAULT nextval('public.fdia_refdia_seq'::regclass);


--
-- Name: fempresa codigo; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fempresa ALTER COLUMN codigo SET DEFAULT nextval('public.fempresa_codigo_seq'::regclass);


--
-- Name: fempresa_vinculo codvinculo; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fempresa_vinculo ALTER COLUMN codvinculo SET DEFAULT nextval('public.fempresa_vinculo_codvinculo_seq'::regclass);


--
-- Name: fextrato idlanextrato; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fextrato ALTER COLUMN idlanextrato SET DEFAULT nextval('public.fextrato_idlanextrato_seq'::regclass);


--
-- Name: ffinanceiro codfinanceiro; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ffinanceiro ALTER COLUMN codfinanceiro SET DEFAULT nextval('public.ffinanceiro_codfinanceiro_seq'::regclass);


--
-- Name: ffuncionario codfuncionario; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ffuncionario ALTER COLUMN codfuncionario SET DEFAULT nextval('public.ffuncionario_codfuncionario_seq'::regclass);


--
-- Name: fitem refitem; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fitem ALTER COLUMN refitem SET DEFAULT nextval('public.fitem_refitem_seq'::regclass);


--
-- Name: fmov idmov; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmov ALTER COLUMN idmov SET DEFAULT (nextval('public.fmov_idmov_seq'::regclass))::public.docod;


--
-- Name: fmovimento codmovimento; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmovimento ALTER COLUMN codmovimento SET DEFAULT nextval('public.fmovimento_codmovimento_seq'::regclass);


--
-- Name: fmovimento_item coditem; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmovimento_item ALTER COLUMN coditem SET DEFAULT nextval('public.fmovimento_item_coditem_seq'::regclass);


--
-- Name: fnota id_nota; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota ALTER COLUMN id_nota SET DEFAULT nextval('public.fnota_id_nota_seq'::regclass);


--
-- Name: fnota_item id_item; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota_item ALTER COLUMN id_item SET DEFAULT nextval('public.fnota_item_id_item_seq'::regclass);


--
-- Name: fpessoa id_pessoa; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fpessoa ALTER COLUMN id_pessoa SET DEFAULT nextval('public.fpessoa_id_pessoa_seq'::regclass);


--
-- Name: fproduto_ecommerce codecommerce; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_ecommerce ALTER COLUMN codecommerce SET DEFAULT nextval('public.fproduto_ecommerce_codecommerce_seq'::regclass);


--
-- Name: fproduto_fiscal codproduto; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_fiscal ALTER COLUMN codproduto SET DEFAULT nextval('public.fproduto_fiscal_codproduto_seq'::regclass);


--
-- Name: fproduto_imagem codimagem; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_imagem ALTER COLUMN codimagem SET DEFAULT nextval('public.fproduto_imagem_codimagem_seq'::regclass);


--
-- Name: fproduto_kit codkit; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_kit ALTER COLUMN codkit SET DEFAULT nextval('public.fproduto_kit_codkit_seq'::regclass);


--
-- Name: fproduto_kit codproduto_filho; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_kit ALTER COLUMN codproduto_filho SET DEFAULT nextval('public.fproduto_kit_codproduto_filho_seq'::regclass);


--
-- Name: fproduto_movimento codmov; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_movimento ALTER COLUMN codmov SET DEFAULT nextval('public.fproduto_movimento_codmov_seq'::regclass);


--
-- Name: fproduto_variacao codvariacao; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_variacao ALTER COLUMN codvariacao SET DEFAULT nextval('public.fproduto_variacao_codvariacao_seq'::regclass);


--
-- Name: frecibo idrecibo; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frecibo ALTER COLUMN idrecibo SET DEFAULT nextval('public.frecibo_idrecibo_seq'::regclass);


--
-- Name: ftipo codtipo; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ftipo ALTER COLUMN codtipo SET DEFAULT nextval('public.ftipo_codtipo_seq'::regclass);


--
-- Name: fusuario codigo; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusuario ALTER COLUMN codigo SET DEFAULT nextval('public.fusuario_codigo_seq'::regclass);


--
-- Name: fvenda id_venda; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda ALTER COLUMN id_venda SET DEFAULT nextval('public.fvenda_id_venda_seq'::regclass);


--
-- Name: fvenda_item id_item; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda_item ALTER COLUMN id_item SET DEFAULT nextval('public.fvenda_item_id_item_seq'::regclass);


--
-- Name: gparametro idparametro; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gparametro ALTER COLUMN idparametro SET DEFAULT nextval('public.gparametro_idparametro_seq'::regclass);


--
-- Name: tissqn id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tissqn ALTER COLUMN id SET DEFAULT nextval('public.tissqn_id_seq'::regclass);


--
-- Name: bc_bi_dashboard bc_bi_dashboard_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard
    ADD CONSTRAINT bc_bi_dashboard_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_dashboard bc_bi_dashboard_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard
    ADD CONSTRAINT bc_bi_dashboard_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_dashboard_widget bc_bi_dashboard_widget_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard_widget
    ADD CONSTRAINT bc_bi_dashboard_widget_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_dashboard_widget bc_bi_dashboard_widget_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard_widget
    ADD CONSTRAINT bc_bi_dashboard_widget_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_indicador bc_bi_indicador_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_indicador
    ADD CONSTRAINT bc_bi_indicador_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_indicador bc_bi_indicador_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_indicador
    ADD CONSTRAINT bc_bi_indicador_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_kpi bc_bi_kpi_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_kpi
    ADD CONSTRAINT bc_bi_kpi_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_kpi bc_bi_kpi_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_kpi
    ADD CONSTRAINT bc_bi_kpi_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_relatorio_agendado bc_bi_relatorio_agendado_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio_agendado
    ADD CONSTRAINT bc_bi_relatorio_agendado_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_relatorio_agendado bc_bi_relatorio_agendado_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio_agendado
    ADD CONSTRAINT bc_bi_relatorio_agendado_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_relatorio bc_bi_relatorio_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio
    ADD CONSTRAINT bc_bi_relatorio_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_relatorio bc_bi_relatorio_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio
    ADD CONSTRAINT bc_bi_relatorio_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_report_parameter bc_bi_report_parameter_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report_parameter
    ADD CONSTRAINT bc_bi_report_parameter_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_report_parameter bc_bi_report_parameter_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report_parameter
    ADD CONSTRAINT bc_bi_report_parameter_uuid_key UNIQUE (uuid);


--
-- Name: bc_bi_report bc_bi_report_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report
    ADD CONSTRAINT bc_bi_report_pkey PRIMARY KEY (id);


--
-- Name: bc_bi_report bc_bi_report_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report
    ADD CONSTRAINT bc_bi_report_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_base_cep bc_cad_base_cep_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_base_cep
    ADD CONSTRAINT bc_cad_base_cep_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_categoria bc_cad_categoria_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_categoria
    ADD CONSTRAINT bc_cad_categoria_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_categoria bc_cad_categoria_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_categoria
    ADD CONSTRAINT bc_cad_categoria_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_cliente bc_cad_cliente_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_cliente
    ADD CONSTRAINT bc_cad_cliente_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_cliente bc_cad_cliente_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_cliente
    ADD CONSTRAINT bc_cad_cliente_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_contato bc_cad_contato_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_contato
    ADD CONSTRAINT bc_cad_contato_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_contato bc_cad_contato_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_contato
    ADD CONSTRAINT bc_cad_contato_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_documento_fiscal bc_cad_documento_fiscal_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_documento_fiscal
    ADD CONSTRAINT bc_cad_documento_fiscal_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_documento_fiscal bc_cad_documento_fiscal_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_documento_fiscal
    ADD CONSTRAINT bc_cad_documento_fiscal_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_endereco bc_cad_endereco_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_endereco
    ADD CONSTRAINT bc_cad_endereco_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_endereco bc_cad_endereco_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_endereco
    ADD CONSTRAINT bc_cad_endereco_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_fornecedor bc_cad_fornecedor_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_fornecedor
    ADD CONSTRAINT bc_cad_fornecedor_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_fornecedor bc_cad_fornecedor_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_fornecedor
    ADD CONSTRAINT bc_cad_fornecedor_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_marca bc_cad_marca_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_marca
    ADD CONSTRAINT bc_cad_marca_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_marca bc_cad_marca_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_marca
    ADD CONSTRAINT bc_cad_marca_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_municipio bc_cad_municipio_codigo_ibge_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_municipio
    ADD CONSTRAINT bc_cad_municipio_codigo_ibge_key UNIQUE (codigo_ibge);


--
-- Name: bc_cad_municipio bc_cad_municipio_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_municipio
    ADD CONSTRAINT bc_cad_municipio_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_papel bc_cad_papel_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_papel
    ADD CONSTRAINT bc_cad_papel_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_papel bc_cad_papel_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_papel
    ADD CONSTRAINT bc_cad_papel_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_pessoa_fisica bc_cad_pessoa_fisica_pessoa_id_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_fisica
    ADD CONSTRAINT bc_cad_pessoa_fisica_pessoa_id_key UNIQUE (pessoa_id);


--
-- Name: bc_cad_pessoa_fisica bc_cad_pessoa_fisica_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_fisica
    ADD CONSTRAINT bc_cad_pessoa_fisica_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_pessoa_juridica bc_cad_pessoa_juridica_pessoa_id_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_juridica
    ADD CONSTRAINT bc_cad_pessoa_juridica_pessoa_id_key UNIQUE (pessoa_id);


--
-- Name: bc_cad_pessoa_juridica bc_cad_pessoa_juridica_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_juridica
    ADD CONSTRAINT bc_cad_pessoa_juridica_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_pessoa bc_cad_pessoa_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa
    ADD CONSTRAINT bc_cad_pessoa_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_pessoa bc_cad_pessoa_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa
    ADD CONSTRAINT bc_cad_pessoa_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_produto_ecommerce bc_cad_produto_ecommerce_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_ecommerce
    ADD CONSTRAINT bc_cad_produto_ecommerce_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_produto_ecommerce bc_cad_produto_ecommerce_produto_id_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_ecommerce
    ADD CONSTRAINT bc_cad_produto_ecommerce_produto_id_key UNIQUE (produto_id);


--
-- Name: bc_cad_produto_imagem bc_cad_produto_imagem_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_imagem
    ADD CONSTRAINT bc_cad_produto_imagem_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_produto_kit bc_cad_produto_kit_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_kit
    ADD CONSTRAINT bc_cad_produto_kit_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_produto bc_cad_produto_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT bc_cad_produto_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_produto bc_cad_produto_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT bc_cad_produto_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_produto_variacao bc_cad_produto_variacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_variacao
    ADD CONSTRAINT bc_cad_produto_variacao_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_produto_variacao bc_cad_produto_variacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_variacao
    ADD CONSTRAINT bc_cad_produto_variacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_servico bc_cad_servico_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_servico
    ADD CONSTRAINT bc_cad_servico_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_servico bc_cad_servico_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_servico
    ADD CONSTRAINT bc_cad_servico_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_transportadora bc_cad_transportadora_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_transportadora
    ADD CONSTRAINT bc_cad_transportadora_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_transportadora bc_cad_transportadora_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_transportadora
    ADD CONSTRAINT bc_cad_transportadora_uuid_key UNIQUE (uuid);


--
-- Name: bc_cad_unidade_medida bc_cad_unidade_medida_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_unidade_medida
    ADD CONSTRAINT bc_cad_unidade_medida_pkey PRIMARY KEY (id);


--
-- Name: bc_cad_unidade_medida bc_cad_unidade_medida_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_unidade_medida
    ADD CONSTRAINT bc_cad_unidade_medida_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_pkey PRIMARY KEY (id);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_contrato bc_com_contrato_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_contrato
    ADD CONSTRAINT bc_com_contrato_pkey PRIMARY KEY (id);


--
-- Name: bc_com_contrato bc_com_contrato_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_contrato
    ADD CONSTRAINT bc_com_contrato_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_cotacao_fornecedor bc_com_cotacao_fornecedor_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor
    ADD CONSTRAINT bc_com_cotacao_fornecedor_pkey PRIMARY KEY (id);


--
-- Name: bc_com_cotacao_fornecedor bc_com_cotacao_fornecedor_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor
    ADD CONSTRAINT bc_com_cotacao_fornecedor_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_cotacao_item bc_com_cotacao_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_item
    ADD CONSTRAINT bc_com_cotacao_item_pkey PRIMARY KEY (id);


--
-- Name: bc_com_cotacao_item bc_com_cotacao_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_item
    ADD CONSTRAINT bc_com_cotacao_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_cotacao bc_com_cotacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao
    ADD CONSTRAINT bc_com_cotacao_pkey PRIMARY KEY (id);


--
-- Name: bc_com_cotacao bc_com_cotacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao
    ADD CONSTRAINT bc_com_cotacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_pedido_item bc_com_pedido_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido_item
    ADD CONSTRAINT bc_com_pedido_item_pkey PRIMARY KEY (id);


--
-- Name: bc_com_pedido bc_com_pedido_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido
    ADD CONSTRAINT bc_com_pedido_pkey PRIMARY KEY (id);


--
-- Name: bc_com_recebimento_item bc_com_recebimento_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item
    ADD CONSTRAINT bc_com_recebimento_item_pkey PRIMARY KEY (id);


--
-- Name: bc_com_recebimento_item bc_com_recebimento_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item
    ADD CONSTRAINT bc_com_recebimento_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_recebimento bc_com_recebimento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento
    ADD CONSTRAINT bc_com_recebimento_pkey PRIMARY KEY (id);


--
-- Name: bc_com_recebimento bc_com_recebimento_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento
    ADD CONSTRAINT bc_com_recebimento_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_solicitacao_item bc_com_solicitacao_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao_item
    ADD CONSTRAINT bc_com_solicitacao_item_pkey PRIMARY KEY (id);


--
-- Name: bc_com_solicitacao_item bc_com_solicitacao_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao_item
    ADD CONSTRAINT bc_com_solicitacao_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_com_solicitacao bc_com_solicitacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao
    ADD CONSTRAINT bc_com_solicitacao_pkey PRIMARY KEY (id);


--
-- Name: bc_com_solicitacao bc_com_solicitacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao
    ADD CONSTRAINT bc_com_solicitacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_auditoria bc_core_auditoria_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_auditoria
    ADD CONSTRAINT bc_core_auditoria_pkey PRIMARY KEY (id);


--
-- Name: bc_core_auditoria bc_core_auditoria_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_auditoria
    ADD CONSTRAINT bc_core_auditoria_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_banco bc_core_banco_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_banco
    ADD CONSTRAINT bc_core_banco_pkey PRIMARY KEY (compe);


--
-- Name: bc_core_configuracao bc_core_configuracao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_configuracao
    ADD CONSTRAINT bc_core_configuracao_pkey PRIMARY KEY (id);


--
-- Name: bc_core_configuracao bc_core_configuracao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_configuracao
    ADD CONSTRAINT bc_core_configuracao_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_empresa bc_core_empresa_cnpj_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa
    ADD CONSTRAINT bc_core_empresa_cnpj_key UNIQUE (cnpj);


--
-- Name: bc_core_empresa bc_core_empresa_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa
    ADD CONSTRAINT bc_core_empresa_pkey PRIMARY KEY (id);


--
-- Name: bc_core_empresa bc_core_empresa_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa
    ADD CONSTRAINT bc_core_empresa_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_empresa_vinculo bc_core_empresa_vinculo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa_vinculo
    ADD CONSTRAINT bc_core_empresa_vinculo_pkey PRIMARY KEY (id);


--
-- Name: bc_core_empresa_vinculo bc_core_empresa_vinculo_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa_vinculo
    ADD CONSTRAINT bc_core_empresa_vinculo_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_log_acesso bc_core_log_acesso_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_log_acesso
    ADD CONSTRAINT bc_core_log_acesso_pkey PRIMARY KEY (id);


--
-- Name: bc_core_modulo bc_core_modulo_chave_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_modulo
    ADD CONSTRAINT bc_core_modulo_chave_key UNIQUE (chave);


--
-- Name: bc_core_modulo bc_core_modulo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_modulo
    ADD CONSTRAINT bc_core_modulo_pkey PRIMARY KEY (id);


--
-- Name: bc_core_modulo bc_core_modulo_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_modulo
    ADD CONSTRAINT bc_core_modulo_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_notificacao bc_core_notificacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_notificacao
    ADD CONSTRAINT bc_core_notificacao_pkey PRIMARY KEY (id);


--
-- Name: bc_core_notificacao bc_core_notificacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_notificacao
    ADD CONSTRAINT bc_core_notificacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_perfil_permissao bc_core_perfil_permissao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil_permissao
    ADD CONSTRAINT bc_core_perfil_permissao_pkey PRIMARY KEY (id);


--
-- Name: bc_core_perfil bc_core_perfil_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil
    ADD CONSTRAINT bc_core_perfil_pkey PRIMARY KEY (id);


--
-- Name: bc_core_perfil bc_core_perfil_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil
    ADD CONSTRAINT bc_core_perfil_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_permissao bc_core_permissao_codigo_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_permissao
    ADD CONSTRAINT bc_core_permissao_codigo_key UNIQUE (codigo);


--
-- Name: bc_core_permissao bc_core_permissao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_permissao
    ADD CONSTRAINT bc_core_permissao_pkey PRIMARY KEY (id);


--
-- Name: bc_core_permissao bc_core_permissao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_permissao
    ADD CONSTRAINT bc_core_permissao_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_sessao bc_core_sessao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_sessao
    ADD CONSTRAINT bc_core_sessao_pkey PRIMARY KEY (id);


--
-- Name: bc_core_sessao bc_core_sessao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_sessao
    ADD CONSTRAINT bc_core_sessao_uuid_key UNIQUE (uuid);


--
-- Name: bc_core_usuario bc_core_usuario_email_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario
    ADD CONSTRAINT bc_core_usuario_email_key UNIQUE (email);


--
-- Name: bc_core_usuario_modulo bc_core_usuario_modulo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_modulo
    ADD CONSTRAINT bc_core_usuario_modulo_pkey PRIMARY KEY (id);


--
-- Name: bc_core_usuario_perfil bc_core_usuario_perfil_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_perfil
    ADD CONSTRAINT bc_core_usuario_perfil_pkey PRIMARY KEY (id);


--
-- Name: bc_core_usuario bc_core_usuario_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario
    ADD CONSTRAINT bc_core_usuario_pkey PRIMARY KEY (id);


--
-- Name: bc_core_usuario bc_core_usuario_username_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario
    ADD CONSTRAINT bc_core_usuario_username_key UNIQUE (username);


--
-- Name: bc_core_usuario bc_core_usuario_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario
    ADD CONSTRAINT bc_core_usuario_uuid_key UNIQUE (uuid);


--
-- Name: bc_crm_atividade bc_crm_atividade_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade
    ADD CONSTRAINT bc_crm_atividade_pkey PRIMARY KEY (id);


--
-- Name: bc_crm_atividade bc_crm_atividade_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade
    ADD CONSTRAINT bc_crm_atividade_uuid_key UNIQUE (uuid);


--
-- Name: bc_crm_oportunidade bc_crm_oportunidade_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_oportunidade
    ADD CONSTRAINT bc_crm_oportunidade_pkey PRIMARY KEY (id);


--
-- Name: bc_crm_oportunidade bc_crm_oportunidade_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_oportunidade
    ADD CONSTRAINT bc_crm_oportunidade_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_deposito bc_est_deposito_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_deposito
    ADD CONSTRAINT bc_est_deposito_pkey PRIMARY KEY (id);


--
-- Name: bc_est_deposito bc_est_deposito_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_deposito
    ADD CONSTRAINT bc_est_deposito_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_endereco bc_est_endereco_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_endereco
    ADD CONSTRAINT bc_est_endereco_pkey PRIMARY KEY (id);


--
-- Name: bc_est_endereco bc_est_endereco_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_endereco
    ADD CONSTRAINT bc_est_endereco_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_pkey PRIMARY KEY (id);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_expedicao bc_est_expedicao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao
    ADD CONSTRAINT bc_est_expedicao_pkey PRIMARY KEY (id);


--
-- Name: bc_est_expedicao bc_est_expedicao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao
    ADD CONSTRAINT bc_est_expedicao_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_inventario_item bc_est_inventario_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario_item
    ADD CONSTRAINT bc_est_inventario_item_pkey PRIMARY KEY (id);


--
-- Name: bc_est_inventario bc_est_inventario_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario
    ADD CONSTRAINT bc_est_inventario_pkey PRIMARY KEY (id);


--
-- Name: bc_est_inventario bc_est_inventario_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario
    ADD CONSTRAINT bc_est_inventario_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_lote bc_est_lote_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_lote
    ADD CONSTRAINT bc_est_lote_pkey PRIMARY KEY (id);


--
-- Name: bc_est_lote bc_est_lote_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_lote
    ADD CONSTRAINT bc_est_lote_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_movimentacao bc_est_movimentacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_movimentacao
    ADD CONSTRAINT bc_est_movimentacao_pkey PRIMARY KEY (id);


--
-- Name: bc_est_reserva bc_est_reserva_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_pkey PRIMARY KEY (id);


--
-- Name: bc_est_reserva bc_est_reserva_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_saldo bc_est_saldo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_saldo
    ADD CONSTRAINT bc_est_saldo_pkey PRIMARY KEY (id);


--
-- Name: bc_est_serie bc_est_serie_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie
    ADD CONSTRAINT bc_est_serie_pkey PRIMARY KEY (id);


--
-- Name: bc_est_serie bc_est_serie_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie
    ADD CONSTRAINT bc_est_serie_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_pkey PRIMARY KEY (id);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_est_transferencia bc_est_transferencia_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia
    ADD CONSTRAINT bc_est_transferencia_pkey PRIMARY KEY (id);


--
-- Name: bc_est_transferencia bc_est_transferencia_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia
    ADD CONSTRAINT bc_est_transferencia_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_analise_rentabilidade bc_fin_analise_rentabilidade_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_analise_rentabilidade
    ADD CONSTRAINT bc_fin_analise_rentabilidade_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_analise_rentabilidade bc_fin_analise_rentabilidade_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_analise_rentabilidade
    ADD CONSTRAINT bc_fin_analise_rentabilidade_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_aplicacao_financeira bc_fin_aplicacao_financeira_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aplicacao_financeira
    ADD CONSTRAINT bc_fin_aplicacao_financeira_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_aplicacao_financeira bc_fin_aplicacao_financeira_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aplicacao_financeira
    ADD CONSTRAINT bc_fin_aplicacao_financeira_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_aprovacao bc_fin_aprovacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao
    ADD CONSTRAINT bc_fin_aprovacao_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_aprovacao bc_fin_aprovacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao
    ADD CONSTRAINT bc_fin_aprovacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_baixa bc_fin_baixa_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_baixa bc_fin_baixa_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_boleto bc_fin_boleto_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_boleto
    ADD CONSTRAINT bc_fin_boleto_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_boleto bc_fin_boleto_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_boleto
    ADD CONSTRAINT bc_fin_boleto_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_caixa bc_fin_caixa_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_caixa
    ADD CONSTRAINT bc_fin_caixa_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_centro_custo bc_fin_centro_custo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_centro_custo
    ADD CONSTRAINT bc_fin_centro_custo_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_centro_custo bc_fin_centro_custo_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_centro_custo
    ADD CONSTRAINT bc_fin_centro_custo_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_comissao bc_fin_comissao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_comissao
    ADD CONSTRAINT bc_fin_comissao_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_conciliacao_bancaria bc_fin_conciliacao_bancaria_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_bancaria
    ADD CONSTRAINT bc_fin_conciliacao_bancaria_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_conciliacao_bancaria bc_fin_conciliacao_bancaria_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_bancaria
    ADD CONSTRAINT bc_fin_conciliacao_bancaria_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_conciliacao_item bc_fin_conciliacao_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item
    ADD CONSTRAINT bc_fin_conciliacao_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_conciliacao_item bc_fin_conciliacao_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item
    ADD CONSTRAINT bc_fin_conciliacao_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_condicao_pagamento bc_fin_condicao_pagamento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_condicao_pagamento
    ADD CONSTRAINT bc_fin_condicao_pagamento_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_condicao_pagamento bc_fin_condicao_pagamento_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_condicao_pagamento
    ADD CONSTRAINT bc_fin_condicao_pagamento_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_conta_bancaria bc_fin_conta_bancaria_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conta_bancaria
    ADD CONSTRAINT bc_fin_conta_bancaria_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_conta_bancaria bc_fin_conta_bancaria_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conta_bancaria
    ADD CONSTRAINT bc_fin_conta_bancaria_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_emprestimo bc_fin_emprestimo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_emprestimo
    ADD CONSTRAINT bc_fin_emprestimo_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_emprestimo bc_fin_emprestimo_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_emprestimo
    ADD CONSTRAINT bc_fin_emprestimo_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_extrato bc_fin_extrato_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_extrato
    ADD CONSTRAINT bc_fin_extrato_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_extrato bc_fin_extrato_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_extrato
    ADD CONSTRAINT bc_fin_extrato_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_fluxo_aprovacao bc_fin_fluxo_aprovacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_fluxo_aprovacao
    ADD CONSTRAINT bc_fin_fluxo_aprovacao_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_fluxo_aprovacao bc_fin_fluxo_aprovacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_fluxo_aprovacao
    ADD CONSTRAINT bc_fin_fluxo_aprovacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_integracao_bancaria bc_fin_integracao_bancaria_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_integracao_bancaria
    ADD CONSTRAINT bc_fin_integracao_bancaria_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_integracao_bancaria bc_fin_integracao_bancaria_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_integracao_bancaria
    ADD CONSTRAINT bc_fin_integracao_bancaria_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_lancamento_contabil bc_fin_lancamento_contabil_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_contabil
    ADD CONSTRAINT bc_fin_lancamento_contabil_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_lancamento_contabil bc_fin_lancamento_contabil_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_contabil
    ADD CONSTRAINT bc_fin_lancamento_contabil_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_lancamento_partida bc_fin_lancamento_partida_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida
    ADD CONSTRAINT bc_fin_lancamento_partida_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_lancamento_partida bc_fin_lancamento_partida_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida
    ADD CONSTRAINT bc_fin_lancamento_partida_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_orcamento bc_fin_orcamento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento
    ADD CONSTRAINT bc_fin_orcamento_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_orcamento_realizado bc_fin_orcamento_realizado_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento_realizado
    ADD CONSTRAINT bc_fin_orcamento_realizado_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_orcamento_realizado bc_fin_orcamento_realizado_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento_realizado
    ADD CONSTRAINT bc_fin_orcamento_realizado_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_orcamento bc_fin_orcamento_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento
    ADD CONSTRAINT bc_fin_orcamento_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_periodo_contabil bc_fin_periodo_contabil_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_periodo_contabil
    ADD CONSTRAINT bc_fin_periodo_contabil_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_periodo_contabil bc_fin_periodo_contabil_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_periodo_contabil
    ADD CONSTRAINT bc_fin_periodo_contabil_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_plano_contas bc_fin_plano_contas_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_plano_contas
    ADD CONSTRAINT bc_fin_plano_contas_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_plano_contas bc_fin_plano_contas_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_plano_contas
    ADD CONSTRAINT bc_fin_plano_contas_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_projecao_fluxo_caixa bc_fin_projecao_fluxo_caixa_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_projecao_fluxo_caixa
    ADD CONSTRAINT bc_fin_projecao_fluxo_caixa_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_projecao_fluxo_caixa bc_fin_projecao_fluxo_caixa_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_projecao_fluxo_caixa
    ADD CONSTRAINT bc_fin_projecao_fluxo_caixa_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_provisao_pdd bc_fin_provisao_pdd_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_provisao_pdd
    ADD CONSTRAINT bc_fin_provisao_pdd_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_provisao_pdd bc_fin_provisao_pdd_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_provisao_pdd
    ADD CONSTRAINT bc_fin_provisao_pdd_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_remessa_item bc_fin_remessa_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa_item
    ADD CONSTRAINT bc_fin_remessa_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_remessa bc_fin_remessa_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa
    ADD CONSTRAINT bc_fin_remessa_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_remessa bc_fin_remessa_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa
    ADD CONSTRAINT bc_fin_remessa_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_renegociacao bc_fin_renegociacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_renegociacao
    ADD CONSTRAINT bc_fin_renegociacao_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_renegociacao bc_fin_renegociacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_renegociacao
    ADD CONSTRAINT bc_fin_renegociacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_retorno_bancario bc_fin_retorno_bancario_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_bancario
    ADD CONSTRAINT bc_fin_retorno_bancario_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_retorno_bancario bc_fin_retorno_bancario_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_bancario
    ADD CONSTRAINT bc_fin_retorno_bancario_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_retorno_item bc_fin_retorno_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_item
    ADD CONSTRAINT bc_fin_retorno_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_tipo_pagamento bc_fin_tipo_pagamento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_tipo_pagamento
    ADD CONSTRAINT bc_fin_tipo_pagamento_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_tipo_pagamento bc_fin_tipo_pagamento_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_tipo_pagamento
    ADD CONSTRAINT bc_fin_tipo_pagamento_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_titulo_parcela bc_fin_titulo_parcela_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo_parcela
    ADD CONSTRAINT bc_fin_titulo_parcela_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_titulo_parcela bc_fin_titulo_parcela_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo_parcela
    ADD CONSTRAINT bc_fin_titulo_parcela_uuid_key UNIQUE (uuid);


--
-- Name: bc_fin_titulo bc_fin_titulo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo
    ADD CONSTRAINT bc_fin_titulo_pkey PRIMARY KEY (id);


--
-- Name: bc_fin_titulo bc_fin_titulo_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo
    ADD CONSTRAINT bc_fin_titulo_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_apuracao bc_fis_apuracao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao
    ADD CONSTRAINT bc_fis_apuracao_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_apuracao bc_fis_apuracao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao
    ADD CONSTRAINT bc_fis_apuracao_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_certificado_digital bc_fis_certificado_digital_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_certificado_digital
    ADD CONSTRAINT bc_fis_certificado_digital_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_certificado_digital bc_fis_certificado_digital_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_certificado_digital
    ADD CONSTRAINT bc_fis_certificado_digital_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_cest bc_fis_cest_codigo_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cest
    ADD CONSTRAINT bc_fis_cest_codigo_key UNIQUE (codigo);


--
-- Name: bc_fis_cest bc_fis_cest_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cest
    ADD CONSTRAINT bc_fis_cest_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_cfop bc_fis_cfop_codigo_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cfop
    ADD CONSTRAINT bc_fis_cfop_codigo_key UNIQUE (codigo);


--
-- Name: bc_fis_cfop bc_fis_cfop_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cfop
    ADD CONSTRAINT bc_fis_cfop_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_cnae_servico bc_fis_cnae_servico_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cnae_servico
    ADD CONSTRAINT bc_fis_cnae_servico_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_cte_item bc_fis_cte_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte_item
    ADD CONSTRAINT bc_fis_cte_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_cte bc_fis_cte_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte
    ADD CONSTRAINT bc_fis_cte_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_cte bc_fis_cte_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte
    ADD CONSTRAINT bc_fis_cte_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_ecd bc_fis_ecd_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecd
    ADD CONSTRAINT bc_fis_ecd_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_ecd bc_fis_ecd_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecd
    ADD CONSTRAINT bc_fis_ecd_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_ecf bc_fis_ecf_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecf
    ADD CONSTRAINT bc_fis_ecf_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_ecf bc_fis_ecf_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecf
    ADD CONSTRAINT bc_fis_ecf_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_esocial bc_fis_esocial_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_esocial
    ADD CONSTRAINT bc_fis_esocial_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_esocial bc_fis_esocial_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_esocial
    ADD CONSTRAINT bc_fis_esocial_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_imposto bc_fis_imposto_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_imposto
    ADD CONSTRAINT bc_fis_imposto_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_imposto bc_fis_imposto_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_imposto
    ADD CONSTRAINT bc_fis_imposto_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_issqn bc_fis_issqn_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_issqn
    ADD CONSTRAINT bc_fis_issqn_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_manifestacao bc_fis_manifestacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_manifestacao
    ADD CONSTRAINT bc_fis_manifestacao_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_manifestacao bc_fis_manifestacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_manifestacao
    ADD CONSTRAINT bc_fis_manifestacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_mdfe bc_fis_mdfe_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_mdfe
    ADD CONSTRAINT bc_fis_mdfe_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_mdfe bc_fis_mdfe_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_mdfe
    ADD CONSTRAINT bc_fis_mdfe_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_nbs bc_fis_nbs_codigo_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nbs
    ADD CONSTRAINT bc_fis_nbs_codigo_key UNIQUE (codigo);


--
-- Name: bc_fis_nbs bc_fis_nbs_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nbs
    ADD CONSTRAINT bc_fis_nbs_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_ncm bc_fis_ncm_codigo_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ncm
    ADD CONSTRAINT bc_fis_ncm_codigo_key UNIQUE (codigo);


--
-- Name: bc_fis_ncm bc_fis_ncm_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ncm
    ADD CONSTRAINT bc_fis_ncm_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfce_item bc_fis_nfce_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce_item
    ADD CONSTRAINT bc_fis_nfce_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfce bc_fis_nfce_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce
    ADD CONSTRAINT bc_fis_nfce_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfce bc_fis_nfce_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce
    ADD CONSTRAINT bc_fis_nfce_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_nfe_evento bc_fis_nfe_evento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_evento
    ADD CONSTRAINT bc_fis_nfe_evento_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfe_item bc_fis_nfe_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_item
    ADD CONSTRAINT bc_fis_nfe_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfe bc_fis_nfe_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfe bc_fis_nfe_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_nfse_item bc_fis_nfse_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_item
    ADD CONSTRAINT bc_fis_nfse_item_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfse bc_fis_nfse_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse
    ADD CONSTRAINT bc_fis_nfse_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfse_retorno bc_fis_nfse_retorno_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_retorno
    ADD CONSTRAINT bc_fis_nfse_retorno_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_nfse bc_fis_nfse_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse
    ADD CONSTRAINT bc_fis_nfse_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_regra_tributaria bc_fis_regra_tributaria_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_regra_tributaria
    ADD CONSTRAINT bc_fis_regra_tributaria_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_regra_tributaria bc_fis_regra_tributaria_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_regra_tributaria
    ADD CONSTRAINT bc_fis_regra_tributaria_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_reinf bc_fis_reinf_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_reinf
    ADD CONSTRAINT bc_fis_reinf_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_reinf bc_fis_reinf_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_reinf
    ADD CONSTRAINT bc_fis_reinf_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_servico_lc116 bc_fis_servico_lc116_codigo_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_servico_lc116
    ADD CONSTRAINT bc_fis_servico_lc116_codigo_key UNIQUE (codigo);


--
-- Name: bc_fis_servico_lc116 bc_fis_servico_lc116_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_servico_lc116
    ADD CONSTRAINT bc_fis_servico_lc116_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_sped_contribuicoes bc_fis_sped_contribuicoes_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_contribuicoes
    ADD CONSTRAINT bc_fis_sped_contribuicoes_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_sped_contribuicoes bc_fis_sped_contribuicoes_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_contribuicoes
    ADD CONSTRAINT bc_fis_sped_contribuicoes_uuid_key UNIQUE (uuid);


--
-- Name: bc_fis_sped_fiscal bc_fis_sped_fiscal_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_fiscal
    ADD CONSTRAINT bc_fis_sped_fiscal_pkey PRIMARY KEY (id);


--
-- Name: bc_fis_sped_fiscal bc_fis_sped_fiscal_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_fiscal
    ADD CONSTRAINT bc_fis_sped_fiscal_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_analise_preditiva bc_ia_analise_preditiva_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_analise_preditiva
    ADD CONSTRAINT bc_ia_analise_preditiva_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_analise_preditiva bc_ia_analise_preditiva_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_analise_preditiva
    ADD CONSTRAINT bc_ia_analise_preditiva_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_chat_mensagem bc_ia_chat_mensagem_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_mensagem
    ADD CONSTRAINT bc_ia_chat_mensagem_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_chat_mensagem bc_ia_chat_mensagem_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_mensagem
    ADD CONSTRAINT bc_ia_chat_mensagem_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_chat_message bc_ia_chat_message_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_message
    ADD CONSTRAINT bc_ia_chat_message_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_chat_message bc_ia_chat_message_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_message
    ADD CONSTRAINT bc_ia_chat_message_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_chat_sessao bc_ia_chat_sessao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_sessao
    ADD CONSTRAINT bc_ia_chat_sessao_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_chat_sessao bc_ia_chat_sessao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_sessao
    ADD CONSTRAINT bc_ia_chat_sessao_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_chat_session bc_ia_chat_session_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_session
    ADD CONSTRAINT bc_ia_chat_session_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_chat_session bc_ia_chat_session_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_session
    ADD CONSTRAINT bc_ia_chat_session_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_classificacao bc_ia_classificacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_classificacao
    ADD CONSTRAINT bc_ia_classificacao_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_classificacao bc_ia_classificacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_classificacao
    ADD CONSTRAINT bc_ia_classificacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_config bc_ia_config_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_config
    ADD CONSTRAINT bc_ia_config_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_config bc_ia_config_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_config
    ADD CONSTRAINT bc_ia_config_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_embedding bc_ia_embedding_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_embedding
    ADD CONSTRAINT bc_ia_embedding_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_embedding bc_ia_embedding_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_embedding
    ADD CONSTRAINT bc_ia_embedding_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_prompt bc_ia_prompt_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt
    ADD CONSTRAINT bc_ia_prompt_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_prompt_template bc_ia_prompt_template_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt_template
    ADD CONSTRAINT bc_ia_prompt_template_pkey PRIMARY KEY (id);


--
-- Name: bc_ia_prompt_template bc_ia_prompt_template_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt_template
    ADD CONSTRAINT bc_ia_prompt_template_uuid_key UNIQUE (uuid);


--
-- Name: bc_ia_prompt bc_ia_prompt_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt
    ADD CONSTRAINT bc_ia_prompt_uuid_key UNIQUE (uuid);


--
-- Name: bc_migration_log bc_migration_log_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_migration_log
    ADD CONSTRAINT bc_migration_log_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_apontamento bc_prod_apontamento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_apontamento
    ADD CONSTRAINT bc_prod_apontamento_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_apontamento bc_prod_apontamento_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_apontamento
    ADD CONSTRAINT bc_prod_apontamento_uuid_key UNIQUE (uuid);


--
-- Name: bc_prod_estrutura bc_prod_estrutura_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_estrutura
    ADD CONSTRAINT bc_prod_estrutura_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_estrutura bc_prod_estrutura_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_estrutura
    ADD CONSTRAINT bc_prod_estrutura_uuid_key UNIQUE (uuid);


--
-- Name: bc_prod_item bc_prod_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_item
    ADD CONSTRAINT bc_prod_item_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_ordem bc_prod_ordem_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_ordem
    ADD CONSTRAINT bc_prod_ordem_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_romaneio_item bc_prod_romaneio_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio_item
    ADD CONSTRAINT bc_prod_romaneio_item_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_romaneio_item bc_prod_romaneio_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio_item
    ADD CONSTRAINT bc_prod_romaneio_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_prod_romaneio bc_prod_romaneio_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio
    ADD CONSTRAINT bc_prod_romaneio_pkey PRIMARY KEY (id);


--
-- Name: bc_prod_romaneio bc_prod_romaneio_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio
    ADD CONSTRAINT bc_prod_romaneio_uuid_key UNIQUE (uuid);


--
-- Name: bc_rh_cargo bc_rh_cargo_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_cargo
    ADD CONSTRAINT bc_rh_cargo_pkey PRIMARY KEY (id);


--
-- Name: bc_rh_folha_item bc_rh_folha_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha_item
    ADD CONSTRAINT bc_rh_folha_item_pkey PRIMARY KEY (id);


--
-- Name: bc_rh_folha bc_rh_folha_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha
    ADD CONSTRAINT bc_rh_folha_pkey PRIMARY KEY (id);


--
-- Name: bc_rh_funcionario bc_rh_funcionario_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_funcionario
    ADD CONSTRAINT bc_rh_funcionario_pkey PRIMARY KEY (id);


--
-- Name: bc_srv_ordem_servico bc_srv_ordem_servico_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico
    ADD CONSTRAINT bc_srv_ordem_servico_pkey PRIMARY KEY (id);


--
-- Name: bc_srv_ordem_servico bc_srv_ordem_servico_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico
    ADD CONSTRAINT bc_srv_ordem_servico_uuid_key UNIQUE (uuid);


--
-- Name: bc_srv_os_apontamento bc_srv_os_apontamento_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_apontamento
    ADD CONSTRAINT bc_srv_os_apontamento_pkey PRIMARY KEY (id);


--
-- Name: bc_srv_os_apontamento bc_srv_os_apontamento_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_apontamento
    ADD CONSTRAINT bc_srv_os_apontamento_uuid_key UNIQUE (uuid);


--
-- Name: bc_srv_os_item bc_srv_os_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item
    ADD CONSTRAINT bc_srv_os_item_pkey PRIMARY KEY (id);


--
-- Name: bc_srv_os_item bc_srv_os_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item
    ADD CONSTRAINT bc_srv_os_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_bonificacao_item bc_ven_bonificacao_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao_item
    ADD CONSTRAINT bc_ven_bonificacao_item_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_bonificacao_item bc_ven_bonificacao_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao_item
    ADD CONSTRAINT bc_ven_bonificacao_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_bonificacao bc_ven_bonificacao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao
    ADD CONSTRAINT bc_ven_bonificacao_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_bonificacao bc_ven_bonificacao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao
    ADD CONSTRAINT bc_ven_bonificacao_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_contrato_item bc_ven_contrato_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item
    ADD CONSTRAINT bc_ven_contrato_item_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_contrato_item bc_ven_contrato_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item
    ADD CONSTRAINT bc_ven_contrato_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_contrato bc_ven_contrato_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato
    ADD CONSTRAINT bc_ven_contrato_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_contrato bc_ven_contrato_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato
    ADD CONSTRAINT bc_ven_contrato_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_devolucao bc_ven_devolucao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao
    ADD CONSTRAINT bc_ven_devolucao_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_devolucao bc_ven_devolucao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao
    ADD CONSTRAINT bc_ven_devolucao_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_pedido_item bc_ven_pedido_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item
    ADD CONSTRAINT bc_ven_pedido_item_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_pedido bc_ven_pedido_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT bc_ven_pedido_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_regra_comissao bc_ven_regra_comissao_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_regra_comissao
    ADD CONSTRAINT bc_ven_regra_comissao_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_regra_comissao bc_ven_regra_comissao_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_regra_comissao
    ADD CONSTRAINT bc_ven_regra_comissao_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_tabela_preco_item bc_ven_tabela_preco_item_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item
    ADD CONSTRAINT bc_ven_tabela_preco_item_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_tabela_preco_item bc_ven_tabela_preco_item_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item
    ADD CONSTRAINT bc_ven_tabela_preco_item_uuid_key UNIQUE (uuid);


--
-- Name: bc_ven_tabela_preco bc_ven_tabela_preco_pkey; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco
    ADD CONSTRAINT bc_ven_tabela_preco_pkey PRIMARY KEY (id);


--
-- Name: bc_ven_tabela_preco bc_ven_tabela_preco_uuid_key; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco
    ADD CONSTRAINT bc_ven_tabela_preco_uuid_key UNIQUE (uuid);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: bc_fis_apuracao uk_apuracao; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao
    ADD CONSTRAINT uk_apuracao UNIQUE (empresa_id, imposto_id, competencia);


--
-- Name: bc_cad_produto_ecommerce uk_bc_cad_produto_ecommerce_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_ecommerce
    ADD CONSTRAINT uk_bc_cad_produto_ecommerce_uuid UNIQUE (uuid);


--
-- Name: bc_com_pedido_item uk_bc_com_pedido_item_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido_item
    ADD CONSTRAINT uk_bc_com_pedido_item_uuid UNIQUE (uuid);


--
-- Name: bc_com_pedido uk_bc_com_pedido_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido
    ADD CONSTRAINT uk_bc_com_pedido_uuid UNIQUE (uuid);


--
-- Name: bc_est_movimentacao uk_bc_est_mov_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_movimentacao
    ADD CONSTRAINT uk_bc_est_mov_uuid UNIQUE (uuid);


--
-- Name: bc_est_saldo uk_bc_est_saldo_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_saldo
    ADD CONSTRAINT uk_bc_est_saldo_uuid UNIQUE (uuid);


--
-- Name: bc_fin_caixa uk_bc_fin_caixa_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_caixa
    ADD CONSTRAINT uk_bc_fin_caixa_uuid UNIQUE (uuid);


--
-- Name: bc_fis_apuracao uk_bc_fis_apuracao_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao
    ADD CONSTRAINT uk_bc_fis_apuracao_uuid UNIQUE (uuid);


--
-- Name: bc_rh_cargo uk_bc_rh_cargo_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_cargo
    ADD CONSTRAINT uk_bc_rh_cargo_uuid UNIQUE (uuid);


--
-- Name: bc_rh_folha_item uk_bc_rh_folha_item_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha_item
    ADD CONSTRAINT uk_bc_rh_folha_item_uuid UNIQUE (uuid);


--
-- Name: bc_rh_folha uk_bc_rh_folha_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha
    ADD CONSTRAINT uk_bc_rh_folha_uuid UNIQUE (uuid);


--
-- Name: bc_rh_funcionario uk_bc_rh_funcionario_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_funcionario
    ADD CONSTRAINT uk_bc_rh_funcionario_uuid UNIQUE (uuid);


--
-- Name: bc_ven_pedido_item uk_bc_ven_pedido_item_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item
    ADD CONSTRAINT uk_bc_ven_pedido_item_uuid UNIQUE (uuid);


--
-- Name: bc_ven_pedido uk_bc_ven_pedido_uuid; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT uk_bc_ven_pedido_uuid UNIQUE (uuid);


--
-- Name: bc_cad_cliente uk_cliente_pessoa; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_cliente
    ADD CONSTRAINT uk_cliente_pessoa UNIQUE (empresa_id, pessoa_id);


--
-- Name: bc_fis_cnae_servico uk_cnae_codigo_lc116; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cnae_servico
    ADD CONSTRAINT uk_cnae_codigo_lc116 UNIQUE (codigo, lc116_codigo);


--
-- Name: bc_core_configuracao uk_configuracao; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_configuracao
    ADD CONSTRAINT uk_configuracao UNIQUE (empresa_id, chave);


--
-- Name: bc_core_empresa_vinculo uk_empresa_vinculo; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa_vinculo
    ADD CONSTRAINT uk_empresa_vinculo UNIQUE (empresa_id, empresa_vinculada_id, tipo);


--
-- Name: bc_cad_fornecedor uk_fornecedor_pessoa; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_fornecedor
    ADD CONSTRAINT uk_fornecedor_pessoa UNIQUE (empresa_id, pessoa_id);


--
-- Name: bc_fis_imposto uk_imposto; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_imposto
    ADD CONSTRAINT uk_imposto UNIQUE (empresa_id, sigla);


--
-- Name: bc_fis_issqn uk_issqn_ibge_codigo; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_issqn
    ADD CONSTRAINT uk_issqn_ibge_codigo UNIQUE (cod_ibge, codigo);


--
-- Name: bc_cad_papel uk_papel; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_papel
    ADD CONSTRAINT uk_papel UNIQUE (empresa_id, nome);


--
-- Name: bc_core_perfil uk_perfil_empresa; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil
    ADD CONSTRAINT uk_perfil_empresa UNIQUE (empresa_id, nome);


--
-- Name: bc_core_perfil_permissao uk_perfil_permissao; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil_permissao
    ADD CONSTRAINT uk_perfil_permissao UNIQUE (perfil_id, permissao_id);


--
-- Name: bc_prod_romaneio uk_prod_romaneio_empresa_numero; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio
    ADD CONSTRAINT uk_prod_romaneio_empresa_numero UNIQUE (empresa_id, numero);


--
-- Name: bc_cad_produto uk_produto_codigo; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT uk_produto_codigo UNIQUE (empresa_id, codigo);


--
-- Name: bc_cad_produto_kit uk_produto_kit; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_kit
    ADD CONSTRAINT uk_produto_kit UNIQUE (kit_id, item_id);


--
-- Name: bc_cad_servico uk_servico_codigo; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_servico
    ADD CONSTRAINT uk_servico_codigo UNIQUE (empresa_id, codigo);


--
-- Name: bc_srv_ordem_servico uk_srv_os_numero; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico
    ADD CONSTRAINT uk_srv_os_numero UNIQUE (empresa_id, numero);


--
-- Name: bc_cad_transportadora uk_transportadora_pessoa; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_transportadora
    ADD CONSTRAINT uk_transportadora_pessoa UNIQUE (empresa_id, pessoa_id);


--
-- Name: bc_cad_unidade_medida uk_unidade_medida; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_unidade_medida
    ADD CONSTRAINT uk_unidade_medida UNIQUE (empresa_id, sigla);


--
-- Name: bc_core_usuario_modulo uk_usuario_modulo; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_modulo
    ADD CONSTRAINT uk_usuario_modulo UNIQUE (usuario_id, modulo_id);


--
-- Name: bc_core_usuario_perfil uk_usuario_perfil; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_perfil
    ADD CONSTRAINT uk_usuario_perfil UNIQUE (usuario_id, perfil_id);


--
-- Name: bc_ven_tabela_preco_item uk_ven_tabela_preco_item_produto; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item
    ADD CONSTRAINT uk_ven_tabela_preco_item_produto UNIQUE (tabela_preco_id, produto_id);


--
-- Name: bc_prod_item ukbouojof1acc60wi84fkrr2thm; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_item
    ADD CONSTRAINT ukbouojof1acc60wi84fkrr2thm UNIQUE (uuid);


--
-- Name: bc_fin_comissao ukkiimsqq5tikgf0gnsw4lymuk9; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_comissao
    ADD CONSTRAINT ukkiimsqq5tikgf0gnsw4lymuk9 UNIQUE (uuid);


--
-- Name: bc_prod_ordem ukm4x148ro7hacu4ylqbxsu9e4n; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_ordem
    ADD CONSTRAINT ukm4x148ro7hacu4ylqbxsu9e4n UNIQUE (uuid);


--
-- Name: bc_prod_ordem uksfiffcaxbc909df77yqfuytcy; Type: CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_ordem
    ADD CONSTRAINT uksfiffcaxbc909df77yqfuytcy UNIQUE (numero);


--
-- Name: dim_cliente dim_cliente_cliente_id_key; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_cliente
    ADD CONSTRAINT dim_cliente_cliente_id_key UNIQUE (cliente_id);


--
-- Name: dim_cliente dim_cliente_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_cliente
    ADD CONSTRAINT dim_cliente_pkey PRIMARY KEY (id);


--
-- Name: dim_empresa dim_empresa_empresa_id_key; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_empresa
    ADD CONSTRAINT dim_empresa_empresa_id_key UNIQUE (empresa_id);


--
-- Name: dim_empresa dim_empresa_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_empresa
    ADD CONSTRAINT dim_empresa_pkey PRIMARY KEY (id);


--
-- Name: dim_produto dim_produto_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_produto
    ADD CONSTRAINT dim_produto_pkey PRIMARY KEY (id);


--
-- Name: dim_produto dim_produto_produto_id_key; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_produto
    ADD CONSTRAINT dim_produto_produto_id_key UNIQUE (produto_id);


--
-- Name: dim_tempo dim_tempo_data_key; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_tempo
    ADD CONSTRAINT dim_tempo_data_key UNIQUE (data);


--
-- Name: dim_tempo dim_tempo_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.dim_tempo
    ADD CONSTRAINT dim_tempo_pkey PRIMARY KEY (id);


--
-- Name: ft_compras ft_compras_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_compras
    ADD CONSTRAINT ft_compras_pkey PRIMARY KEY (id);


--
-- Name: ft_estoque ft_estoque_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_estoque
    ADD CONSTRAINT ft_estoque_pkey PRIMARY KEY (id);


--
-- Name: ft_financeiro ft_financeiro_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_financeiro
    ADD CONSTRAINT ft_financeiro_pkey PRIMARY KEY (id);


--
-- Name: ft_producao ft_producao_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_producao
    ADD CONSTRAINT ft_producao_pkey PRIMARY KEY (id);


--
-- Name: ft_vendas ft_vendas_pkey; Type: CONSTRAINT; Schema: brasil_saas_dl; Owner: -
--

ALTER TABLE ONLY brasil_saas_dl.ft_vendas
    ADD CONSTRAINT ft_vendas_pkey PRIMARY KEY (id);


--
-- Name: base_cep base_cep_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base_cep
    ADD CONSTRAINT base_cep_pkey PRIMARY KEY (cep);


--
-- Name: fcaixa fcaixa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcaixa
    ADD CONSTRAINT fcaixa_pkey PRIMARY KEY (codcaixa);


--
-- Name: fcentrocusto fcentrocusto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcentrocusto
    ADD CONSTRAINT fcentrocusto_pkey PRIMARY KEY (codcusto);


--
-- Name: fempresa_vinculo fempresa_vinculo_codmatriz_codfilial_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fempresa_vinculo
    ADD CONSTRAINT fempresa_vinculo_codmatriz_codfilial_key UNIQUE (codmatriz, codfilial);


--
-- Name: fempresa_vinculo fempresa_vinculo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fempresa_vinculo
    ADD CONSTRAINT fempresa_vinculo_pkey PRIMARY KEY (codvinculo);


--
-- Name: ffinanceiro ffinanceiro_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ffinanceiro
    ADD CONSTRAINT ffinanceiro_pkey PRIMARY KEY (codfinanceiro);


--
-- Name: fmovimento_item fmovimento_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmovimento_item
    ADD CONSTRAINT fmovimento_item_pkey PRIMARY KEY (coditem);


--
-- Name: fmovimento fmovimento_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmovimento
    ADD CONSTRAINT fmovimento_pkey PRIMARY KEY (codmovimento);


--
-- Name: fnota_item fnota_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota_item
    ADD CONSTRAINT fnota_item_pkey PRIMARY KEY (id_item);


--
-- Name: fnota fnota_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota
    ADD CONSTRAINT fnota_pkey PRIMARY KEY (id_nota);


--
-- Name: fpessoa fpessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fpessoa
    ADD CONSTRAINT fpessoa_pkey PRIMARY KEY (id_pessoa);


--
-- Name: fproduto_ecommerce fproduto_ecommerce_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_ecommerce
    ADD CONSTRAINT fproduto_ecommerce_pkey PRIMARY KEY (codecommerce);


--
-- Name: fproduto_fiscal fproduto_fiscal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_fiscal
    ADD CONSTRAINT fproduto_fiscal_pkey PRIMARY KEY (codproduto);


--
-- Name: fproduto_imagem fproduto_imagem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_imagem
    ADD CONSTRAINT fproduto_imagem_pkey PRIMARY KEY (codimagem);


--
-- Name: fproduto_kit fproduto_kit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_kit
    ADD CONSTRAINT fproduto_kit_pkey PRIMARY KEY (codkit, codproduto_filho);


--
-- Name: fproduto_movimento fproduto_movimento_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_movimento
    ADD CONSTRAINT fproduto_movimento_pkey PRIMARY KEY (codmov);


--
-- Name: fproduto_variacao fproduto_variacao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_variacao
    ADD CONSTRAINT fproduto_variacao_pkey PRIMARY KEY (codvariacao);


--
-- Name: fvenda_item fvenda_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda_item
    ADD CONSTRAINT fvenda_item_pkey PRIMARY KEY (id_item);


--
-- Name: fvenda fvenda_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda
    ADD CONSTRAINT fvenda_pkey PRIMARY KEY (id_venda);


--
-- Name: fcfo pk_fcfo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcfo
    ADD CONSTRAINT pk_fcfo PRIMARY KEY (codcfo);


--
-- Name: fcondicao pk_fcondicao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcondicao
    ADD CONSTRAINT pk_fcondicao PRIMARY KEY (codcondicao);


--
-- Name: fcusto pk_fcusto; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fcusto
    ADD CONSTRAINT pk_fcusto PRIMARY KEY (codcusto);


--
-- Name: fdatas pk_fdatas_1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fdatas
    ADD CONSTRAINT pk_fdatas_1 PRIMARY KEY (iddata);


--
-- Name: fdia pk_fdia; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fdia
    ADD CONSTRAINT pk_fdia PRIMARY KEY (refdia);


--
-- Name: fdocumento pk_fdocumento_1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fdocumento
    ADD CONSTRAINT pk_fdocumento_1 PRIMARY KEY (coddoc);


--
-- Name: fempresa pk_fempresa; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fempresa
    ADD CONSTRAINT pk_fempresa PRIMARY KEY (codigo);


--
-- Name: fextrato pk_fextrato; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fextrato
    ADD CONSTRAINT pk_fextrato PRIMARY KEY (idlanextrato);


--
-- Name: ffuncionario pk_ffuncionario; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ffuncionario
    ADD CONSTRAINT pk_ffuncionario PRIMARY KEY (codfuncionario);


--
-- Name: fitem pk_fitem; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fitem
    ADD CONSTRAINT pk_fitem PRIMARY KEY (refitem);


--
-- Name: flan pk_flan; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flan
    ADD CONSTRAINT pk_flan PRIMARY KEY (idlan);


--
-- Name: fmov pk_fmov; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmov
    ADD CONSTRAINT pk_fmov PRIMARY KEY (idmov);


--
-- Name: fproduto pk_fproduto; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto
    ADD CONSTRAINT pk_fproduto PRIMARY KEY (codproduto);


--
-- Name: frecibo pk_frecibo_1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.frecibo
    ADD CONSTRAINT pk_frecibo_1 PRIMARY KEY (idrecibo);


--
-- Name: ftipo pk_ftipo_1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ftipo
    ADD CONSTRAINT pk_ftipo_1 PRIMARY KEY (codtipo);


--
-- Name: ftipopagamento pk_ftipopagamento_1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ftipopagamento
    ADD CONSTRAINT pk_ftipopagamento_1 PRIMARY KEY (codtipo);


--
-- Name: fusuario pk_fusuario; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fusuario
    ADD CONSTRAINT pk_fusuario PRIMARY KEY (codigo);


--
-- Name: gparametro pk_gparametro; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gparametro
    ADD CONSTRAINT pk_gparametro PRIMARY KEY (idparametro);


--
-- Name: tmunicipio pk_tmunicipio_1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tmunicipio
    ADD CONSTRAINT pk_tmunicipio_1 PRIMARY KEY (refmunicipio);


--
-- Name: tcnae_servico tcnae_servico_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tcnae_servico
    ADD CONSTRAINT tcnae_servico_pkey PRIMARY KEY (cnae, codigo_item);


--
-- Name: tissqn tissqn_cod_ibge_codigo_servico_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tissqn
    ADD CONSTRAINT tissqn_cod_ibge_codigo_servico_key UNIQUE (cod_ibge, codigo_servico);


--
-- Name: tissqn tissqn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tissqn
    ADD CONSTRAINT tissqn_pkey PRIMARY KEY (id);


--
-- Name: tncm tncm_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tncm
    ADD CONSTRAINT tncm_pkey PRIMARY KEY (codigo);


--
-- Name: tservico_lc116 tservico_lc116_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tservico_lc116
    ADD CONSTRAINT tservico_lc116_pkey PRIMARY KEY (codigo_item);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON brasil_saas.flyway_schema_history USING btree (success);


--
-- Name: idx_apuracao_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_apuracao_empresa ON brasil_saas.bc_fis_apuracao USING btree (empresa_id, competencia);


--
-- Name: idx_auditoria_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_auditoria_empresa ON brasil_saas.bc_core_auditoria USING btree (empresa_id, tabela, created_at);


--
-- Name: idx_base_cep_cep; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_base_cep_cep ON brasil_saas.bc_cad_base_cep USING btree (cep);


--
-- Name: idx_bc_core_perfil_pai_id; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bc_core_perfil_pai_id ON brasil_saas.bc_core_perfil USING btree (perfil_pai_id);


--
-- Name: idx_bc_fin_aprovacao_documento; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bc_fin_aprovacao_documento ON brasil_saas.bc_fin_aprovacao USING btree (tipo_documento, documento_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_bc_fin_aprovacao_pendentes; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bc_fin_aprovacao_pendentes ON brasil_saas.bc_fin_aprovacao USING btree (empresa_id, status, data_solicitacao) WHERE (deleted_at IS NULL);


--
-- Name: idx_bc_fin_aprovacao_titulo_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bc_fin_aprovacao_titulo_status ON brasil_saas.bc_fin_aprovacao USING btree (titulo_id, status) WHERE (deleted_at IS NULL);


--
-- Name: idx_bc_municipio_nome; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bc_municipio_nome ON brasil_saas.bc_cad_municipio USING btree (nome);


--
-- Name: idx_bi_dashboard_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_dashboard_empresa ON brasil_saas.bc_bi_dashboard USING btree (empresa_id);


--
-- Name: idx_bi_dashboard_type; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_dashboard_type ON brasil_saas.bc_bi_dashboard USING btree (dashboard_type);


--
-- Name: idx_bi_dashboard_widget_dashboard; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_dashboard_widget_dashboard ON brasil_saas.bc_bi_dashboard_widget USING btree (dashboard_id);


--
-- Name: idx_bi_indicador_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_indicador_empresa ON brasil_saas.bc_bi_indicador USING btree (empresa_id);


--
-- Name: idx_bi_kpi_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_kpi_empresa ON brasil_saas.bc_bi_kpi USING btree (empresa_id);


--
-- Name: idx_bi_kpi_type; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_kpi_type ON brasil_saas.bc_bi_kpi USING btree (kpi_type);


--
-- Name: idx_bi_relatorio_agendado_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_relatorio_agendado_empresa ON brasil_saas.bc_bi_relatorio_agendado USING btree (empresa_id);


--
-- Name: idx_bi_relatorio_agendado_relatorio; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_relatorio_agendado_relatorio ON brasil_saas.bc_bi_relatorio_agendado USING btree (relatorio_id);


--
-- Name: idx_bi_relatorio_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_relatorio_empresa ON brasil_saas.bc_bi_relatorio USING btree (empresa_id);


--
-- Name: idx_bi_report_category; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_report_category ON brasil_saas.bc_bi_report USING btree (category);


--
-- Name: idx_bi_report_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_report_empresa ON brasil_saas.bc_bi_report USING btree (empresa_id);


--
-- Name: idx_bi_report_parameter_report; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_bi_report_parameter_report ON brasil_saas.bc_bi_report_parameter USING btree (report_id);


--
-- Name: idx_cliente_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_cliente_empresa ON brasil_saas.bc_cad_cliente USING btree (empresa_id);


--
-- Name: idx_com_conferencia_fatura_nfe; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_conferencia_fatura_nfe ON brasil_saas.bc_com_conferencia_fatura USING btree (empresa_id, nfe_id);


--
-- Name: idx_com_conferencia_fatura_pedido; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_conferencia_fatura_pedido ON brasil_saas.bc_com_conferencia_fatura USING btree (empresa_id, pedido_id, status);


--
-- Name: idx_com_conferencia_fatura_titulo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_conferencia_fatura_titulo ON brasil_saas.bc_com_conferencia_fatura USING btree (empresa_id, titulo_id);


--
-- Name: idx_com_cotacao_empresa_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_cotacao_empresa_status ON brasil_saas.bc_com_cotacao USING btree (empresa_id, status);


--
-- Name: idx_com_cotacao_fornecedor; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_cotacao_fornecedor ON brasil_saas.bc_com_cotacao_fornecedor USING btree (empresa_id, fornecedor_id);


--
-- Name: idx_com_cotacao_fornecedor_cotacao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_cotacao_fornecedor_cotacao ON brasil_saas.bc_com_cotacao_fornecedor USING btree (empresa_id, cotacao_id);


--
-- Name: idx_com_cotacao_item_fornecedor; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_cotacao_item_fornecedor ON brasil_saas.bc_com_cotacao_item USING btree (empresa_id, cotacao_fornecedor_id);


--
-- Name: idx_com_cotacao_solicitacao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_cotacao_solicitacao ON brasil_saas.bc_com_cotacao USING btree (empresa_id, solicitacao_id);


--
-- Name: idx_com_item_pedido; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_item_pedido ON brasil_saas.bc_com_pedido_item USING btree (pedido_id);


--
-- Name: idx_com_pedido_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_pedido_empresa ON brasil_saas.bc_com_pedido USING btree (empresa_id, status);


--
-- Name: idx_com_pedido_fornecedor; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_pedido_fornecedor ON brasil_saas.bc_com_pedido USING btree (fornecedor_id);


--
-- Name: idx_com_recebimento_empresa_data; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_recebimento_empresa_data ON brasil_saas.bc_com_recebimento USING btree (empresa_id, data_recebimento DESC);


--
-- Name: idx_com_recebimento_empresa_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_recebimento_empresa_status ON brasil_saas.bc_com_recebimento USING btree (empresa_id, status);


--
-- Name: idx_com_recebimento_item_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_recebimento_item_produto ON brasil_saas.bc_com_recebimento_item USING btree (empresa_id, produto_id);


--
-- Name: idx_com_recebimento_item_recebimento; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_recebimento_item_recebimento ON brasil_saas.bc_com_recebimento_item USING btree (empresa_id, recebimento_id);


--
-- Name: idx_com_recebimento_pedido; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_recebimento_pedido ON brasil_saas.bc_com_recebimento USING btree (empresa_id, pedido_id);


--
-- Name: idx_com_solicitacao_empresa_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_solicitacao_empresa_status ON brasil_saas.bc_com_solicitacao USING btree (empresa_id, status);


--
-- Name: idx_com_solicitacao_item_empresa_solicitacao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_com_solicitacao_item_empresa_solicitacao ON brasil_saas.bc_com_solicitacao_item USING btree (empresa_id, solicitacao_id);


--
-- Name: idx_crm_atividade_agendada; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_crm_atividade_agendada ON brasil_saas.bc_crm_atividade USING btree (empresa_id, data_agendada, status);


--
-- Name: idx_crm_oportunidade_vendedor_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_crm_oportunidade_vendedor_status ON brasil_saas.bc_crm_oportunidade USING btree (empresa_id, vendedor_id, status);


--
-- Name: idx_endereco_pessoa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_endereco_pessoa ON brasil_saas.bc_cad_endereco USING btree (pessoa_id);


--
-- Name: idx_est_endereco_deposito_ativo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_endereco_deposito_ativo ON brasil_saas.bc_est_endereco USING btree (empresa_id, deposito_id, ativo);


--
-- Name: idx_est_expedicao_item; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_expedicao_item ON brasil_saas.bc_est_expedicao_item USING btree (empresa_id, expedicao_id);


--
-- Name: idx_est_expedicao_item_auditoria; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_expedicao_item_auditoria ON brasil_saas.bc_est_expedicao_item USING btree (empresa_id, expedicao_id, created_at);


--
-- Name: idx_est_expedicao_item_deleted; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_expedicao_item_deleted ON brasil_saas.bc_est_expedicao_item USING btree (empresa_id, expedicao_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_est_expedicao_item_endereco; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_expedicao_item_endereco ON brasil_saas.bc_est_expedicao_item USING btree (empresa_id, endereco_id, lote_id, status);


--
-- Name: idx_est_expedicao_item_lote; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_expedicao_item_lote ON brasil_saas.bc_est_expedicao_item USING btree (empresa_id, lote_id, status);


--
-- Name: idx_est_expedicao_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_expedicao_status ON brasil_saas.bc_est_expedicao USING btree (empresa_id, deposito_id, status, data_abertura DESC);


--
-- Name: idx_est_inventario_empresa_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_inventario_empresa_status ON brasil_saas.bc_est_inventario USING btree (empresa_id, deposito_id, status);


--
-- Name: idx_est_inventario_item_inventario; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_inventario_item_inventario ON brasil_saas.bc_est_inventario_item USING btree (inventario_id);


--
-- Name: idx_est_inventario_item_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_inventario_item_produto ON brasil_saas.bc_est_inventario_item USING btree (produto_id, lote_id, endereco_id);


--
-- Name: idx_est_lote_fefo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_lote_fefo ON brasil_saas.bc_est_lote USING btree (empresa_id, deposito_id, produto_id, status, data_validade);


--
-- Name: idx_est_lote_validade_ativo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_lote_validade_ativo ON brasil_saas.bc_est_lote USING btree (empresa_id, deposito_id, produto_id, status, data_validade, id);


--
-- Name: idx_est_mov_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_mov_produto ON brasil_saas.bc_est_movimentacao USING btree (empresa_id, produto_id, data_movimento);


--
-- Name: idx_est_reserva_endereco_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_reserva_endereco_status ON brasil_saas.bc_est_reserva USING btree (empresa_id, deposito_id, endereco_id, produto_id, lote_id, status);


--
-- Name: idx_est_reserva_lote_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_reserva_lote_status ON brasil_saas.bc_est_reserva USING btree (empresa_id, deposito_id, produto_id, lote_id, status);


--
-- Name: idx_est_reserva_pedido; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_reserva_pedido ON brasil_saas.bc_est_reserva USING btree (empresa_id, pedido_venda_id, status);


--
-- Name: idx_est_reserva_produto_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_reserva_produto_status ON brasil_saas.bc_est_reserva USING btree (empresa_id, deposito_id, produto_id, status);


--
-- Name: idx_est_saldo_deposito_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_saldo_deposito_produto ON brasil_saas.bc_est_saldo USING btree (deposito_id, produto_id);


--
-- Name: idx_est_saldo_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_saldo_produto ON brasil_saas.bc_est_saldo USING btree (empresa_id, produto_id);


--
-- Name: idx_est_serie_produto_deposito; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_serie_produto_deposito ON brasil_saas.bc_est_serie USING btree (empresa_id, produto_id, deposito_id, status);


--
-- Name: idx_est_transferencia_empresa_data; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_transferencia_empresa_data ON brasil_saas.bc_est_transferencia USING btree (empresa_id, data_transferencia DESC);


--
-- Name: idx_est_transferencia_item_transferencia; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_transferencia_item_transferencia ON brasil_saas.bc_est_transferencia_item USING btree (transferencia_id);


--
-- Name: idx_est_transferencia_item_wms; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_est_transferencia_item_wms ON brasil_saas.bc_est_transferencia_item USING btree (lote_id, endereco_origem_id, endereco_destino_id);


--
-- Name: idx_fin_baixa_empresa_conta_data; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_baixa_empresa_conta_data ON brasil_saas.bc_fin_baixa USING btree (empresa_id, conta_bancaria_id, data_baixa) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_baixa_empresa_titulo_data; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_baixa_empresa_titulo_data ON brasil_saas.bc_fin_baixa USING btree (empresa_id, titulo_id, data_baixa) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_baixa_empresa_titulo_parcela_data; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_baixa_empresa_titulo_parcela_data ON brasil_saas.bc_fin_baixa USING btree (empresa_id, titulo_id, parcela_id, data_baixa DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_extrato_conta_data_id; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_extrato_conta_data_id ON brasil_saas.bc_fin_extrato USING btree (conta_bancaria_id, data_movimento DESC, id DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_extrato_empresa_conciliado; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_extrato_empresa_conciliado ON brasil_saas.bc_fin_extrato USING btree (empresa_id, conciliado, data_movimento DESC) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_titulo_empresa_status_vencimento; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_titulo_empresa_status_vencimento ON brasil_saas.bc_fin_titulo USING btree (empresa_id, status, data_vencimento) WHERE (deleted_at IS NULL);


--
-- Name: idx_fin_titulo_parcela_empresa_status_vencimento; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fin_titulo_parcela_empresa_status_vencimento ON brasil_saas.bc_fin_titulo_parcela USING btree (empresa_id, status, data_vencimento) WHERE (deleted_at IS NULL);


--
-- Name: idx_fis_nfe_pedido_compra; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fis_nfe_pedido_compra ON brasil_saas.bc_fis_nfe USING btree (empresa_id, pedido_compra_id);


--
-- Name: idx_fis_nfe_pedido_venda; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_fis_nfe_pedido_venda ON brasil_saas.bc_fis_nfe USING btree (empresa_id, pedido_venda_id);


--
-- Name: idx_ia_analise_preditiva_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_analise_preditiva_empresa ON brasil_saas.bc_ia_analise_preditiva USING btree (empresa_id);


--
-- Name: idx_ia_chat_mensagem_sessao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_mensagem_sessao ON brasil_saas.bc_ia_chat_mensagem USING btree (sessao_id);


--
-- Name: idx_ia_chat_message_session; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_message_session ON brasil_saas.bc_ia_chat_message USING btree (session_id);


--
-- Name: idx_ia_chat_message_type; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_message_type ON brasil_saas.bc_ia_chat_message USING btree (message_type);


--
-- Name: idx_ia_chat_sessao_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_sessao_empresa ON brasil_saas.bc_ia_chat_sessao USING btree (empresa_id);


--
-- Name: idx_ia_chat_session_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_session_empresa ON brasil_saas.bc_ia_chat_session USING btree (empresa_id);


--
-- Name: idx_ia_chat_session_type; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_session_type ON brasil_saas.bc_ia_chat_session USING btree (session_type);


--
-- Name: idx_ia_chat_session_user; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_chat_session_user ON brasil_saas.bc_ia_chat_session USING btree (user_id);


--
-- Name: idx_ia_classificacao_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_classificacao_empresa ON brasil_saas.bc_ia_classificacao USING btree (empresa_id);


--
-- Name: idx_ia_config_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_config_empresa ON brasil_saas.bc_ia_config USING btree (empresa_id);


--
-- Name: idx_ia_embedding_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_embedding_empresa ON brasil_saas.bc_ia_embedding USING btree (empresa_id);


--
-- Name: idx_ia_prompt_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_prompt_empresa ON brasil_saas.bc_ia_prompt USING btree (empresa_id);


--
-- Name: idx_ia_prompt_template_category; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_prompt_template_category ON brasil_saas.bc_ia_prompt_template USING btree (category);


--
-- Name: idx_ia_prompt_template_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ia_prompt_template_empresa ON brasil_saas.bc_ia_prompt_template USING btree (empresa_id);


--
-- Name: idx_log_acesso_usuario; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_log_acesso_usuario ON brasil_saas.bc_core_log_acesso USING btree (usuario_id, created_at);


--
-- Name: idx_nfe_chave; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_nfe_chave ON brasil_saas.bc_fis_nfe USING btree (chave_acesso);


--
-- Name: idx_nfe_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_nfe_empresa ON brasil_saas.bc_fis_nfe USING btree (empresa_id, data_emissao);


--
-- Name: idx_nfe_item_nfe; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_nfe_item_nfe ON brasil_saas.bc_fis_nfe_item USING btree (nfe_id);


--
-- Name: idx_nfse_chave; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_nfse_chave ON brasil_saas.bc_fis_nfse USING btree (codigo_verificacao);


--
-- Name: idx_nfse_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_nfse_empresa ON brasil_saas.bc_fis_nfse USING btree (empresa_id, data_emissao);


--
-- Name: idx_notificacao_usuario; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_notificacao_usuario ON brasil_saas.bc_core_notificacao USING btree (usuario_id, lida);


--
-- Name: idx_pessoa_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_pessoa_empresa ON brasil_saas.bc_cad_pessoa USING btree (empresa_id, nome);


--
-- Name: idx_prod_apontamento_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_apontamento_empresa ON brasil_saas.bc_prod_apontamento USING btree (empresa_id);


--
-- Name: idx_prod_apontamento_item; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_apontamento_item ON brasil_saas.bc_prod_apontamento USING btree (item_producao_id);


--
-- Name: idx_prod_apontamento_producao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_apontamento_producao ON brasil_saas.bc_prod_apontamento USING btree (producao_id);


--
-- Name: idx_prod_estrutura_filho; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_estrutura_filho ON brasil_saas.bc_prod_estrutura USING btree (empresa_id, produto_filho_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_prod_estrutura_pai; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_estrutura_pai ON brasil_saas.bc_prod_estrutura USING btree (empresa_id, produto_pai_id, ativo) WHERE (deleted_at IS NULL);


--
-- Name: idx_prod_item_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_item_empresa ON brasil_saas.bc_prod_item USING btree (empresa_id);


--
-- Name: idx_prod_item_producao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_item_producao ON brasil_saas.bc_prod_item USING btree (producao_id);


--
-- Name: idx_prod_ordem_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_ordem_empresa ON brasil_saas.bc_prod_ordem USING btree (empresa_id);


--
-- Name: idx_prod_romaneio_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_romaneio_empresa ON brasil_saas.bc_prod_romaneio USING btree (empresa_id);


--
-- Name: idx_prod_romaneio_item_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_romaneio_item_produto ON brasil_saas.bc_prod_romaneio_item USING btree (produto_id);


--
-- Name: idx_prod_romaneio_item_romaneio; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_romaneio_item_romaneio ON brasil_saas.bc_prod_romaneio_item USING btree (romaneio_id);


--
-- Name: idx_prod_romaneio_producao; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_prod_romaneio_producao ON brasil_saas.bc_prod_romaneio USING btree (producao_id);


--
-- Name: idx_produto_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_produto_empresa ON brasil_saas.bc_cad_produto USING btree (empresa_id, nome);


--
-- Name: idx_rh_folha_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_rh_folha_empresa ON brasil_saas.bc_rh_folha USING btree (empresa_id, competencia);


--
-- Name: idx_rh_folha_item_folha; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_rh_folha_item_folha ON brasil_saas.bc_rh_folha_item USING btree (folha_id);


--
-- Name: idx_rh_func_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_rh_func_empresa ON brasil_saas.bc_rh_funcionario USING btree (empresa_id);


--
-- Name: idx_servico_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_servico_empresa ON brasil_saas.bc_cad_servico USING btree (empresa_id);


--
-- Name: idx_sessao_usuario; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_sessao_usuario ON brasil_saas.bc_core_sessao USING btree (usuario_id, expira_at);


--
-- Name: idx_srv_os_apont_os; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_srv_os_apont_os ON brasil_saas.bc_srv_os_apontamento USING btree (os_id);


--
-- Name: idx_srv_os_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_srv_os_empresa ON brasil_saas.bc_srv_ordem_servico USING btree (empresa_id, status);


--
-- Name: idx_srv_os_item_os; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_srv_os_item_os ON brasil_saas.bc_srv_os_item USING btree (os_id);


--
-- Name: idx_ven_contrato_cliente_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_contrato_cliente_status ON brasil_saas.bc_ven_contrato USING btree (empresa_id, cliente_id, status);


--
-- Name: idx_ven_devolucao_cliente_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_devolucao_cliente_status ON brasil_saas.bc_ven_devolucao USING btree (empresa_id, cliente_id, status);


--
-- Name: idx_ven_item_pedido; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_item_pedido ON brasil_saas.bc_ven_pedido_item USING btree (pedido_id);


--
-- Name: idx_ven_pedido_cliente; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_pedido_cliente ON brasil_saas.bc_ven_pedido USING btree (cliente_id);


--
-- Name: idx_ven_pedido_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_pedido_empresa ON brasil_saas.bc_ven_pedido USING btree (empresa_id, status);


--
-- Name: idx_ven_pedido_tabela_preco; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_pedido_tabela_preco ON brasil_saas.bc_ven_pedido USING btree (empresa_id, tabela_preco_id);


--
-- Name: idx_ven_regra_comissao_vendedor; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_regra_comissao_vendedor ON brasil_saas.bc_ven_regra_comissao USING btree (empresa_id, vendedor_id, ativo);


--
-- Name: idx_ven_tabela_preco_item_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX idx_ven_tabela_preco_item_produto ON brasil_saas.bc_ven_tabela_preco_item USING btree (empresa_id, produto_id);


--
-- Name: ix_bc_cad_produto_codigo_barras; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_bc_cad_produto_codigo_barras ON brasil_saas.bc_cad_produto USING btree (codigo_barras) WHERE ((codigo_barras IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: ix_bc_core_banco_nome; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_bc_core_banco_nome ON brasil_saas.bc_core_banco USING btree (lower((nome)::text));


--
-- Name: ix_bc_core_banco_pix; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_bc_core_banco_pix ON brasil_saas.bc_core_banco USING btree (aceita_pix) WHERE aceita_pix;


--
-- Name: ix_bc_fin_caixa_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_bc_fin_caixa_empresa ON brasil_saas.bc_fin_caixa USING btree (empresa_id, nome);


--
-- Name: ix_bc_fis_nfe_item_codigo_barras; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_bc_fis_nfe_item_codigo_barras ON brasil_saas.bc_fis_nfe_item USING btree (codigo_barras) WHERE (codigo_barras IS NOT NULL);


--
-- Name: ix_bc_fis_nfe_item_nfe; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_bc_fis_nfe_item_nfe ON brasil_saas.bc_fis_nfe_item USING btree (nfe_id);


--
-- Name: ix_fin_boleto_chave; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_boleto_chave ON brasil_saas.bc_fin_boleto USING btree (empresa_id, banco, nosso_numero_chave);


--
-- Name: ix_fin_boleto_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_boleto_empresa ON brasil_saas.bc_fin_boleto USING btree (empresa_id, criado_em DESC);


--
-- Name: ix_fin_boleto_nosso_numero; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_boleto_nosso_numero ON brasil_saas.bc_fin_boleto USING btree (empresa_id, banco, nosso_numero);


--
-- Name: ix_fin_boleto_titulo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_boleto_titulo ON brasil_saas.bc_fin_boleto USING btree (titulo_id);


--
-- Name: ix_fin_boleto_vencimento; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_boleto_vencimento ON brasil_saas.bc_fin_boleto USING btree (empresa_id, vencimento) WHERE ((status)::text = 'EMITIDO'::text);


--
-- Name: ix_fin_remessa_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_remessa_empresa ON brasil_saas.bc_fin_remessa USING btree (empresa_id, data_geracao DESC);


--
-- Name: ix_fin_remessa_item_remessa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_remessa_item_remessa ON brasil_saas.bc_fin_remessa_item USING btree (remessa_id);


--
-- Name: ix_fin_remessa_item_titulo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_remessa_item_titulo ON brasil_saas.bc_fin_remessa_item USING btree (titulo_id);


--
-- Name: ix_fin_remessa_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_remessa_status ON brasil_saas.bc_fin_remessa USING btree (empresa_id, status);


--
-- Name: ix_fin_retorno_empresa; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_retorno_empresa ON brasil_saas.bc_fin_retorno_bancario USING btree (empresa_id, criado_em DESC);


--
-- Name: ix_fin_retorno_item_nosso_numero; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_retorno_item_nosso_numero ON brasil_saas.bc_fin_retorno_item USING btree (nosso_numero);


--
-- Name: ix_fin_retorno_item_retorno; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_retorno_item_retorno ON brasil_saas.bc_fin_retorno_item USING btree (retorno_id);


--
-- Name: ix_fin_retorno_item_titulo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fin_retorno_item_titulo ON brasil_saas.bc_fin_retorno_item USING btree (titulo_id);


--
-- Name: ix_fis_nfse_empresa_status; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fis_nfse_empresa_status ON brasil_saas.bc_fis_nfse USING btree (empresa_id, status);


--
-- Name: ix_fis_nfse_retorno_indeciso; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fis_nfse_retorno_indeciso ON brasil_saas.bc_fis_nfse_retorno USING btree (empresa_id, created_at DESC) WHERE (sucesso IS NULL);


--
-- Name: ix_fis_nfse_retorno_nfse; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fis_nfse_retorno_nfse ON brasil_saas.bc_fis_nfse_retorno USING btree (nfse_id, created_at DESC);


--
-- Name: ix_fis_nfse_retorno_sem_sucesso; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_fis_nfse_retorno_sem_sucesso ON brasil_saas.bc_fis_nfse_retorno USING btree (empresa_id, created_at DESC) WHERE (sucesso IS FALSE);


--
-- Name: ix_usuario_modulo_modulo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_usuario_modulo_modulo ON brasil_saas.bc_core_usuario_modulo USING btree (modulo_id);


--
-- Name: ix_usuario_modulo_usuario; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE INDEX ix_usuario_modulo_usuario ON brasil_saas.bc_core_usuario_modulo USING btree (usuario_id);


--
-- Name: uk_bc_fin_caixa_empresa_nome; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_bc_fin_caixa_empresa_nome ON brasil_saas.bc_fin_caixa USING btree (empresa_id, lower((nome)::text));


--
-- Name: uk_empresa_matriz_por_grupo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_empresa_matriz_por_grupo ON brasil_saas.bc_core_empresa USING btree (grupo_cnpj_cpf) WHERE (matriz AND (deleted_at IS NULL));


--
-- Name: uk_est_deposito_codigo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_deposito_codigo ON brasil_saas.bc_est_deposito USING btree (empresa_id, codigo) WHERE (deleted_at IS NULL);


--
-- Name: uk_est_endereco_codigo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_endereco_codigo ON brasil_saas.bc_est_endereco USING btree (deposito_id, codigo) WHERE (deleted_at IS NULL);


--
-- Name: uk_est_expedicao_pedido_aberta; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_expedicao_pedido_aberta ON brasil_saas.bc_est_expedicao USING btree (empresa_id, pedido_venda_id) WHERE ((deleted_at IS NULL) AND ((status)::text <> ALL (ARRAY[('EXPEDIDA'::character varying)::text, ('CANCELADA'::character varying)::text])));


--
-- Name: uk_est_lote_produto_codigo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_lote_produto_codigo ON brasil_saas.bc_est_lote USING btree (empresa_id, produto_id, codigo) WHERE (deleted_at IS NULL);


--
-- Name: uk_est_reserva_pedido_produto_deposito_lote; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_reserva_pedido_produto_deposito_lote ON brasil_saas.bc_est_reserva USING btree (empresa_id, pedido_venda_id, deposito_id, produto_id, lote_id) WHERE ((pedido_venda_id IS NOT NULL) AND (lote_id IS NOT NULL) AND (deleted_at IS NULL) AND ((status)::text = ANY (ARRAY[('RESERVADA'::character varying)::text, ('SEPARACAO'::character varying)::text])));


--
-- Name: uk_est_reserva_pedido_produto_deposito_sem_lote; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_reserva_pedido_produto_deposito_sem_lote ON brasil_saas.bc_est_reserva USING btree (empresa_id, pedido_venda_id, deposito_id, produto_id) WHERE ((pedido_venda_id IS NOT NULL) AND (lote_id IS NULL) AND (deleted_at IS NULL) AND ((status)::text = ANY (ARRAY[('RESERVADA'::character varying)::text, ('SEPARACAO'::character varying)::text])));


--
-- Name: uk_est_saldo_empresa_deposito_produto; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_saldo_empresa_deposito_produto ON brasil_saas.bc_est_saldo USING btree (empresa_id, deposito_id, produto_id);


--
-- Name: uk_est_serie_numero; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_est_serie_numero ON brasil_saas.bc_est_serie USING btree (empresa_id, numero_serie) WHERE (deleted_at IS NULL);


--
-- Name: uk_prod_estrutura_item; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_prod_estrutura_item ON brasil_saas.bc_prod_estrutura USING btree (empresa_id, produto_pai_id, produto_filho_id) WHERE (deleted_at IS NULL);


--
-- Name: uk_ven_tabela_preco_codigo; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX uk_ven_tabela_preco_codigo ON brasil_saas.bc_ven_tabela_preco USING btree (empresa_id, codigo) WHERE ((codigo IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: ux_bc_fis_nfe_item_uuid; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX ux_bc_fis_nfe_item_uuid ON brasil_saas.bc_fis_nfe_item USING btree (uuid);


--
-- Name: ux_cad_servico_codigo_municipal; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX ux_cad_servico_codigo_municipal ON brasil_saas.bc_cad_servico USING btree (empresa_id, codigo_tributacao_municipal) WHERE ((codigo_tributacao_municipal IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: ux_fis_nfse_chave_nacional; Type: INDEX; Schema: brasil_saas; Owner: -
--

CREATE UNIQUE INDEX ux_fis_nfse_chave_nacional ON brasil_saas.bc_fis_nfse USING btree (chave_nota_nacional) WHERE ((chave_nota_nacional IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_dl_cliente_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_cliente_empresa ON brasil_saas_dl.dim_cliente USING btree (empresa_id);


--
-- Name: idx_dl_compras_data_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_compras_data_empresa ON brasil_saas_dl.ft_compras USING btree (data_id, empresa_id);


--
-- Name: idx_dl_estoque_data_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_estoque_data_empresa ON brasil_saas_dl.ft_estoque USING btree (data_id, empresa_id);


--
-- Name: idx_dl_financeiro_data_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_financeiro_data_empresa ON brasil_saas_dl.ft_financeiro USING btree (data_id, empresa_id);


--
-- Name: idx_dl_producao_data_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_producao_data_empresa ON brasil_saas_dl.ft_producao USING btree (data_id, empresa_id);


--
-- Name: idx_dl_produto_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_produto_empresa ON brasil_saas_dl.dim_produto USING btree (empresa_id);


--
-- Name: idx_dl_tempo_ano_mes; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_tempo_ano_mes ON brasil_saas_dl.dim_tempo USING btree (ano, mes);


--
-- Name: idx_dl_vendas_data_empresa; Type: INDEX; Schema: brasil_saas_dl; Owner: -
--

CREATE INDEX idx_dl_vendas_data_empresa ON brasil_saas_dl.ft_vendas USING btree (data_id, empresa_id);


--
-- Name: idx_fprodvar_ean; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fprodvar_ean ON public.fproduto_variacao USING btree (codigo_barras);


--
-- Name: idx_fprodvar_produto; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fprodvar_produto ON public.fproduto_variacao USING btree (codproduto);


--
-- Name: idx_fvenda_cliente; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fvenda_cliente ON public.fvenda USING btree (id_cliente);


--
-- Name: idx_fvenda_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fvenda_data ON public.fvenda USING btree (data_venda);


--
-- Name: idx_tissqn_cod; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tissqn_cod ON public.tissqn USING btree (codigo_servico);


--
-- Name: idx_tissqn_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tissqn_desc ON public.tissqn USING btree (descricao);


--
-- Name: idx_tissqn_mun; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tissqn_mun ON public.tissqn USING btree (municipio);


--
-- Name: idx_tmunicipio_ibge; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tmunicipio_ibge ON public.tmunicipio USING btree (codigoibge);


--
-- Name: idx_tmunicipio_nome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tmunicipio_nome ON public.tmunicipio USING btree (nomemunucipio);


--
-- Name: bc_bi_dashboard bc_bi_dashboard_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard
    ADD CONSTRAINT bc_bi_dashboard_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_bi_dashboard_widget bc_bi_dashboard_widget_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_dashboard_widget
    ADD CONSTRAINT bc_bi_dashboard_widget_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES brasil_saas.bc_bi_dashboard(id) ON DELETE CASCADE;


--
-- Name: bc_bi_indicador bc_bi_indicador_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_indicador
    ADD CONSTRAINT bc_bi_indicador_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_bi_kpi bc_bi_kpi_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_kpi
    ADD CONSTRAINT bc_bi_kpi_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_bi_relatorio_agendado bc_bi_relatorio_agendado_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio_agendado
    ADD CONSTRAINT bc_bi_relatorio_agendado_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_bi_relatorio_agendado bc_bi_relatorio_agendado_relatorio_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio_agendado
    ADD CONSTRAINT bc_bi_relatorio_agendado_relatorio_id_fkey FOREIGN KEY (relatorio_id) REFERENCES brasil_saas.bc_bi_relatorio(id) ON DELETE SET NULL;


--
-- Name: bc_bi_relatorio bc_bi_relatorio_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_relatorio
    ADD CONSTRAINT bc_bi_relatorio_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_bi_report bc_bi_report_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report
    ADD CONSTRAINT bc_bi_report_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_bi_report_parameter bc_bi_report_parameter_report_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_bi_report_parameter
    ADD CONSTRAINT bc_bi_report_parameter_report_id_fkey FOREIGN KEY (report_id) REFERENCES brasil_saas.bc_bi_report(id) ON DELETE CASCADE;


--
-- Name: bc_cad_base_cep bc_cad_base_cep_municipio_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_base_cep
    ADD CONSTRAINT bc_cad_base_cep_municipio_id_fkey FOREIGN KEY (municipio_id) REFERENCES brasil_saas.bc_cad_municipio(id);


--
-- Name: bc_cad_categoria bc_cad_categoria_categoria_pai_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_categoria
    ADD CONSTRAINT bc_cad_categoria_categoria_pai_id_fkey FOREIGN KEY (categoria_pai_id) REFERENCES brasil_saas.bc_cad_categoria(id);


--
-- Name: bc_cad_categoria bc_cad_categoria_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_categoria
    ADD CONSTRAINT bc_cad_categoria_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_cliente bc_cad_cliente_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_cliente
    ADD CONSTRAINT bc_cad_cliente_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_cliente bc_cad_cliente_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_cliente
    ADD CONSTRAINT bc_cad_cliente_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_contato bc_cad_contato_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_contato
    ADD CONSTRAINT bc_cad_contato_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_contato bc_cad_contato_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_contato
    ADD CONSTRAINT bc_cad_contato_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_documento_fiscal bc_cad_documento_fiscal_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_documento_fiscal
    ADD CONSTRAINT bc_cad_documento_fiscal_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_documento_fiscal bc_cad_documento_fiscal_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_documento_fiscal
    ADD CONSTRAINT bc_cad_documento_fiscal_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_endereco bc_cad_endereco_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_endereco
    ADD CONSTRAINT bc_cad_endereco_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_endereco bc_cad_endereco_municipio_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_endereco
    ADD CONSTRAINT bc_cad_endereco_municipio_id_fkey FOREIGN KEY (municipio_id) REFERENCES brasil_saas.bc_cad_municipio(id);


--
-- Name: bc_cad_endereco bc_cad_endereco_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_endereco
    ADD CONSTRAINT bc_cad_endereco_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_fornecedor bc_cad_fornecedor_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_fornecedor
    ADD CONSTRAINT bc_cad_fornecedor_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_fornecedor bc_cad_fornecedor_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_fornecedor
    ADD CONSTRAINT bc_cad_fornecedor_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_marca bc_cad_marca_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_marca
    ADD CONSTRAINT bc_cad_marca_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_papel bc_cad_papel_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_papel
    ADD CONSTRAINT bc_cad_papel_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_pessoa bc_cad_pessoa_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa
    ADD CONSTRAINT bc_cad_pessoa_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_pessoa_fisica bc_cad_pessoa_fisica_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_fisica
    ADD CONSTRAINT bc_cad_pessoa_fisica_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_pessoa_juridica bc_cad_pessoa_juridica_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_pessoa_juridica
    ADD CONSTRAINT bc_cad_pessoa_juridica_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_produto bc_cad_produto_categoria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT bc_cad_produto_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES brasil_saas.bc_cad_categoria(id);


--
-- Name: bc_cad_produto_ecommerce bc_cad_produto_ecommerce_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_ecommerce
    ADD CONSTRAINT bc_cad_produto_ecommerce_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_produto_ecommerce bc_cad_produto_ecommerce_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_ecommerce
    ADD CONSTRAINT bc_cad_produto_ecommerce_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_cad_produto bc_cad_produto_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT bc_cad_produto_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_produto_imagem bc_cad_produto_imagem_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_imagem
    ADD CONSTRAINT bc_cad_produto_imagem_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_produto_imagem bc_cad_produto_imagem_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_imagem
    ADD CONSTRAINT bc_cad_produto_imagem_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_cad_produto_kit bc_cad_produto_kit_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_kit
    ADD CONSTRAINT bc_cad_produto_kit_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_produto_kit bc_cad_produto_kit_item_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_kit
    ADD CONSTRAINT bc_cad_produto_kit_item_id_fkey FOREIGN KEY (item_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_cad_produto_kit bc_cad_produto_kit_kit_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_kit
    ADD CONSTRAINT bc_cad_produto_kit_kit_id_fkey FOREIGN KEY (kit_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_cad_produto bc_cad_produto_marca_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT bc_cad_produto_marca_id_fkey FOREIGN KEY (marca_id) REFERENCES brasil_saas.bc_cad_marca(id);


--
-- Name: bc_cad_produto bc_cad_produto_unidade_medida_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto
    ADD CONSTRAINT bc_cad_produto_unidade_medida_id_fkey FOREIGN KEY (unidade_medida_id) REFERENCES brasil_saas.bc_cad_unidade_medida(id);


--
-- Name: bc_cad_produto_variacao bc_cad_produto_variacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_variacao
    ADD CONSTRAINT bc_cad_produto_variacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_produto_variacao bc_cad_produto_variacao_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_produto_variacao
    ADD CONSTRAINT bc_cad_produto_variacao_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_cad_servico bc_cad_servico_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_servico
    ADD CONSTRAINT bc_cad_servico_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_servico bc_cad_servico_unidade_medida_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_servico
    ADD CONSTRAINT bc_cad_servico_unidade_medida_id_fkey FOREIGN KEY (unidade_medida_id) REFERENCES brasil_saas.bc_cad_unidade_medida(id);


--
-- Name: bc_cad_transportadora bc_cad_transportadora_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_transportadora
    ADD CONSTRAINT bc_cad_transportadora_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_cad_transportadora bc_cad_transportadora_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_transportadora
    ADD CONSTRAINT bc_cad_transportadora_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_cad_unidade_medida bc_cad_unidade_medida_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_cad_unidade_medida
    ADD CONSTRAINT bc_cad_unidade_medida_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_nfe_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_nfe_fkey FOREIGN KEY (nfe_id) REFERENCES brasil_saas.bc_fis_nfe(id);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_pedido_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES brasil_saas.bc_com_pedido(id);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_recebimento_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_recebimento_id_fkey FOREIGN KEY (recebimento_id) REFERENCES brasil_saas.bc_com_recebimento(id);


--
-- Name: bc_com_conferencia_fatura bc_com_conferencia_fatura_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_conferencia_fatura
    ADD CONSTRAINT bc_com_conferencia_fatura_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_com_contrato bc_com_contrato_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_contrato
    ADD CONSTRAINT bc_com_contrato_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_contrato bc_com_contrato_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_contrato
    ADD CONSTRAINT bc_com_contrato_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES brasil_saas.bc_cad_fornecedor(id);


--
-- Name: bc_com_cotacao bc_com_cotacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao
    ADD CONSTRAINT bc_com_cotacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_cotacao_fornecedor bc_com_cotacao_fornecedor_condicao_pagamento_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor
    ADD CONSTRAINT bc_com_cotacao_fornecedor_condicao_pagamento_id_fkey FOREIGN KEY (condicao_pagamento_id) REFERENCES brasil_saas.bc_fin_condicao_pagamento(id);


--
-- Name: bc_com_cotacao_fornecedor bc_com_cotacao_fornecedor_cotacao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor
    ADD CONSTRAINT bc_com_cotacao_fornecedor_cotacao_id_fkey FOREIGN KEY (cotacao_id) REFERENCES brasil_saas.bc_com_cotacao(id);


--
-- Name: bc_com_cotacao_fornecedor bc_com_cotacao_fornecedor_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor
    ADD CONSTRAINT bc_com_cotacao_fornecedor_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_cotacao_fornecedor bc_com_cotacao_fornecedor_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_fornecedor
    ADD CONSTRAINT bc_com_cotacao_fornecedor_fornecedor_id_fkey FOREIGN KEY (fornecedor_id) REFERENCES brasil_saas.bc_cad_fornecedor(id);


--
-- Name: bc_com_cotacao_item bc_com_cotacao_item_cotacao_fornecedor_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_item
    ADD CONSTRAINT bc_com_cotacao_item_cotacao_fornecedor_id_fkey FOREIGN KEY (cotacao_fornecedor_id) REFERENCES brasil_saas.bc_com_cotacao_fornecedor(id);


--
-- Name: bc_com_cotacao_item bc_com_cotacao_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_item
    ADD CONSTRAINT bc_com_cotacao_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_cotacao_item bc_com_cotacao_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao_item
    ADD CONSTRAINT bc_com_cotacao_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_com_cotacao bc_com_cotacao_solicitacao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_cotacao
    ADD CONSTRAINT bc_com_cotacao_solicitacao_id_fkey FOREIGN KEY (solicitacao_id) REFERENCES brasil_saas.bc_com_solicitacao(id);


--
-- Name: bc_com_pedido_item bc_com_item_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido_item
    ADD CONSTRAINT bc_com_item_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_pedido_item bc_com_item_pedido_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido_item
    ADD CONSTRAINT bc_com_item_pedido_fkey FOREIGN KEY (pedido_id) REFERENCES brasil_saas.bc_com_pedido(id);


--
-- Name: bc_com_pedido_item bc_com_item_produto_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido_item
    ADD CONSTRAINT bc_com_item_produto_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_com_pedido bc_com_pedido_cond_pagto_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido
    ADD CONSTRAINT bc_com_pedido_cond_pagto_fkey FOREIGN KEY (condicao_pagamento_id) REFERENCES brasil_saas.bc_fin_condicao_pagamento(id);


--
-- Name: bc_com_pedido bc_com_pedido_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido
    ADD CONSTRAINT bc_com_pedido_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_pedido bc_com_pedido_fornecedor_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido
    ADD CONSTRAINT bc_com_pedido_fornecedor_fkey FOREIGN KEY (fornecedor_id) REFERENCES brasil_saas.bc_cad_fornecedor(id);


--
-- Name: bc_com_pedido bc_com_pedido_titulo_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_pedido
    ADD CONSTRAINT bc_com_pedido_titulo_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_com_recebimento bc_com_recebimento_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento
    ADD CONSTRAINT bc_com_recebimento_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_recebimento_item bc_com_recebimento_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item
    ADD CONSTRAINT bc_com_recebimento_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_recebimento_item bc_com_recebimento_item_lote_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item
    ADD CONSTRAINT bc_com_recebimento_item_lote_id_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_com_recebimento_item bc_com_recebimento_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item
    ADD CONSTRAINT bc_com_recebimento_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_com_recebimento_item bc_com_recebimento_item_recebimento_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento_item
    ADD CONSTRAINT bc_com_recebimento_item_recebimento_id_fkey FOREIGN KEY (recebimento_id) REFERENCES brasil_saas.bc_com_recebimento(id);


--
-- Name: bc_com_recebimento bc_com_recebimento_pedido_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_recebimento
    ADD CONSTRAINT bc_com_recebimento_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES brasil_saas.bc_com_pedido(id);


--
-- Name: bc_com_solicitacao bc_com_solicitacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao
    ADD CONSTRAINT bc_com_solicitacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_solicitacao_item bc_com_solicitacao_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao_item
    ADD CONSTRAINT bc_com_solicitacao_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_com_solicitacao_item bc_com_solicitacao_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao_item
    ADD CONSTRAINT bc_com_solicitacao_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_com_solicitacao_item bc_com_solicitacao_item_solicitacao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_com_solicitacao_item
    ADD CONSTRAINT bc_com_solicitacao_item_solicitacao_id_fkey FOREIGN KEY (solicitacao_id) REFERENCES brasil_saas.bc_com_solicitacao(id);


--
-- Name: bc_core_auditoria bc_core_auditoria_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_auditoria
    ADD CONSTRAINT bc_core_auditoria_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_auditoria bc_core_auditoria_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_auditoria
    ADD CONSTRAINT bc_core_auditoria_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_core_configuracao bc_core_configuracao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_configuracao
    ADD CONSTRAINT bc_core_configuracao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_empresa_vinculo bc_core_empresa_vinculo_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa_vinculo
    ADD CONSTRAINT bc_core_empresa_vinculo_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_empresa_vinculo bc_core_empresa_vinculo_empresa_vinculada_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa_vinculo
    ADD CONSTRAINT bc_core_empresa_vinculo_empresa_vinculada_id_fkey FOREIGN KEY (empresa_vinculada_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_log_acesso bc_core_log_acesso_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_log_acesso
    ADD CONSTRAINT bc_core_log_acesso_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_log_acesso bc_core_log_acesso_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_log_acesso
    ADD CONSTRAINT bc_core_log_acesso_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_core_notificacao bc_core_notificacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_notificacao
    ADD CONSTRAINT bc_core_notificacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_notificacao bc_core_notificacao_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_notificacao
    ADD CONSTRAINT bc_core_notificacao_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_core_perfil bc_core_perfil_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil
    ADD CONSTRAINT bc_core_perfil_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_perfil_permissao bc_core_perfil_permissao_perfil_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil_permissao
    ADD CONSTRAINT bc_core_perfil_permissao_perfil_id_fkey FOREIGN KEY (perfil_id) REFERENCES brasil_saas.bc_core_perfil(id);


--
-- Name: bc_core_perfil_permissao bc_core_perfil_permissao_permissao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil_permissao
    ADD CONSTRAINT bc_core_perfil_permissao_permissao_id_fkey FOREIGN KEY (permissao_id) REFERENCES brasil_saas.bc_core_permissao(id);


--
-- Name: bc_core_sessao bc_core_sessao_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_sessao
    ADD CONSTRAINT bc_core_sessao_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_core_usuario bc_core_usuario_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario
    ADD CONSTRAINT bc_core_usuario_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_core_usuario_modulo bc_core_usuario_modulo_modulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_modulo
    ADD CONSTRAINT bc_core_usuario_modulo_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES brasil_saas.bc_core_modulo(id) ON DELETE CASCADE;


--
-- Name: bc_core_usuario_modulo bc_core_usuario_modulo_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_modulo
    ADD CONSTRAINT bc_core_usuario_modulo_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id) ON DELETE CASCADE;


--
-- Name: bc_core_usuario_perfil bc_core_usuario_perfil_perfil_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_perfil
    ADD CONSTRAINT bc_core_usuario_perfil_perfil_id_fkey FOREIGN KEY (perfil_id) REFERENCES brasil_saas.bc_core_perfil(id);


--
-- Name: bc_core_usuario_perfil bc_core_usuario_perfil_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_usuario_perfil
    ADD CONSTRAINT bc_core_usuario_perfil_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_crm_atividade bc_crm_atividade_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade
    ADD CONSTRAINT bc_crm_atividade_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_crm_atividade bc_crm_atividade_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade
    ADD CONSTRAINT bc_crm_atividade_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_crm_atividade bc_crm_atividade_oportunidade_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade
    ADD CONSTRAINT bc_crm_atividade_oportunidade_id_fkey FOREIGN KEY (oportunidade_id) REFERENCES brasil_saas.bc_crm_oportunidade(id);


--
-- Name: bc_crm_atividade bc_crm_atividade_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_atividade
    ADD CONSTRAINT bc_crm_atividade_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES brasil_saas.bc_rh_funcionario(id);


--
-- Name: bc_crm_oportunidade bc_crm_oportunidade_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_oportunidade
    ADD CONSTRAINT bc_crm_oportunidade_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_crm_oportunidade bc_crm_oportunidade_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_oportunidade
    ADD CONSTRAINT bc_crm_oportunidade_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_crm_oportunidade bc_crm_oportunidade_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_crm_oportunidade
    ADD CONSTRAINT bc_crm_oportunidade_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES brasil_saas.bc_rh_funcionario(id);


--
-- Name: bc_est_deposito bc_est_deposito_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_deposito
    ADD CONSTRAINT bc_est_deposito_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_endereco bc_est_endereco_deposito_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_endereco
    ADD CONSTRAINT bc_est_endereco_deposito_id_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_endereco bc_est_endereco_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_endereco
    ADD CONSTRAINT bc_est_endereco_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_expedicao bc_est_expedicao_deposito_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao
    ADD CONSTRAINT bc_est_expedicao_deposito_id_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_expedicao bc_est_expedicao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao
    ADD CONSTRAINT bc_est_expedicao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_endereco_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_endereco_fkey FOREIGN KEY (endereco_id) REFERENCES brasil_saas.bc_est_endereco(id);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_expedicao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_expedicao_id_fkey FOREIGN KEY (expedicao_id) REFERENCES brasil_saas.bc_est_expedicao(id) ON DELETE CASCADE;


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_lote_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_lote_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_expedicao_item bc_est_expedicao_item_reserva_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao_item
    ADD CONSTRAINT bc_est_expedicao_item_reserva_id_fkey FOREIGN KEY (reserva_id) REFERENCES brasil_saas.bc_est_reserva(id);


--
-- Name: bc_est_expedicao bc_est_expedicao_pedido_venda_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_expedicao
    ADD CONSTRAINT bc_est_expedicao_pedido_venda_id_fkey FOREIGN KEY (pedido_venda_id) REFERENCES brasil_saas.bc_ven_pedido(id);


--
-- Name: bc_est_inventario bc_est_inventario_deposito_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario
    ADD CONSTRAINT bc_est_inventario_deposito_id_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_inventario bc_est_inventario_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario
    ADD CONSTRAINT bc_est_inventario_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_inventario_item bc_est_inventario_item_endereco_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario_item
    ADD CONSTRAINT bc_est_inventario_item_endereco_id_fkey FOREIGN KEY (endereco_id) REFERENCES brasil_saas.bc_est_endereco(id);


--
-- Name: bc_est_inventario_item bc_est_inventario_item_inventario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario_item
    ADD CONSTRAINT bc_est_inventario_item_inventario_id_fkey FOREIGN KEY (inventario_id) REFERENCES brasil_saas.bc_est_inventario(id) ON DELETE CASCADE;


--
-- Name: bc_est_inventario_item bc_est_inventario_item_lote_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario_item
    ADD CONSTRAINT bc_est_inventario_item_lote_id_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_est_inventario_item bc_est_inventario_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_inventario_item
    ADD CONSTRAINT bc_est_inventario_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_lote bc_est_lote_deposito_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_lote
    ADD CONSTRAINT bc_est_lote_deposito_id_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_lote bc_est_lote_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_lote
    ADD CONSTRAINT bc_est_lote_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_lote bc_est_lote_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_lote
    ADD CONSTRAINT bc_est_lote_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_movimentacao bc_est_mov_deposito_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_movimentacao
    ADD CONSTRAINT bc_est_mov_deposito_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_movimentacao bc_est_mov_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_movimentacao
    ADD CONSTRAINT bc_est_mov_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_movimentacao bc_est_mov_produto_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_movimentacao
    ADD CONSTRAINT bc_est_mov_produto_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_reserva bc_est_reserva_deposito_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_deposito_id_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_reserva bc_est_reserva_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_reserva bc_est_reserva_endereco_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_endereco_fkey FOREIGN KEY (endereco_id) REFERENCES brasil_saas.bc_est_endereco(id);


--
-- Name: bc_est_reserva bc_est_reserva_lote_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_lote_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_est_reserva bc_est_reserva_pedido_venda_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_pedido_venda_id_fkey FOREIGN KEY (pedido_venda_id) REFERENCES brasil_saas.bc_ven_pedido(id);


--
-- Name: bc_est_reserva bc_est_reserva_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_reserva
    ADD CONSTRAINT bc_est_reserva_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_saldo bc_est_saldo_deposito_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_saldo
    ADD CONSTRAINT bc_est_saldo_deposito_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_saldo bc_est_saldo_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_saldo
    ADD CONSTRAINT bc_est_saldo_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_saldo bc_est_saldo_produto_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_saldo
    ADD CONSTRAINT bc_est_saldo_produto_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_serie bc_est_serie_deposito_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie
    ADD CONSTRAINT bc_est_serie_deposito_id_fkey FOREIGN KEY (deposito_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_serie bc_est_serie_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie
    ADD CONSTRAINT bc_est_serie_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_serie bc_est_serie_lote_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie
    ADD CONSTRAINT bc_est_serie_lote_id_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_est_serie bc_est_serie_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_serie
    ADD CONSTRAINT bc_est_serie_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_transferencia bc_est_transferencia_deposito_destino_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia
    ADD CONSTRAINT bc_est_transferencia_deposito_destino_id_fkey FOREIGN KEY (deposito_destino_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_transferencia bc_est_transferencia_deposito_origem_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia
    ADD CONSTRAINT bc_est_transferencia_deposito_origem_id_fkey FOREIGN KEY (deposito_origem_id) REFERENCES brasil_saas.bc_est_deposito(id);


--
-- Name: bc_est_transferencia bc_est_transferencia_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia
    ADD CONSTRAINT bc_est_transferencia_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_endereco_destino_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_endereco_destino_fkey FOREIGN KEY (endereco_destino_id) REFERENCES brasil_saas.bc_est_endereco(id);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_endereco_origem_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_endereco_origem_fkey FOREIGN KEY (endereco_origem_id) REFERENCES brasil_saas.bc_est_endereco(id);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_lote_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_lote_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_est_transferencia_item bc_est_transferencia_item_transferencia_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_est_transferencia_item
    ADD CONSTRAINT bc_est_transferencia_item_transferencia_id_fkey FOREIGN KEY (transferencia_id) REFERENCES brasil_saas.bc_est_transferencia(id) ON DELETE CASCADE;


--
-- Name: bc_fin_analise_rentabilidade bc_fin_analise_rentabilidade_centro_custo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_analise_rentabilidade
    ADD CONSTRAINT bc_fin_analise_rentabilidade_centro_custo_id_fkey FOREIGN KEY (centro_custo_id) REFERENCES brasil_saas.bc_fin_centro_custo(id);


--
-- Name: bc_fin_analise_rentabilidade bc_fin_analise_rentabilidade_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_analise_rentabilidade
    ADD CONSTRAINT bc_fin_analise_rentabilidade_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_aplicacao_financeira bc_fin_aplicacao_financeira_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aplicacao_financeira
    ADD CONSTRAINT bc_fin_aplicacao_financeira_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_aplicacao_financeira bc_fin_aplicacao_financeira_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aplicacao_financeira
    ADD CONSTRAINT bc_fin_aplicacao_financeira_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_aprovacao bc_fin_aprovacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao
    ADD CONSTRAINT bc_fin_aprovacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_aprovacao bc_fin_aprovacao_fluxo_aprovacao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao
    ADD CONSTRAINT bc_fin_aprovacao_fluxo_aprovacao_id_fkey FOREIGN KEY (fluxo_aprovacao_id) REFERENCES brasil_saas.bc_fin_fluxo_aprovacao(id);


--
-- Name: bc_fin_aprovacao bc_fin_aprovacao_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao
    ADD CONSTRAINT bc_fin_aprovacao_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_aprovacao bc_fin_aprovacao_usuario_aprovador_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_aprovacao
    ADD CONSTRAINT bc_fin_aprovacao_usuario_aprovador_id_fkey FOREIGN KEY (usuario_aprovador_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_fin_baixa bc_fin_baixa_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_baixa bc_fin_baixa_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_baixa bc_fin_baixa_parcela_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_parcela_id_fkey FOREIGN KEY (parcela_id) REFERENCES brasil_saas.bc_fin_titulo_parcela(id);


--
-- Name: bc_fin_baixa bc_fin_baixa_tipo_pagamento_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_tipo_pagamento_id_fkey FOREIGN KEY (tipo_pagamento_id) REFERENCES brasil_saas.bc_fin_tipo_pagamento(id);


--
-- Name: bc_fin_baixa bc_fin_baixa_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_baixa
    ADD CONSTRAINT bc_fin_baixa_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_boleto bc_fin_boleto_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_boleto
    ADD CONSTRAINT bc_fin_boleto_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_boleto bc_fin_boleto_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_boleto
    ADD CONSTRAINT bc_fin_boleto_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_caixa bc_fin_caixa_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_caixa
    ADD CONSTRAINT bc_fin_caixa_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_centro_custo bc_fin_centro_custo_centro_custo_pai_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_centro_custo
    ADD CONSTRAINT bc_fin_centro_custo_centro_custo_pai_id_fkey FOREIGN KEY (centro_custo_pai_id) REFERENCES brasil_saas.bc_fin_centro_custo(id);


--
-- Name: bc_fin_centro_custo bc_fin_centro_custo_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_centro_custo
    ADD CONSTRAINT bc_fin_centro_custo_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_conciliacao_bancaria bc_fin_conciliacao_bancaria_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_bancaria
    ADD CONSTRAINT bc_fin_conciliacao_bancaria_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_conciliacao_bancaria bc_fin_conciliacao_bancaria_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_bancaria
    ADD CONSTRAINT bc_fin_conciliacao_bancaria_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_conciliacao_item bc_fin_conciliacao_item_baixa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item
    ADD CONSTRAINT bc_fin_conciliacao_item_baixa_id_fkey FOREIGN KEY (baixa_id) REFERENCES brasil_saas.bc_fin_baixa(id);


--
-- Name: bc_fin_conciliacao_item bc_fin_conciliacao_item_conciliacao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item
    ADD CONSTRAINT bc_fin_conciliacao_item_conciliacao_id_fkey FOREIGN KEY (conciliacao_id) REFERENCES brasil_saas.bc_fin_conciliacao_bancaria(id);


--
-- Name: bc_fin_conciliacao_item bc_fin_conciliacao_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item
    ADD CONSTRAINT bc_fin_conciliacao_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_conciliacao_item bc_fin_conciliacao_item_extrato_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conciliacao_item
    ADD CONSTRAINT bc_fin_conciliacao_item_extrato_id_fkey FOREIGN KEY (extrato_id) REFERENCES brasil_saas.bc_fin_extrato(id);


--
-- Name: bc_fin_condicao_pagamento bc_fin_condicao_pagamento_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_condicao_pagamento
    ADD CONSTRAINT bc_fin_condicao_pagamento_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_conta_bancaria bc_fin_conta_bancaria_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_conta_bancaria
    ADD CONSTRAINT bc_fin_conta_bancaria_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_emprestimo bc_fin_emprestimo_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_emprestimo
    ADD CONSTRAINT bc_fin_emprestimo_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_extrato bc_fin_extrato_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_extrato
    ADD CONSTRAINT bc_fin_extrato_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_extrato bc_fin_extrato_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_extrato
    ADD CONSTRAINT bc_fin_extrato_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_fluxo_aprovacao bc_fin_fluxo_aprovacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_fluxo_aprovacao
    ADD CONSTRAINT bc_fin_fluxo_aprovacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_integracao_bancaria bc_fin_integracao_bancaria_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_integracao_bancaria
    ADD CONSTRAINT bc_fin_integracao_bancaria_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_integracao_bancaria bc_fin_integracao_bancaria_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_integracao_bancaria
    ADD CONSTRAINT bc_fin_integracao_bancaria_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_lancamento_contabil bc_fin_lancamento_contabil_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_contabil
    ADD CONSTRAINT bc_fin_lancamento_contabil_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_lancamento_contabil bc_fin_lancamento_contabil_periodo_contabil_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_contabil
    ADD CONSTRAINT bc_fin_lancamento_contabil_periodo_contabil_id_fkey FOREIGN KEY (periodo_contabil_id) REFERENCES brasil_saas.bc_fin_periodo_contabil(id);


--
-- Name: bc_fin_lancamento_partida bc_fin_lancamento_partida_centro_custo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida
    ADD CONSTRAINT bc_fin_lancamento_partida_centro_custo_id_fkey FOREIGN KEY (centro_custo_id) REFERENCES brasil_saas.bc_fin_centro_custo(id);


--
-- Name: bc_fin_lancamento_partida bc_fin_lancamento_partida_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida
    ADD CONSTRAINT bc_fin_lancamento_partida_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_lancamento_partida bc_fin_lancamento_partida_lancamento_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida
    ADD CONSTRAINT bc_fin_lancamento_partida_lancamento_id_fkey FOREIGN KEY (lancamento_id) REFERENCES brasil_saas.bc_fin_lancamento_contabil(id);


--
-- Name: bc_fin_lancamento_partida bc_fin_lancamento_partida_plano_contas_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_lancamento_partida
    ADD CONSTRAINT bc_fin_lancamento_partida_plano_contas_id_fkey FOREIGN KEY (plano_contas_id) REFERENCES brasil_saas.bc_fin_plano_contas(id);


--
-- Name: bc_fin_orcamento bc_fin_orcamento_centro_custo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento
    ADD CONSTRAINT bc_fin_orcamento_centro_custo_id_fkey FOREIGN KEY (centro_custo_id) REFERENCES brasil_saas.bc_fin_centro_custo(id);


--
-- Name: bc_fin_orcamento bc_fin_orcamento_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento
    ADD CONSTRAINT bc_fin_orcamento_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_orcamento bc_fin_orcamento_plano_contas_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento
    ADD CONSTRAINT bc_fin_orcamento_plano_contas_id_fkey FOREIGN KEY (plano_contas_id) REFERENCES brasil_saas.bc_fin_plano_contas(id);


--
-- Name: bc_fin_orcamento_realizado bc_fin_orcamento_realizado_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento_realizado
    ADD CONSTRAINT bc_fin_orcamento_realizado_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_orcamento_realizado bc_fin_orcamento_realizado_orcamento_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_orcamento_realizado
    ADD CONSTRAINT bc_fin_orcamento_realizado_orcamento_id_fkey FOREIGN KEY (orcamento_id) REFERENCES brasil_saas.bc_fin_orcamento(id);


--
-- Name: bc_fin_periodo_contabil bc_fin_periodo_contabil_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_periodo_contabil
    ADD CONSTRAINT bc_fin_periodo_contabil_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_plano_contas bc_fin_plano_contas_conta_pai_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_plano_contas
    ADD CONSTRAINT bc_fin_plano_contas_conta_pai_id_fkey FOREIGN KEY (conta_pai_id) REFERENCES brasil_saas.bc_fin_plano_contas(id);


--
-- Name: bc_fin_plano_contas bc_fin_plano_contas_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_plano_contas
    ADD CONSTRAINT bc_fin_plano_contas_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_projecao_fluxo_caixa bc_fin_projecao_fluxo_caixa_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_projecao_fluxo_caixa
    ADD CONSTRAINT bc_fin_projecao_fluxo_caixa_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_provisao_pdd bc_fin_provisao_pdd_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_provisao_pdd
    ADD CONSTRAINT bc_fin_provisao_pdd_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_remessa bc_fin_remessa_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa
    ADD CONSTRAINT bc_fin_remessa_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_remessa bc_fin_remessa_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa
    ADD CONSTRAINT bc_fin_remessa_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_remessa_item bc_fin_remessa_item_boleto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa_item
    ADD CONSTRAINT bc_fin_remessa_item_boleto_id_fkey FOREIGN KEY (boleto_id) REFERENCES brasil_saas.bc_fin_boleto(id);


--
-- Name: bc_fin_remessa_item bc_fin_remessa_item_remessa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa_item
    ADD CONSTRAINT bc_fin_remessa_item_remessa_id_fkey FOREIGN KEY (remessa_id) REFERENCES brasil_saas.bc_fin_remessa(id) ON DELETE CASCADE;


--
-- Name: bc_fin_remessa_item bc_fin_remessa_item_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_remessa_item
    ADD CONSTRAINT bc_fin_remessa_item_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_renegociacao bc_fin_renegociacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_renegociacao
    ADD CONSTRAINT bc_fin_renegociacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_renegociacao bc_fin_renegociacao_novo_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_renegociacao
    ADD CONSTRAINT bc_fin_renegociacao_novo_titulo_id_fkey FOREIGN KEY (novo_titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_renegociacao bc_fin_renegociacao_titulo_original_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_renegociacao
    ADD CONSTRAINT bc_fin_renegociacao_titulo_original_id_fkey FOREIGN KEY (titulo_original_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_retorno_bancario bc_fin_retorno_bancario_conta_bancaria_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_bancario
    ADD CONSTRAINT bc_fin_retorno_bancario_conta_bancaria_id_fkey FOREIGN KEY (conta_bancaria_id) REFERENCES brasil_saas.bc_fin_conta_bancaria(id);


--
-- Name: bc_fin_retorno_bancario bc_fin_retorno_bancario_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_bancario
    ADD CONSTRAINT bc_fin_retorno_bancario_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_retorno_item bc_fin_retorno_item_boleto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_item
    ADD CONSTRAINT bc_fin_retorno_item_boleto_id_fkey FOREIGN KEY (boleto_id) REFERENCES brasil_saas.bc_fin_boleto(id);


--
-- Name: bc_fin_retorno_item bc_fin_retorno_item_retorno_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_item
    ADD CONSTRAINT bc_fin_retorno_item_retorno_id_fkey FOREIGN KEY (retorno_id) REFERENCES brasil_saas.bc_fin_retorno_bancario(id) ON DELETE CASCADE;


--
-- Name: bc_fin_retorno_item bc_fin_retorno_item_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_retorno_item
    ADD CONSTRAINT bc_fin_retorno_item_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_tipo_pagamento bc_fin_tipo_pagamento_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_tipo_pagamento
    ADD CONSTRAINT bc_fin_tipo_pagamento_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_titulo bc_fin_titulo_centro_custo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo
    ADD CONSTRAINT bc_fin_titulo_centro_custo_id_fkey FOREIGN KEY (centro_custo_id) REFERENCES brasil_saas.bc_fin_centro_custo(id);


--
-- Name: bc_fin_titulo bc_fin_titulo_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo
    ADD CONSTRAINT bc_fin_titulo_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_titulo_parcela bc_fin_titulo_parcela_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo_parcela
    ADD CONSTRAINT bc_fin_titulo_parcela_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fin_titulo_parcela bc_fin_titulo_parcela_titulo_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo_parcela
    ADD CONSTRAINT bc_fin_titulo_parcela_titulo_id_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_fin_titulo bc_fin_titulo_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo
    ADD CONSTRAINT bc_fin_titulo_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_fin_titulo bc_fin_titulo_plano_contas_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fin_titulo
    ADD CONSTRAINT bc_fin_titulo_plano_contas_id_fkey FOREIGN KEY (plano_contas_id) REFERENCES brasil_saas.bc_fin_plano_contas(id);


--
-- Name: bc_fis_apuracao bc_fis_apuracao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao
    ADD CONSTRAINT bc_fis_apuracao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_apuracao bc_fis_apuracao_imposto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_apuracao
    ADD CONSTRAINT bc_fis_apuracao_imposto_id_fkey FOREIGN KEY (imposto_id) REFERENCES brasil_saas.bc_fis_imposto(id);


--
-- Name: bc_fis_certificado_digital bc_fis_certificado_digital_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_certificado_digital
    ADD CONSTRAINT bc_fis_certificado_digital_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_cte bc_fis_cte_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte
    ADD CONSTRAINT bc_fis_cte_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_cte_item bc_fis_cte_item_cte_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte_item
    ADD CONSTRAINT bc_fis_cte_item_cte_id_fkey FOREIGN KEY (cte_id) REFERENCES brasil_saas.bc_fis_cte(id);


--
-- Name: bc_fis_cte bc_fis_cte_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_cte
    ADD CONSTRAINT bc_fis_cte_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_fis_ecd bc_fis_ecd_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecd
    ADD CONSTRAINT bc_fis_ecd_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_ecf bc_fis_ecf_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_ecf
    ADD CONSTRAINT bc_fis_ecf_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_esocial bc_fis_esocial_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_esocial
    ADD CONSTRAINT bc_fis_esocial_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_imposto bc_fis_imposto_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_imposto
    ADD CONSTRAINT bc_fis_imposto_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_manifestacao bc_fis_manifestacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_manifestacao
    ADD CONSTRAINT bc_fis_manifestacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_mdfe bc_fis_mdfe_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_mdfe
    ADD CONSTRAINT bc_fis_mdfe_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_nfce bc_fis_nfce_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce
    ADD CONSTRAINT bc_fis_nfce_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_nfce_item bc_fis_nfce_item_nfce_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce_item
    ADD CONSTRAINT bc_fis_nfce_item_nfce_id_fkey FOREIGN KEY (nfce_id) REFERENCES brasil_saas.bc_fis_nfce(id);


--
-- Name: bc_fis_nfce_item bc_fis_nfce_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce_item
    ADD CONSTRAINT bc_fis_nfce_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_fis_nfce bc_fis_nfce_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfce
    ADD CONSTRAINT bc_fis_nfce_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_fis_nfe bc_fis_nfe_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_fis_nfe bc_fis_nfe_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_nfe_evento bc_fis_nfe_evento_nfe_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_evento
    ADD CONSTRAINT bc_fis_nfe_evento_nfe_id_fkey FOREIGN KEY (nfe_id) REFERENCES brasil_saas.bc_fis_nfe(id);


--
-- Name: bc_fis_nfe_item bc_fis_nfe_item_nfe_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_item
    ADD CONSTRAINT bc_fis_nfe_item_nfe_id_fkey FOREIGN KEY (nfe_id) REFERENCES brasil_saas.bc_fis_nfe(id);


--
-- Name: bc_fis_nfe_item bc_fis_nfe_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe_item
    ADD CONSTRAINT bc_fis_nfe_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_fis_nfe bc_fis_nfe_pedido_compra_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_pedido_compra_fkey FOREIGN KEY (pedido_compra_id) REFERENCES brasil_saas.bc_com_pedido(id);


--
-- Name: bc_fis_nfe bc_fis_nfe_pedido_venda_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_pedido_venda_fkey FOREIGN KEY (pedido_venda_id) REFERENCES brasil_saas.bc_ven_pedido(id);


--
-- Name: bc_fis_nfe bc_fis_nfe_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfe
    ADD CONSTRAINT bc_fis_nfe_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_fis_nfse bc_fis_nfse_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse
    ADD CONSTRAINT bc_fis_nfse_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_fis_nfse bc_fis_nfse_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse
    ADD CONSTRAINT bc_fis_nfse_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_nfse_item bc_fis_nfse_item_nfse_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_item
    ADD CONSTRAINT bc_fis_nfse_item_nfse_id_fkey FOREIGN KEY (nfse_id) REFERENCES brasil_saas.bc_fis_nfse(id);


--
-- Name: bc_fis_nfse_item bc_fis_nfse_item_servico_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_item
    ADD CONSTRAINT bc_fis_nfse_item_servico_id_fkey FOREIGN KEY (servico_id) REFERENCES brasil_saas.bc_cad_servico(id);


--
-- Name: bc_fis_nfse bc_fis_nfse_pessoa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse
    ADD CONSTRAINT bc_fis_nfse_pessoa_id_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_fis_nfse bc_fis_nfse_servico_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse
    ADD CONSTRAINT bc_fis_nfse_servico_id_fkey FOREIGN KEY (servico_id) REFERENCES brasil_saas.bc_cad_servico(id);


--
-- Name: bc_fis_regra_tributaria bc_fis_regra_tributaria_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_regra_tributaria
    ADD CONSTRAINT bc_fis_regra_tributaria_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_reinf bc_fis_reinf_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_reinf
    ADD CONSTRAINT bc_fis_reinf_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_sped_contribuicoes bc_fis_sped_contribuicoes_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_contribuicoes
    ADD CONSTRAINT bc_fis_sped_contribuicoes_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_fis_sped_fiscal bc_fis_sped_fiscal_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_sped_fiscal
    ADD CONSTRAINT bc_fis_sped_fiscal_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ia_analise_preditiva bc_ia_analise_preditiva_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_analise_preditiva
    ADD CONSTRAINT bc_ia_analise_preditiva_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_chat_mensagem bc_ia_chat_mensagem_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_mensagem
    ADD CONSTRAINT bc_ia_chat_mensagem_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_chat_mensagem bc_ia_chat_mensagem_sessao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_mensagem
    ADD CONSTRAINT bc_ia_chat_mensagem_sessao_id_fkey FOREIGN KEY (sessao_id) REFERENCES brasil_saas.bc_ia_chat_sessao(id) ON DELETE CASCADE;


--
-- Name: bc_ia_chat_message bc_ia_chat_message_session_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_message
    ADD CONSTRAINT bc_ia_chat_message_session_id_fkey FOREIGN KEY (session_id) REFERENCES brasil_saas.bc_ia_chat_session(id) ON DELETE CASCADE;


--
-- Name: bc_ia_chat_sessao bc_ia_chat_sessao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_sessao
    ADD CONSTRAINT bc_ia_chat_sessao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_chat_session bc_ia_chat_session_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_chat_session
    ADD CONSTRAINT bc_ia_chat_session_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_classificacao bc_ia_classificacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_classificacao
    ADD CONSTRAINT bc_ia_classificacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_config bc_ia_config_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_config
    ADD CONSTRAINT bc_ia_config_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_embedding bc_ia_embedding_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_embedding
    ADD CONSTRAINT bc_ia_embedding_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_prompt bc_ia_prompt_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt
    ADD CONSTRAINT bc_ia_prompt_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_ia_prompt_template bc_ia_prompt_template_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ia_prompt_template
    ADD CONSTRAINT bc_ia_prompt_template_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_prod_apontamento bc_prod_apontamento_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_apontamento
    ADD CONSTRAINT bc_prod_apontamento_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_prod_apontamento bc_prod_apontamento_item_producao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_apontamento
    ADD CONSTRAINT bc_prod_apontamento_item_producao_id_fkey FOREIGN KEY (item_producao_id) REFERENCES brasil_saas.bc_prod_item(id);


--
-- Name: bc_prod_apontamento bc_prod_apontamento_producao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_apontamento
    ADD CONSTRAINT bc_prod_apontamento_producao_id_fkey FOREIGN KEY (producao_id) REFERENCES brasil_saas.bc_prod_ordem(id) ON DELETE CASCADE;


--
-- Name: bc_prod_estrutura bc_prod_estrutura_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_estrutura
    ADD CONSTRAINT bc_prod_estrutura_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_prod_romaneio bc_prod_romaneio_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio
    ADD CONSTRAINT bc_prod_romaneio_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE CASCADE;


--
-- Name: bc_prod_romaneio_item bc_prod_romaneio_item_romaneio_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio_item
    ADD CONSTRAINT bc_prod_romaneio_item_romaneio_id_fkey FOREIGN KEY (romaneio_id) REFERENCES brasil_saas.bc_prod_romaneio(id) ON DELETE CASCADE;


--
-- Name: bc_prod_romaneio bc_prod_romaneio_producao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_romaneio
    ADD CONSTRAINT bc_prod_romaneio_producao_id_fkey FOREIGN KEY (producao_id) REFERENCES brasil_saas.bc_prod_ordem(id) ON DELETE RESTRICT;


--
-- Name: bc_rh_cargo bc_rh_cargo_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_cargo
    ADD CONSTRAINT bc_rh_cargo_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_rh_folha bc_rh_folha_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha
    ADD CONSTRAINT bc_rh_folha_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_rh_folha_item bc_rh_folha_item_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha_item
    ADD CONSTRAINT bc_rh_folha_item_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_rh_folha_item bc_rh_folha_item_folha_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha_item
    ADD CONSTRAINT bc_rh_folha_item_folha_fkey FOREIGN KEY (folha_id) REFERENCES brasil_saas.bc_rh_folha(id);


--
-- Name: bc_rh_folha_item bc_rh_folha_item_func_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha_item
    ADD CONSTRAINT bc_rh_folha_item_func_fkey FOREIGN KEY (funcionario_id) REFERENCES brasil_saas.bc_rh_funcionario(id);


--
-- Name: bc_rh_folha bc_rh_folha_titulo_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_folha
    ADD CONSTRAINT bc_rh_folha_titulo_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_rh_funcionario bc_rh_func_cargo_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_funcionario
    ADD CONSTRAINT bc_rh_func_cargo_fkey FOREIGN KEY (cargo_id) REFERENCES brasil_saas.bc_rh_cargo(id);


--
-- Name: bc_rh_funcionario bc_rh_func_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_funcionario
    ADD CONSTRAINT bc_rh_func_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_rh_funcionario bc_rh_func_pessoa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_rh_funcionario
    ADD CONSTRAINT bc_rh_func_pessoa_fkey FOREIGN KEY (pessoa_id) REFERENCES brasil_saas.bc_cad_pessoa(id);


--
-- Name: bc_srv_ordem_servico bc_srv_ordem_servico_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico
    ADD CONSTRAINT bc_srv_ordem_servico_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_srv_ordem_servico bc_srv_ordem_servico_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico
    ADD CONSTRAINT bc_srv_ordem_servico_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_srv_ordem_servico bc_srv_ordem_servico_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_ordem_servico
    ADD CONSTRAINT bc_srv_ordem_servico_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_srv_os_apontamento bc_srv_os_apontamento_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_apontamento
    ADD CONSTRAINT bc_srv_os_apontamento_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_srv_os_apontamento bc_srv_os_apontamento_os_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_apontamento
    ADD CONSTRAINT bc_srv_os_apontamento_os_id_fkey FOREIGN KEY (os_id) REFERENCES brasil_saas.bc_srv_ordem_servico(id);


--
-- Name: bc_srv_os_apontamento bc_srv_os_apontamento_usuario_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_apontamento
    ADD CONSTRAINT bc_srv_os_apontamento_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES brasil_saas.bc_core_usuario(id);


--
-- Name: bc_srv_os_item bc_srv_os_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item
    ADD CONSTRAINT bc_srv_os_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_srv_os_item bc_srv_os_item_os_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item
    ADD CONSTRAINT bc_srv_os_item_os_id_fkey FOREIGN KEY (os_id) REFERENCES brasil_saas.bc_srv_ordem_servico(id);


--
-- Name: bc_srv_os_item bc_srv_os_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item
    ADD CONSTRAINT bc_srv_os_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_srv_os_item bc_srv_os_item_servico_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_srv_os_item
    ADD CONSTRAINT bc_srv_os_item_servico_id_fkey FOREIGN KEY (servico_id) REFERENCES brasil_saas.bc_cad_servico(id);


--
-- Name: bc_ven_bonificacao bc_ven_bonificacao_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao
    ADD CONSTRAINT bc_ven_bonificacao_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_ven_bonificacao bc_ven_bonificacao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao
    ADD CONSTRAINT bc_ven_bonificacao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_bonificacao_item bc_ven_bonificacao_item_bonificacao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao_item
    ADD CONSTRAINT bc_ven_bonificacao_item_bonificacao_id_fkey FOREIGN KEY (bonificacao_id) REFERENCES brasil_saas.bc_ven_bonificacao(id);


--
-- Name: bc_ven_bonificacao_item bc_ven_bonificacao_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao_item
    ADD CONSTRAINT bc_ven_bonificacao_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_bonificacao_item bc_ven_bonificacao_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao_item
    ADD CONSTRAINT bc_ven_bonificacao_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_ven_bonificacao bc_ven_bonificacao_pedido_origem_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_bonificacao
    ADD CONSTRAINT bc_ven_bonificacao_pedido_origem_id_fkey FOREIGN KEY (pedido_origem_id) REFERENCES brasil_saas.bc_ven_pedido(id);


--
-- Name: bc_ven_contrato bc_ven_contrato_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato
    ADD CONSTRAINT bc_ven_contrato_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_ven_contrato bc_ven_contrato_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato
    ADD CONSTRAINT bc_ven_contrato_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_contrato_item bc_ven_contrato_item_contrato_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item
    ADD CONSTRAINT bc_ven_contrato_item_contrato_id_fkey FOREIGN KEY (contrato_id) REFERENCES brasil_saas.bc_ven_contrato(id);


--
-- Name: bc_ven_contrato_item bc_ven_contrato_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item
    ADD CONSTRAINT bc_ven_contrato_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_contrato_item bc_ven_contrato_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item
    ADD CONSTRAINT bc_ven_contrato_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_ven_contrato_item bc_ven_contrato_item_servico_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_contrato_item
    ADD CONSTRAINT bc_ven_contrato_item_servico_id_fkey FOREIGN KEY (servico_id) REFERENCES brasil_saas.bc_cad_servico(id);


--
-- Name: bc_ven_devolucao bc_ven_devolucao_cliente_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao
    ADD CONSTRAINT bc_ven_devolucao_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_ven_devolucao bc_ven_devolucao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao
    ADD CONSTRAINT bc_ven_devolucao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_devolucao_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_devolucao_id_fkey FOREIGN KEY (devolucao_id) REFERENCES brasil_saas.bc_ven_devolucao(id);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_lote_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_lote_id_fkey FOREIGN KEY (lote_id) REFERENCES brasil_saas.bc_est_lote(id);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_numero_serie_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_numero_serie_id_fkey FOREIGN KEY (numero_serie_id) REFERENCES brasil_saas.bc_est_serie(id);


--
-- Name: bc_ven_devolucao_item bc_ven_devolucao_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao_item
    ADD CONSTRAINT bc_ven_devolucao_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_ven_devolucao bc_ven_devolucao_pedido_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_devolucao
    ADD CONSTRAINT bc_ven_devolucao_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES brasil_saas.bc_ven_pedido(id);


--
-- Name: bc_ven_pedido_item bc_ven_item_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item
    ADD CONSTRAINT bc_ven_item_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_pedido_item bc_ven_item_pedido_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item
    ADD CONSTRAINT bc_ven_item_pedido_fkey FOREIGN KEY (pedido_id) REFERENCES brasil_saas.bc_ven_pedido(id);


--
-- Name: bc_ven_pedido_item bc_ven_item_produto_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item
    ADD CONSTRAINT bc_ven_item_produto_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_ven_pedido_item bc_ven_item_servico_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido_item
    ADD CONSTRAINT bc_ven_item_servico_fkey FOREIGN KEY (servico_id) REFERENCES brasil_saas.bc_cad_servico(id);


--
-- Name: bc_ven_pedido bc_ven_pedido_cliente_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT bc_ven_pedido_cliente_fkey FOREIGN KEY (cliente_id) REFERENCES brasil_saas.bc_cad_cliente(id);


--
-- Name: bc_ven_pedido bc_ven_pedido_cond_pagto_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT bc_ven_pedido_cond_pagto_fkey FOREIGN KEY (condicao_pagamento_id) REFERENCES brasil_saas.bc_fin_condicao_pagamento(id);


--
-- Name: bc_ven_pedido bc_ven_pedido_empresa_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT bc_ven_pedido_empresa_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_pedido bc_ven_pedido_tabela_preco_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT bc_ven_pedido_tabela_preco_fkey FOREIGN KEY (tabela_preco_id) REFERENCES brasil_saas.bc_ven_tabela_preco(id);


--
-- Name: bc_ven_pedido bc_ven_pedido_titulo_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_pedido
    ADD CONSTRAINT bc_ven_pedido_titulo_fkey FOREIGN KEY (titulo_id) REFERENCES brasil_saas.bc_fin_titulo(id);


--
-- Name: bc_ven_regra_comissao bc_ven_regra_comissao_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_regra_comissao
    ADD CONSTRAINT bc_ven_regra_comissao_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_regra_comissao bc_ven_regra_comissao_vendedor_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_regra_comissao
    ADD CONSTRAINT bc_ven_regra_comissao_vendedor_id_fkey FOREIGN KEY (vendedor_id) REFERENCES brasil_saas.bc_rh_funcionario(id);


--
-- Name: bc_ven_tabela_preco bc_ven_tabela_preco_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco
    ADD CONSTRAINT bc_ven_tabela_preco_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_tabela_preco_item bc_ven_tabela_preco_item_empresa_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item
    ADD CONSTRAINT bc_ven_tabela_preco_item_empresa_id_fkey FOREIGN KEY (empresa_id) REFERENCES brasil_saas.bc_core_empresa(id);


--
-- Name: bc_ven_tabela_preco_item bc_ven_tabela_preco_item_produto_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item
    ADD CONSTRAINT bc_ven_tabela_preco_item_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES brasil_saas.bc_cad_produto(id);


--
-- Name: bc_ven_tabela_preco_item bc_ven_tabela_preco_item_tabela_preco_id_fkey; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_ven_tabela_preco_item
    ADD CONSTRAINT bc_ven_tabela_preco_item_tabela_preco_id_fkey FOREIGN KEY (tabela_preco_id) REFERENCES brasil_saas.bc_ven_tabela_preco(id);


--
-- Name: bc_core_perfil fk_bc_core_perfil_pai; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_perfil
    ADD CONSTRAINT fk_bc_core_perfil_pai FOREIGN KEY (perfil_pai_id) REFERENCES brasil_saas.bc_core_perfil(id) ON DELETE SET NULL;


--
-- Name: bc_core_empresa fk_empresa_matriz_do_grupo; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_core_empresa
    ADD CONSTRAINT fk_empresa_matriz_do_grupo FOREIGN KEY (matriz_id) REFERENCES brasil_saas.bc_core_empresa(id) ON DELETE RESTRICT;


--
-- Name: bc_fis_nfse_retorno fk_fis_nfse_retorno_nfse; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_fis_nfse_retorno
    ADD CONSTRAINT fk_fis_nfse_retorno_nfse FOREIGN KEY (nfse_id) REFERENCES brasil_saas.bc_fis_nfse(id) ON DELETE CASCADE;


--
-- Name: bc_prod_item fkal2vl187nvs8xwaq8kbexe66k; Type: FK CONSTRAINT; Schema: brasil_saas; Owner: -
--

ALTER TABLE ONLY brasil_saas.bc_prod_item
    ADD CONSTRAINT fkal2vl187nvs8xwaq8kbexe66k FOREIGN KEY (producao_id) REFERENCES brasil_saas.bc_prod_ordem(id);


--
-- Name: ffinanceiro ffinanceiro_codmovimento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ffinanceiro
    ADD CONSTRAINT ffinanceiro_codmovimento_fkey FOREIGN KEY (codmovimento) REFERENCES public.fmovimento(codmovimento) ON DELETE CASCADE;


--
-- Name: fitem fitem_codvariacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fitem
    ADD CONSTRAINT fitem_codvariacao_fkey FOREIGN KEY (codvariacao) REFERENCES public.fproduto_variacao(codvariacao);


--
-- Name: flan flan_id_pessoa_parceiro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flan
    ADD CONSTRAINT flan_id_pessoa_parceiro_fkey FOREIGN KEY (id_pessoa_parceiro) REFERENCES public.fpessoa(id_pessoa);


--
-- Name: fmov fmov_id_pessoa_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmov
    ADD CONSTRAINT fmov_id_pessoa_cliente_fkey FOREIGN KEY (id_pessoa_cliente) REFERENCES public.fpessoa(id_pessoa);


--
-- Name: fmov fmov_id_pessoa_funcionario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmov
    ADD CONSTRAINT fmov_id_pessoa_funcionario_fkey FOREIGN KEY (id_pessoa_funcionario) REFERENCES public.fpessoa(id_pessoa);


--
-- Name: fmovimento_item fmovimento_item_codmovimento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmovimento_item
    ADD CONSTRAINT fmovimento_item_codmovimento_fkey FOREIGN KEY (codmovimento) REFERENCES public.fmovimento(codmovimento) ON DELETE CASCADE;


--
-- Name: fmovimento_item fmovimento_item_codvariacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmovimento_item
    ADD CONSTRAINT fmovimento_item_codvariacao_fkey FOREIGN KEY (codvariacao) REFERENCES public.fproduto_variacao(codvariacao);


--
-- Name: fnota fnota_centro_custo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota
    ADD CONSTRAINT fnota_centro_custo_fkey FOREIGN KEY (centro_custo) REFERENCES public.fcusto(codcusto);


--
-- Name: fnota fnota_codmovimento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota
    ADD CONSTRAINT fnota_codmovimento_fkey FOREIGN KEY (codmovimento) REFERENCES public.fmovimento(codmovimento);


--
-- Name: fnota fnota_id_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota
    ADD CONSTRAINT fnota_id_venda_fkey FOREIGN KEY (id_venda) REFERENCES public.fvenda(id_venda) ON DELETE CASCADE;


--
-- Name: fnota_item fnota_item_codvariacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota_item
    ADD CONSTRAINT fnota_item_codvariacao_fkey FOREIGN KEY (codvariacao) REFERENCES public.fproduto_variacao(codvariacao);


--
-- Name: fnota_item fnota_item_id_nota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fnota_item
    ADD CONSTRAINT fnota_item_id_nota_fkey FOREIGN KEY (id_nota) REFERENCES public.fnota(id_nota) ON DELETE CASCADE;


--
-- Name: fpessoa fpessoa_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fpessoa
    ADD CONSTRAINT fpessoa_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.fusuario(codigo);


--
-- Name: fproduto_ecommerce fproduto_ecommerce_codproduto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_ecommerce
    ADD CONSTRAINT fproduto_ecommerce_codproduto_fkey FOREIGN KEY (codproduto) REFERENCES public.fproduto(codproduto) ON DELETE CASCADE;


--
-- Name: fproduto_fiscal fproduto_fiscal_codproduto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_fiscal
    ADD CONSTRAINT fproduto_fiscal_codproduto_fkey FOREIGN KEY (codproduto) REFERENCES public.fproduto(codproduto) ON DELETE CASCADE;


--
-- Name: fproduto_imagem fproduto_imagem_codvariacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_imagem
    ADD CONSTRAINT fproduto_imagem_codvariacao_fkey FOREIGN KEY (codvariacao) REFERENCES public.fproduto_variacao(codvariacao) ON DELETE CASCADE;


--
-- Name: fproduto_kit fproduto_kit_codkit_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_kit
    ADD CONSTRAINT fproduto_kit_codkit_fkey FOREIGN KEY (codkit) REFERENCES public.fproduto(codproduto) ON DELETE CASCADE;


--
-- Name: fproduto_kit fproduto_kit_codproduto_filho_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_kit
    ADD CONSTRAINT fproduto_kit_codproduto_filho_fkey FOREIGN KEY (codproduto_filho) REFERENCES public.fproduto(codproduto) ON DELETE CASCADE;


--
-- Name: fproduto_movimento fproduto_movimento_codvariacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_movimento
    ADD CONSTRAINT fproduto_movimento_codvariacao_fkey FOREIGN KEY (codvariacao) REFERENCES public.fproduto_variacao(codvariacao) ON DELETE CASCADE;


--
-- Name: fproduto_variacao fproduto_variacao_codproduto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fproduto_variacao
    ADD CONSTRAINT fproduto_variacao_codproduto_fkey FOREIGN KEY (codproduto) REFERENCES public.fproduto(codproduto) ON DELETE CASCADE;


--
-- Name: fvenda fvenda_centro_custo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda
    ADD CONSTRAINT fvenda_centro_custo_fkey FOREIGN KEY (centro_custo) REFERENCES public.fcusto(codcusto);


--
-- Name: fvenda fvenda_condicao_pagamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda
    ADD CONSTRAINT fvenda_condicao_pagamento_fkey FOREIGN KEY (condicao_pagamento) REFERENCES public.fcondicao(codcondicao);


--
-- Name: fvenda fvenda_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda
    ADD CONSTRAINT fvenda_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.fpessoa(id_pessoa);


--
-- Name: fvenda fvenda_id_recibo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda
    ADD CONSTRAINT fvenda_id_recibo_fkey FOREIGN KEY (id_recibo) REFERENCES public.frecibo(idrecibo);


--
-- Name: fvenda_item fvenda_item_codvariacao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda_item
    ADD CONSTRAINT fvenda_item_codvariacao_fkey FOREIGN KEY (codvariacao) REFERENCES public.fproduto_variacao(codvariacao);


--
-- Name: fvenda_item fvenda_item_id_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda_item
    ADD CONSTRAINT fvenda_item_id_venda_fkey FOREIGN KEY (id_venda) REFERENCES public.fvenda(id_venda) ON DELETE CASCADE;


--
-- Name: fvenda fvenda_tipo_pagamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fvenda
    ADD CONSTRAINT fvenda_tipo_pagamento_fkey FOREIGN KEY (tipo_pagamento) REFERENCES public.ftipopagamento(codtipo);


--
-- Name: tcnae_servico tcnae_servico_codigo_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tcnae_servico
    ADD CONSTRAINT tcnae_servico_codigo_item_fkey FOREIGN KEY (codigo_item) REFERENCES public.tservico_lc116(codigo_item);


--
-- PostgreSQL database dump complete
--

\unrestrict 2ZcSy2FdaWKfBPjpHUmu9KLqIpIJbaiT5pnXDsxx5VXzgW8FD6oH1LYkAhqIVY9

